"""
Módulo de ferramentas para agentes CrewAI do sistema Fuel OP.
Contém todas as funções que os agentes podem usar para interagir com o sistema.
"""

import logging
import smtplib
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Dict, Optional, Any
from sqlalchemy.orm import Session
from twilio.rest import Client

from .database import SessionLocal, SensorData, AnomalyEvent, ActionFeedback
from .config import settings

logger = logging.getLogger(__name__)

def query_recent_sensor_data(
    station_id: Optional[str] = None,
    sensor_type: Optional[str] = None,
    hours_back: int = 24,
    limit: int = 100
) -> List[Dict[str, Any]]:
    """
    Consultar dados recentes dos sensores.

    Args:
        station_id: ID da estação (opcional)
        sensor_type: Tipo do sensor (opcional)
        hours_back: Horas para trás na consulta
        limit: Limite de registros

    Returns:
        Lista de dados dos sensores
    """
    try:
        with SessionLocal() as db:
            query = db.query(SensorData)

            # Filtros opcionais
            if station_id:
                query = query.filter(SensorData.station_id == station_id)
            if sensor_type:
                query = query.filter(SensorData.sensor_type == sensor_type)

            # Filtro de tempo
            time_threshold = datetime.utcnow() - timedelta(hours=hours_back)
            query = query.filter(SensorData.timestamp >= time_threshold)

            # Ordenar e limitar
            results = query.order_by(SensorData.timestamp.desc()).limit(limit).all()

            # Converter para dicionário
            data = []
            for result in results:
                data.append({
                    "id": result.id,
                    "station_id": result.station_id,
                    "sensor_type": result.sensor_type,
                    "value": result.value,
                    "unit": result.unit,
                    "timestamp": result.timestamp.isoformat(),
                    "quality_score": result.quality_score
                })

            logger.info(f"Consultados {len(data)} registros de sensores")
            return data

    except Exception as e:
        logger.error(f"Erro ao consultar dados de sensores: {e}")
        return []

def save_anomaly_record(
    station_id: str,
    sensor_type: str,
    anomaly_score: float,
    sensor_value: float,
    threshold: float = 0.7,
    severity: str = "medium",
    description: Optional[str] = None
) -> Dict[str, Any]:
    """
    Salvar registro de anomalia detectada.

    Args:
        station_id: ID da estação
        sensor_type: Tipo do sensor
        anomaly_score: Score da anomalia
        sensor_value: Valor do sensor que causou anomalia
        threshold: Limiar usado para detecção
        severity: Severidade (low, medium, high, critical)
        description: Descrição da anomalia

    Returns:
        Dados da anomalia salva
    """
    try:
        with SessionLocal() as db:
            anomaly = AnomalyEvent(
                station_id=station_id,
                sensor_type=sensor_type,
                anomaly_score=anomaly_score,
                threshold=threshold,
                sensor_value=sensor_value,
                severity=severity,
                description=description
            )

            db.add(anomaly)
            db.commit()
            db.refresh(anomaly)

            result = {
                "id": anomaly.id,
                "station_id": anomaly.station_id,
                "sensor_type": anomaly.sensor_type,
                "anomaly_score": anomaly.anomaly_score,
                "severity": anomaly.severity,
                "detected_at": anomaly.detected_at.isoformat()
            }

            logger.info(f"Anomalia salva com ID: {anomaly.id}")
            return result

    except Exception as e:
        logger.error(f"Erro ao salvar anomalia: {e}")
        return {}

def get_recent_anomalies(
    station_id: Optional[str] = None,
    severity: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 50
) -> List[Dict[str, Any]]:
    """
    Obter anomalias recentes.

    Args:
        station_id: ID da estação (opcional)
        severity: Severidade (opcional)
        status: Status (opcional)
        limit: Limite de registros

    Returns:
        Lista de anomalias
    """
    try:
        with SessionLocal() as db:
            query = db.query(AnomalyEvent)

            # Filtros opcionais
            if station_id:
                query = query.filter(AnomalyEvent.station_id == station_id)
            if severity:
                query = query.filter(AnomalyEvent.severity == severity)
            if status:
                query = query.filter(AnomalyEvent.status == status)

            results = query.order_by(AnomalyEvent.detected_at.desc()).limit(limit).all()

            anomalies = []
            for result in results:
                anomalies.append({
                    "id": result.id,
                    "station_id": result.station_id,
                    "sensor_type": result.sensor_type,
                    "anomaly_score": result.anomaly_score,
                    "severity": result.severity,
                    "status": result.status,
                    "sensor_value": result.sensor_value,
                    "detected_at": result.detected_at.isoformat(),
                    "description": result.description
                })

            logger.info(f"Consultadas {len(anomalies)} anomalias")
            return anomalies

    except Exception as e:
        logger.error(f"Erro ao consultar anomalias: {e}")
        return []

def log_action_feedback(
    anomaly_id: int,
    action_type: str,
    action_description: str,
    priority: str = "medium",
    assigned_to: Optional[str] = None
) -> Dict[str, Any]:
    """
    Registrar feedback de ação tomada.

    Args:
        anomaly_id: ID da anomalia
        action_type: Tipo de ação (alert, maintenance, etc.)
        action_description: Descrição da ação
        priority: Prioridade da ação
        assigned_to: Pessoa designada para a ação

    Returns:
        Dados da ação registrada
    """
    try:
        with SessionLocal() as db:
            action = ActionFeedback(
                anomaly_id=anomaly_id,
                action_type=action_type,
                action_description=action_description,
                priority=priority,
                assigned_to=assigned_to
            )

            db.add(action)
            db.commit()
            db.refresh(action)

            result = {
                "id": action.id,
                "anomaly_id": action.anomaly_id,
                "action_type": action.action_type,
                "priority": action.priority,
                "status": action.status,
                "created_at": action.created_at.isoformat()
            }

            logger.info(f"Ação registrada com ID: {action.id}")
            return result

    except Exception as e:
        logger.error(f"Erro ao registrar ação: {e}")
        return {}

def send_sms_alert(phone_number: str, message: str) -> bool:
    """
    Enviar alerta via SMS usando Twilio.

    Args:
        phone_number: Número do telefone
        message: Mensagem a ser enviada

    Returns:
        True se enviado com sucesso, False caso contrário
    """
    try:
        if not settings.twilio_sid or not settings.twilio_auth_token:
            logger.warning("Credenciais Twilio não configuradas")
            return False

        client = Client(settings.twilio_sid, settings.twilio_auth_token)

        message = client.messages.create(
            body=message,
            from_=settings.twilio_phone_number,
            to=phone_number
        )

        logger.info(f"SMS enviado com sucesso. SID: {message.sid}")
        return True

    except Exception as e:
        logger.error(f"Erro ao enviar SMS: {e}")
        return False

def send_whatsapp_alert(phone_number: str, message: str) -> bool:
    """
    Enviar alerta via WhatsApp usando Twilio.

    Args:
        phone_number: Número do WhatsApp
        message: Mensagem a ser enviada

    Returns:
        True se enviado com sucesso, False caso contrário
    """
    try:
        if not settings.twilio_sid or not settings.twilio_auth_token:
            logger.warning("Credenciais Twilio não configuradas")
            return False

        client = Client(settings.twilio_sid, settings.twilio_auth_token)

        message = client.messages.create(
            body=message,
            from_=settings.whatsapp_phone_number,
            to=f"whatsapp:{phone_number}"
        )

        logger.info(f"WhatsApp enviado com sucesso. SID: {message.sid}")
        return True

    except Exception as e:
        logger.error(f"Erro ao enviar WhatsApp: {e}")
        return False

def send_email_alert(
    to_email: str,
    subject: str,
    body: str,
    is_html: bool = False
) -> bool:
    """
    Enviar alerta via email.

    Args:
        to_email: Email do destinatário
        subject: Assunto do email
        body: Corpo do email
        is_html: Se o corpo é HTML

    Returns:
        True se enviado com sucesso, False caso contrário
    """
    try:
        if not settings.smtp_user or not settings.smtp_password:
            logger.warning("Credenciais SMTP não configuradas")
            return False

        msg = MIMEMultipart()
        msg['From'] = settings.smtp_user
        msg['To'] = to_email
        msg['Subject'] = subject

        msg.attach(MIMEText(body, 'html' if is_html else 'plain'))

        server = smtplib.SMTP(settings.smtp_host, settings.smtp_port)
        server.starttls()
        server.login(settings.smtp_user, settings.smtp_password)

        text = msg.as_string()
        server.sendmail(settings.smtp_user, to_email, text)
        server.quit()

        logger.info(f"Email enviado com sucesso para {to_email}")
        return True

    except Exception as e:
        logger.error(f"Erro ao enviar email: {e}")
        return False

def get_system_status() -> Dict[str, Any]:
    """
    Obter status geral do sistema.

    Returns:
        Dicionário com informações de status
    """
    try:
        with SessionLocal() as db:
            now = datetime.utcnow()
            one_hour_ago = now - timedelta(hours=1)
            one_day_ago = now - timedelta(days=1)

            status = {
                "timestamp": now.isoformat(),
                "database": {
                    "connected": True,
                    "total_sensors": db.query(SensorData).count(),
                    "recent_data": db.query(SensorData).filter(
                        SensorData.timestamp >= one_hour_ago
                    ).count()
                },
                "anomalies": {
                    "total": db.query(AnomalyEvent).count(),
                    "last_24h": db.query(AnomalyEvent).filter(
                        AnomalyEvent.detected_at >= one_day_ago
                    ).count(),
                    "unresolved": db.query(AnomalyEvent).filter(
                        AnomalyEvent.status != "resolved"
                    ).count()
                },
                "actions": {
                    "total": db.query(ActionFeedback).count(),
                    "pending": db.query(ActionFeedback).filter(
                        ActionFeedback.status == "pending"
                    ).count()
                }
            }

            return status

    except Exception as e:
        logger.error(f"Erro ao obter status do sistema: {e}")
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "error": str(e),
            "database": {"connected": False}
        }
