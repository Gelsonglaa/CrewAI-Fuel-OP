"""
Módulo de gerenciamento de banco de dados para o sistema CrewAI Fuel OP.
Inclui modelos ORM, inicialização e gerenciamento de sessões.
"""

import logging
from datetime import datetime
from typing import Optional, List
from sqlalchemy import create_engine, Column, Integer, Float, String, DateTime, Boolean, Text, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.sql import func

from .config import settings

logger = logging.getLogger(__name__)

# Configuração do engine
engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False} if "sqlite" in settings.database_url else {},
    echo=settings.debug
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class SensorData(Base):
    """Modelo para dados dos sensores."""
    __tablename__ = "sensor_data"

    id = Column(Integer, primary_key=True, index=True)
    station_id = Column(String(50), nullable=False, index=True)
    sensor_type = Column(String(50), nullable=False, index=True)
    value = Column(Float, nullable=False)
    unit = Column(String(20), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    quality_score = Column(Float, default=1.0)  # Score de qualidade do dado
    is_processed = Column(Boolean, default=False, index=True)

    # Índices compostos para otimizar consultas
    __table_args__ = (
        Index('idx_station_time', 'station_id', 'timestamp'),
        Index('idx_sensor_time', 'sensor_type', 'timestamp'),
        Index('idx_processed_time', 'is_processed', 'timestamp'),
    )

class AnomalyEvent(Base):
    """Modelo para eventos de anomalia."""
    __tablename__ = "anomaly_events"

    id = Column(Integer, primary_key=True, index=True)
    station_id = Column(String(50), nullable=False, index=True)
    sensor_type = Column(String(50), nullable=False, index=True)
    anomaly_score = Column(Float, nullable=False)
    threshold = Column(Float, nullable=False)
    sensor_value = Column(Float, nullable=False)
    expected_value = Column(Float, nullable=True)
    severity = Column(String(20), nullable=False, default="medium")  # low, medium, high, critical
    status = Column(String(20), nullable=False, default="detected", index=True)  # detected, investigating, resolved
    description = Column(Text, nullable=True)
    detected_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    resolved_at = Column(DateTime, nullable=True)

    # Índices para otimizar consultas de anomalias
    __table_args__ = (
        Index('idx_station_detected', 'station_id', 'detected_at'),
        Index('idx_severity_status', 'severity', 'status'),
    )

class ActionFeedback(Base):
    """Modelo para feedback de ações tomadas."""
    __tablename__ = "action_feedback"

    id = Column(Integer, primary_key=True, index=True)
    anomaly_id = Column(Integer, nullable=False, index=True)  # FK para AnomalyEvent
    action_type = Column(String(50), nullable=False)  # alert, maintenance, shutdown, etc.
    action_description = Column(Text, nullable=False)
    status = Column(String(20), nullable=False, default="pending")  # pending, completed, failed
    priority = Column(String(20), nullable=False, default="medium")
    assigned_to = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    completed_at = Column(DateTime, nullable=True)
    feedback = Column(Text, nullable=True)
    effectiveness_score = Column(Float, nullable=True)  # Score de efetividade da ação

class SystemMetrics(Base):
    """Modelo para métricas do sistema."""
    __tablename__ = "system_metrics"

    id = Column(Integer, primary_key=True, index=True)
    metric_name = Column(String(100), nullable=False, index=True)
    metric_value = Column(Float, nullable=False)
    metric_type = Column(String(50), nullable=False)  # counter, gauge, histogram
    tags = Column(Text, nullable=True)  # JSON com tags adicionais
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

def get_db() -> Session:
    """Dependency para obter sessão do banco de dados."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_database() -> None:
    """Inicializar banco de dados criando todas as tabelas."""
    try:
        logger.info("Inicializando banco de dados...")
        Base.metadata.create_all(bind=engine)
        logger.info("Banco de dados inicializado com sucesso")

        # Verificar se há dados de exemplo para criar
        with SessionLocal() as db:
            sensor_count = db.query(SensorData).count()
            if sensor_count == 0:
                logger.info("Criando dados de exemplo...")
                create_sample_data(db)

    except Exception as e:
        logger.error(f"Erro ao inicializar banco de dados: {e}")
        raise

def create_sample_data(db: Session) -> None:
    """Criar dados de exemplo para desenvolvimento."""
    from datetime import datetime, timedelta
    import random

    stations = ["STATION_001", "STATION_002", "STATION_003"]
    sensor_types = ["fuel_level", "pressure", "temperature", "flow_rate"]

    base_time = datetime.utcnow() - timedelta(days=7)

    for i in range(1000):  # 1000 registros de exemplo
        for station in stations:
            for sensor_type in sensor_types:
                # Gerar valor baseado no tipo de sensor
                if sensor_type == "fuel_level":
                    value = random.uniform(20, 100)  # %
                    unit = "percent"
                elif sensor_type == "pressure":
                    value = random.uniform(1.0, 5.0)  # bar
                    unit = "bar"
                elif sensor_type == "temperature":
                    value = random.uniform(15, 40)  # °C
                    unit = "celsius"
                else:  # flow_rate
                    value = random.uniform(0, 100)  # L/min
                    unit = "L/min"

                sensor_data = SensorData(
                    station_id=station,
                    sensor_type=sensor_type,
                    value=value,
                    unit=unit,
                    timestamp=base_time + timedelta(minutes=i*5),
                    quality_score=random.uniform(0.8, 1.0)
                )
                db.add(sensor_data)

    # Criar algumas anomalias de exemplo
    for i in range(20):
        anomaly = AnomalyEvent(
            station_id=random.choice(stations),
            sensor_type=random.choice(sensor_types),
            anomaly_score=random.uniform(0.7, 0.95),
            threshold=0.7,
            sensor_value=random.uniform(0, 100),
            severity=random.choice(["medium", "high"]),
            detected_at=base_time + timedelta(hours=i)
        )
        db.add(anomaly)

    db.commit()
    logger.info("Dados de exemplo criados com sucesso")

def get_database_stats() -> dict:
    """Obter estatísticas do banco de dados."""
    with SessionLocal() as db:
        stats = {
            "sensor_data_count": db.query(SensorData).count(),
            "anomaly_events_count": db.query(AnomalyEvent).count(),
            "action_feedback_count": db.query(ActionFeedback).count(),
            "unresolved_anomalies": db.query(AnomalyEvent).filter(
                AnomalyEvent.status != "resolved"
            ).count(),
            "recent_sensor_data": db.query(SensorData).filter(
                SensorData.timestamp >= datetime.utcnow() - timedelta(hours=24)
            ).count()
        }
    return stats

# Inicializar banco de dados ao importar o módulo
if __name__ != "__main__":
    init_database()
