"""
Serviço de detecção de anomalias otimizado para o sistema CrewAI Fuel OP.
Utiliza Isolation Forest para detectar padrões anômalos nos dados dos sensores.
"""

import logging
import numpy as np
import pandas as pd
import joblib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

from ..core.config import settings
from ..core.database import SessionLocal, SensorData

logger = logging.getLogger(__name__)

class AnomalyDetectionService:
    """
    Serviço de detecção de anomalias usando Isolation Forest.
    """

    def __init__(self):
        self.model = None
        self.scaler = None
        self.feature_columns = [
            'value', 'quality_score', 'hour', 'day_of_week', 
            'value_lag1', 'value_lag2', 'value_rolling_mean', 'value_rolling_std'
        ]
        self.model_path = Path("app/ml/models/anomaly_detector.joblib")
        self.scaler_path = Path("app/ml/models/anomaly_scaler.joblib")

        # Carregar modelo existente ou treinar novo
        self.load_model()

    def create_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Criar features para detecção de anomalias.

        Args:
            df: DataFrame com dados dos sensores

        Returns:
            DataFrame com features engineered
        """
        try:
            # Converter timestamp para datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'])

            # Features temporais
            df['hour'] = df['timestamp'].dt.hour
            df['day_of_week'] = df['timestamp'].dt.dayofweek

            # Ordenar por timestamp
            df = df.sort_values('timestamp')

            # Features de lag
            df['value_lag1'] = df['value'].shift(1)
            df['value_lag2'] = df['value'].shift(2)

            # Features de rolling window
            df['value_rolling_mean'] = df['value'].rolling(window=5, min_periods=1).mean()
            df['value_rolling_std'] = df['value'].rolling(window=5, min_periods=1).std()

            # Preencher valores NaN
            df = df.fillna(method='forward').fillna(method='backward')

            # Retornar apenas features necessárias
            return df[self.feature_columns].copy()

        except Exception as e:
            logger.error(f"Erro ao criar features: {e}")
            return pd.DataFrame()

    def train_model(self, contamination: float = 0.1) -> bool:
        """
        Treinar modelo de detecção de anomalias.

        Args:
            contamination: Proporção esperada de anomalias

        Returns:
            True se treinamento bem-sucedido
        """
        try:
            logger.info("Iniciando treinamento do modelo de detecção de anomalias...")

            # Carregar dados de treinamento
            with SessionLocal() as db:
                query = db.query(SensorData).order_by(SensorData.timestamp.desc()).limit(10000)
                results = query.all()

                if len(results) < 100:
                    logger.warning("Poucos dados para treinamento, criando dados sintéticos...")
                    self._create_synthetic_data(db)
                    results = query.all()

                # Converter para DataFrame
                data = []
                for result in results:
                    data.append({
                        'station_id': result.station_id,
                        'sensor_type': result.sensor_type,
                        'value': result.value,
                        'quality_score': result.quality_score,
                        'timestamp': result.timestamp
                    })

                df = pd.DataFrame(data)

            # Criar features
            features_df = self.create_features(df)

            if features_df.empty:
                logger.error("Erro ao criar features para treinamento")
                return False

            # Treinar scaler
            self.scaler = StandardScaler()
            features_scaled = self.scaler.fit_transform(features_df)

            # Treinar modelo
            self.model = IsolationForest(
                contamination=contamination,
                random_state=42,
                n_estimators=100,
                max_samples='auto',
                max_features=1.0,
                bootstrap=False,
                n_jobs=-1
            )

            self.model.fit(features_scaled)

            # Salvar modelo e scaler
            self.model_path.parent.mkdir(parents=True, exist_ok=True)
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.scaler_path)

            logger.info("Modelo de detecção de anomalias treinado com sucesso!")
            return True

        except Exception as e:
            logger.error(f"Erro no treinamento do modelo: {e}")
            return False

    def load_model(self) -> bool:
        """
        Carregar modelo treinado.

        Returns:
            True se carregamento bem-sucedido
        """
        try:
            if self.model_path.exists() and self.scaler_path.exists():
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                logger.info("Modelo de detecção de anomalias carregado com sucesso")
                return True
            else:
                logger.info("Modelo não encontrado, treinando novo modelo...")
                return self.train_model()

        except Exception as e:
            logger.error(f"Erro ao carregar modelo: {e}")
            return self.train_model()

    def predict(self, sensor_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Detectar anomalia em um único ponto de dados.

        Args:
            sensor_data: Dados do sensor

        Returns:
            Resultado da detecção
        """
        try:
            if not self.model or not self.scaler:
                logger.error("Modelo não carregado")
                return {"error": "Modelo não carregado"}

            # Converter para DataFrame
            df = pd.DataFrame([sensor_data])

            # Criar features
            features_df = self.create_features(df)

            if features_df.empty:
                return {"error": "Erro ao criar features"}

            # Normalizar
            features_scaled = self.scaler.transform(features_df)

            # Fazer predição
            prediction = self.model.predict(features_scaled)[0]
            score = self.model.score_samples(features_scaled)[0]

            # Interpretar resultado
            is_anomaly = prediction == -1
            anomaly_score = abs(score)  # Quanto mais negativo, mais anômalo

            # Determinar severidade
            if anomaly_score > 0.6:
                severity = "high"
            elif anomaly_score > 0.4:
                severity = "medium"
            else:
                severity = "low"

            result = {
                "is_anomaly": is_anomaly,
                "anomaly_score": float(anomaly_score),
                "severity": severity,
                "threshold": settings.anomaly_threshold,
                "timestamp": datetime.utcnow().isoformat()
            }

            return result

        except Exception as e:
            logger.error(f"Erro na predição de anomalia: {e}")
            return {"error": str(e)}

    def predict_batch(self, sensor_data_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detectar anomalias em lote.

        Args:
            sensor_data_list: Lista de dados dos sensores

        Returns:
            Lista de resultados de detecção
        """
        try:
            if not self.model or not self.scaler:
                logger.error("Modelo não carregado")
                return []

            # Converter para DataFrame
            df = pd.DataFrame(sensor_data_list)

            # Criar features
            features_df = self.create_features(df)

            if features_df.empty:
                return []

            # Normalizar
            features_scaled = self.scaler.transform(features_df)

            # Fazer predições
            predictions = self.model.predict(features_scaled)
            scores = self.model.score_samples(features_scaled)

            # Processar resultados
            results = []
            for i, (prediction, score) in enumerate(zip(predictions, scores)):
                is_anomaly = prediction == -1
                anomaly_score = abs(score)

                # Determinar severidade
                if anomaly_score > 0.6:
                    severity = "high"
                elif anomaly_score > 0.4:
                    severity = "medium"
                else:
                    severity = "low"

                results.append({
                    "index": i,
                    "is_anomaly": is_anomaly,
                    "anomaly_score": float(anomaly_score),
                    "severity": severity,
                    "threshold": settings.anomaly_threshold
                })

            return results

        except Exception as e:
            logger.error(f"Erro na predição em lote: {e}")
            return []

    def _create_synthetic_data(self, db) -> None:
        """
        Criar dados sintéticos para treinamento.

        Args:
            db: Sessão do banco de dados
        """
        try:
            logger.info("Criando dados sintéticos para treinamento...")

            import random
            from datetime import datetime, timedelta

            stations = ["STATION_001", "STATION_002", "STATION_003"]
            sensor_types = ["fuel_level", "pressure", "temperature", "flow_rate"]

            base_time = datetime.utcnow() - timedelta(days=30)

            for i in range(5000):
                for station in stations:
                    for sensor_type in sensor_types:
                        # Gerar valor baseado no tipo de sensor
                        if sensor_type == "fuel_level":
                            value = random.uniform(20, 100)
                            unit = "percent"
                        elif sensor_type == "pressure":
                            value = random.uniform(1.0, 5.0)
                            unit = "bar"
                        elif sensor_type == "temperature":
                            value = random.uniform(15, 40)
                            unit = "celsius"
                        else:  # flow_rate
                            value = random.uniform(0, 100)
                            unit = "L/min"

                        # Adicionar algumas anomalias
                        if random.random() < 0.05:  # 5% de anomalias
                            value *= random.uniform(0.3, 3.0)  # Multiplicar por fator anômalo

                        sensor_data = SensorData(
                            station_id=station,
                            sensor_type=sensor_type,
                            value=value,
                            unit=unit,
                            timestamp=base_time + timedelta(minutes=i*2),
                            quality_score=random.uniform(0.7, 1.0)
                        )
                        db.add(sensor_data)

            db.commit()
            logger.info("Dados sintéticos criados com sucesso")

        except Exception as e:
            logger.error(f"Erro ao criar dados sintéticos: {e}")

    def get_model_info(self) -> Dict[str, Any]:
        """
        Obter informações sobre o modelo.

        Returns:
            Informações do modelo
        """
        try:
            if not self.model:
                return {"error": "Modelo não carregado"}

            return {
                "model_type": "IsolationForest",
                "n_estimators": self.model.n_estimators,
                "contamination": self.model.contamination,
                "features": self.feature_columns,
                "model_path": str(self.model_path),
                "scaler_path": str(self.scaler_path),
                "last_trained": datetime.utcnow().isoformat()
            }

        except Exception as e:
            logger.error(f"Erro ao obter informações do modelo: {e}")
            return {"error": str(e)}

# Instância global do serviço
anomaly_service = AnomalyDetectionService()

def detect_anomaly(sensor_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Função helper para detectar anomalia.

    Args:
        sensor_data: Dados do sensor

    Returns:
        Resultado da detecção
    """
    return anomaly_service.predict(sensor_data)

def detect_anomalies_batch(sensor_data_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Função helper para detectar anomalias em lote.

    Args:
        sensor_data_list: Lista de dados dos sensores

    Returns:
        Lista de resultados
    """
    return anomaly_service.predict_batch(sensor_data_list)
