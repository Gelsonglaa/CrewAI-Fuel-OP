"""
Serviço de previsão de demanda otimizado para o sistema CrewAI Fuel OP.
Utiliza Random Forest para prever consumo futuro de combustível.
"""

import logging
import numpy as np
import pandas as pd
import joblib
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

from ..core.config import settings
from ..core.database import SessionLocal, SensorData

logger = logging.getLogger(__name__)

class DemandForecastingService:
    """
    Serviço de previsão de demanda usando Random Forest.
    """

    def __init__(self):
        self.model = None
        self.scaler = None
        self.feature_columns = [
            'hour', 'day_of_week', 'month', 'is_weekend',
            'fuel_level_lag1', 'fuel_level_lag2', 'fuel_level_lag3',
            'flow_rate_mean', 'temperature_mean', 'pressure_mean',
            'fuel_level_rolling_mean', 'fuel_level_rolling_std'
        ]
        self.model_path = Path("app/ml/models/demand_forecaster.joblib")
        self.scaler_path = Path("app/ml/models/demand_scaler.joblib")

        # Carregar modelo existente ou treinar novo
        self.load_model()

    def create_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Criar features para previsão de demanda.

        Args:
            df: DataFrame com dados dos sensores

        Returns:
            DataFrame com features engineered
        """
        try:
            # Converter timestamp para datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'])

            # Pivot para ter sensores como colunas
            df_pivot = df.pivot_table(
                index=['station_id', 'timestamp'],
                columns='sensor_type',
                values='value',
                aggfunc='mean'
            ).reset_index()

            # Features temporais
            df_pivot['hour'] = df_pivot['timestamp'].dt.hour
            df_pivot['day_of_week'] = df_pivot['timestamp'].dt.dayofweek
            df_pivot['month'] = df_pivot['timestamp'].dt.month
            df_pivot['is_weekend'] = (df_pivot['day_of_week'] >= 5).astype(int)

            # Ordenar por timestamp
            df_pivot = df_pivot.sort_values(['station_id', 'timestamp'])

            # Features de lag para fuel_level
            df_pivot['fuel_level_lag1'] = df_pivot.groupby('station_id')['fuel_level'].shift(1)
            df_pivot['fuel_level_lag2'] = df_pivot.groupby('station_id')['fuel_level'].shift(2)
            df_pivot['fuel_level_lag3'] = df_pivot.groupby('station_id')['fuel_level'].shift(3)

            # Features agregadas
            df_pivot['flow_rate_mean'] = df_pivot.get('flow_rate', 0)
            df_pivot['temperature_mean'] = df_pivot.get('temperature', 0)
            df_pivot['pressure_mean'] = df_pivot.get('pressure', 0)

            # Features de rolling window
            df_pivot['fuel_level_rolling_mean'] = df_pivot.groupby('station_id')['fuel_level'].rolling(
                window=5, min_periods=1
            ).mean().reset_index(level=0, drop=True)

            df_pivot['fuel_level_rolling_std'] = df_pivot.groupby('station_id')['fuel_level'].rolling(
                window=5, min_periods=1
            ).std().reset_index(level=0, drop=True)

            # Preencher valores NaN
            df_pivot = df_pivot.fillna(method='forward').fillna(0)

            # Retornar apenas features necessárias
            feature_df = df_pivot[self.feature_columns].copy()
            return feature_df

        except Exception as e:
            logger.error(f"Erro ao criar features: {e}")
            return pd.DataFrame()

    def train_model(self) -> bool:
        """
        Treinar modelo de previsão de demanda.

        Returns:
            True se treinamento bem-sucedido
        """
        try:
            logger.info("Iniciando treinamento do modelo de previsão de demanda...")

            # Carregar dados de treinamento
            with SessionLocal() as db:
                query = db.query(SensorData).order_by(SensorData.timestamp.desc()).limit(20000)
                results = query.all()

                if len(results) < 500:
                    logger.warning("Poucos dados para treinamento, criando dados sintéticos...")
                    self._create_synthetic_data(db)
                    results = query.all()

                # Converter para DataFrame
                data = []
                for result in results:
                    data.append({
                        'station_id': result.station_id,
                        'sensor_type': result.sensor_type,
                        'value': result.value,
                        'timestamp': result.timestamp
                    })

                df = pd.DataFrame(data)

            # Filtrar apenas dados de fuel_level para criar target
            fuel_data = df[df['sensor_type'] == 'fuel_level'].copy()

            if len(fuel_data) < 100:
                logger.error("Dados insuficientes de fuel_level")
                return False

            # Criar features
            features_df = self.create_features(df)

            if features_df.empty:
                logger.error("Erro ao criar features para treinamento")
                return False

            # Criar target (consumo de combustível)
            fuel_pivot = fuel_data.pivot_table(
                index=['station_id', 'timestamp'],
                values='value',
                aggfunc='mean'
            ).reset_index()

            fuel_pivot = fuel_pivot.sort_values(['station_id', 'timestamp'])
            fuel_pivot['fuel_consumption'] = fuel_pivot.groupby('station_id')['value'].diff().abs()

            # Alinhar features com target
            target_df = fuel_pivot[['station_id', 'timestamp', 'fuel_consumption']].copy()
            target_df = target_df.dropna()

            # Merge features com target
            combined_df = pd.merge(
                features_df.reset_index(),
                target_df,
                left_on=['station_id', 'timestamp'],
                right_on=['station_id', 'timestamp'],
                how='inner'
            )

            if len(combined_df) < 50:
                logger.error("Dados insuficientes após merge")
                return False

            # Separar features e target
            X = combined_df[self.feature_columns]
            y = combined_df['fuel_consumption']

            # Split train/test
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )

            # Treinar scaler
            self.scaler = StandardScaler()
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)

            # Treinar modelo com Grid Search
            param_grid = {
                'n_estimators': [100, 200],
                'max_depth': [10, 20, None],
                'min_samples_split': [2, 5],
                'min_samples_leaf': [1, 2]
            }

            rf = RandomForestRegressor(random_state=42, n_jobs=-1)
            grid_search = GridSearchCV(rf, param_grid, cv=3, scoring='r2', n_jobs=-1)
            grid_search.fit(X_train_scaled, y_train)

            self.model = grid_search.best_estimator_

            # Avaliar modelo
            y_pred = self.model.predict(X_test_scaled)
            mse = mean_squared_error(y_test, y_pred)
            mae = mean_absolute_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)

            logger.info(f"Modelo treinado - MSE: {mse:.4f}, MAE: {mae:.4f}, R2: {r2:.4f}")

            # Salvar modelo e scaler
            self.model_path.parent.mkdir(parents=True, exist_ok=True)
            joblib.dump(self.model, self.model_path)
            joblib.dump(self.scaler, self.scaler_path)

            logger.info("Modelo de previsão de demanda treinado com sucesso!")
            return True

        except Exception as e:
            logger.error(f"Erro no treinamento do modelo: {e}")
            return False

    def load_model(self) -> bool:
        """
        Carregar modelo treinado.

        Returns:
            True se carregamento bem-sucedido
        """
        try:
            if self.model_path.exists() and self.scaler_path.exists():
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                logger.info("Modelo de previsão de demanda carregado com sucesso")
                return True
            else:
                logger.info("Modelo não encontrado, treinando novo modelo...")
                return self.train_model()

        except Exception as e:
            logger.error(f"Erro ao carregar modelo: {e}")
            return self.train_model()

    def predict_demand(self, hours_ahead: int = 24, station_id: str = "STATION_001") -> Dict[str, Any]:
        """
        Prever demanda de combustível.

        Args:
            hours_ahead: Horas para prever à frente
            station_id: ID da estação

        Returns:
            Previsão de demanda
        """
        try:
            if not self.model or not self.scaler:
                logger.error("Modelo não carregado")
                return {"error": "Modelo não carregado"}

            # Obter dados recentes para criar features
            with SessionLocal() as db:
                query = db.query(SensorData).filter(
                    SensorData.station_id == station_id
                ).order_by(SensorData.timestamp.desc()).limit(100)

                results = query.all()

                if not results:
                    return {"error": "Dados insuficientes para previsão"}

                # Converter para DataFrame
                data = []
                for result in results:
                    data.append({
                        'station_id': result.station_id,
                        'sensor_type': result.sensor_type,
                        'value': result.value,
                        'timestamp': result.timestamp
                    })

                df = pd.DataFrame(data)

            # Criar features
            features_df = self.create_features(df)

            if features_df.empty:
                return {"error": "Erro ao criar features"}

            # Usar último registro como base
            last_features = features_df.iloc[-1:].copy()

            predictions = []
            current_time = datetime.utcnow()

            for h in range(hours_ahead):
                future_time = current_time + timedelta(hours=h)

                # Atualizar features temporais
                last_features['hour'] = future_time.hour
                last_features['day_of_week'] = future_time.weekday()
                last_features['month'] = future_time.month
                last_features['is_weekend'] = int(future_time.weekday() >= 5)

                # Normalizar features
                features_scaled = self.scaler.transform(last_features)

                # Fazer predição
                prediction = self.model.predict(features_scaled)[0]

                predictions.append({
                    "hour": h + 1,
                    "timestamp": future_time.isoformat(),
                    "predicted_consumption": float(max(0, prediction)),  # Não pode ser negativo
                    "confidence": "medium"  # Placeholder para confiança
                })

            result = {
                "station_id": station_id,
                "predictions": predictions,
                "total_predicted_consumption": sum(p["predicted_consumption"] for p in predictions),
                "generated_at": datetime.utcnow().isoformat()
            }

            return result

        except Exception as e:
            logger.error(f"Erro na previsão de demanda: {e}")
            return {"error": str(e)}

    def _create_synthetic_data(self, db) -> None:
        """
        Criar dados sintéticos para treinamento.

        Args:
            db: Sessão do banco de dados
        """
        try:
            logger.info("Criando dados sintéticos para treinamento...")

            import random
            from datetime import datetime, timedelta

            stations = ["STATION_001", "STATION_002", "STATION_003"]
            sensor_types = ["fuel_level", "pressure", "temperature", "flow_rate"]

            base_time = datetime.utcnow() - timedelta(days=30)

            for i in range(2000):
                for station in stations:
                    for sensor_type in sensor_types:
                        # Gerar valor baseado no tipo de sensor
                        if sensor_type == "fuel_level":
                            # Simular consumo gradual com reabastecimentos
                            base_value = 70 + 20 * np.sin(i * 0.1)  # Padrão cíclico
                            if i % 100 == 0:  # Reabastecimento
                                base_value = 95
                            value = max(10, base_value + random.uniform(-10, 10))
                            unit = "percent"
                        elif sensor_type == "pressure":
                            value = random.uniform(1.5, 4.5)
                            unit = "bar"
                        elif sensor_type == "temperature":
                            value = 25 + 10 * np.sin(i * 0.05) + random.uniform(-5, 5)
                            unit = "celsius"
                        else:  # flow_rate
                            # Simular padrão de consumo baseado na hora
                            hour = (base_time + timedelta(hours=i)).hour
                            if 7 <= hour <= 19:  # Dia
                                value = random.uniform(30, 80)
                            else:  # Noite
                                value = random.uniform(5, 30)
                            unit = "L/min"

                        sensor_data = SensorData(
                            station_id=station,
                            sensor_type=sensor_type,
                            value=value,
                            unit=unit,
                            timestamp=base_time + timedelta(hours=i),
                            quality_score=random.uniform(0.8, 1.0)
                        )
                        db.add(sensor_data)

            db.commit()
            logger.info("Dados sintéticos criados com sucesso")

        except Exception as e:
            logger.error(f"Erro ao criar dados sintéticos: {e}")

    def get_model_info(self) -> Dict[str, Any]:
        """
        Obter informações sobre o modelo.

        Returns:
            Informações do modelo
        """
        try:
            if not self.model:
                return {"error": "Modelo não carregado"}

            return {
                "model_type": "RandomForestRegressor",
                "n_estimators": self.model.n_estimators,
                "max_depth": self.model.max_depth,
                "features": self.feature_columns,
                "model_path": str(self.model_path),
                "scaler_path": str(self.scaler_path),
                "last_trained": datetime.utcnow().isoformat()
            }

        except Exception as e:
            logger.error(f"Erro ao obter informações do modelo: {e}")
            return {"error": str(e)}

# Instância global do serviço
demand_service = DemandForecastingService()

def predict_fuel_demand(hours_ahead: int = 24, station_id: str = "STATION_001") -> Dict[str, Any]:
    """
    Função helper para prever demanda de combustível.

    Args:
        hours_ahead: Horas para prever
        station_id: ID da estação

    Returns:
        Previsão de demanda
    """
    return demand_service.predict_demand(hours_ahead, station_id)
