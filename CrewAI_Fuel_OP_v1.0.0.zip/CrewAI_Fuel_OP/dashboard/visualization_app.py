"""
Dashboard Streamlit otimizado para o sistema CrewAI Fuel OP.
Interface web interativa para monitoramento em tempo real.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import requests
import time
from datetime import datetime, timedelta
import json
from typing import Dict, List, Any, Optional

# Configuração da página
st.set_page_config(
    page_title="CrewAI Fuel OP Dashboard",
    page_icon="⛽",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Configurações
API_BASE_URL = "http://localhost:8000"  # Alterar conforme necessário
REFRESH_INTERVAL = 30  # segundos

class APIClient:
    """Cliente para comunicação com a API."""

    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()

    def get(self, endpoint: str, params: Dict = None) -> Dict:
        """Fazer requisição GET."""
        try:
            url = f"{self.base_url}{endpoint}"
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            st.error(f"Erro na API: {e}")
            return {}

    def post(self, endpoint: str, data: Dict = None) -> Dict:
        """Fazer requisição POST."""
        try:
            url = f"{self.base_url}{endpoint}"
            response = self.session.post(url, json=data, timeout=30)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            st.error(f"Erro na API: {e}")
            return {}

# Inicializar cliente da API
@st.cache_resource
def get_api_client():
    return APIClient(API_BASE_URL)

api = get_api_client()

# Funções utilitárias
@st.cache_data(ttl=30)
def load_dashboard_stats():
    """Carregar estatísticas do dashboard."""
    return api.get("/stats/dashboard")

@st.cache_data(ttl=60)
def load_stations():
    """Carregar lista de estações."""
    return api.get("/stations")

@st.cache_data(ttl=30)
def load_anomalies(station_id=None, severity=None):
    """Carregar anomalias."""
    params = {}
    if station_id:
        params["station_id"] = station_id
    if severity:
        params["severity"] = severity
    return api.get("/anomalies", params=params)

@st.cache_data(ttl=30)
def load_sensor_data(station_id, hours_back=24):
    """Carregar dados de sensores."""
    return api.get(f"/sensor-data/{station_id}", {"hours_back": hours_back})

def create_gauge_chart(value: float, title: str, max_value: float = 100, unit: str = "") -> go.Figure:
    """Criar gráfico de gauge."""
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=value,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': title},
        delta={'reference': max_value * 0.8},
        gauge={
            'axis': {'range': [None, max_value]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, max_value * 0.5], 'color': "lightgray"},
                {'range': [max_value * 0.5, max_value * 0.8], 'color': "gray"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': max_value * 0.9
            }
        }
    ))

    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=300
    )

    return fig

def create_time_series_chart(data: List[Dict], title: str) -> go.Figure:
    """Criar gráfico de série temporal."""
    if not data:
        return go.Figure().add_annotation(
            text="Sem dados disponíveis",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False
        )

    df = pd.DataFrame(data)
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Agrupar por sensor_type
    fig = go.Figure()

    for sensor_type in df['sensor_type'].unique():
        sensor_data = df[df['sensor_type'] == sensor_type]
        fig.add_trace(go.Scatter(
            x=sensor_data['timestamp'],
            y=sensor_data['value'],
            name=sensor_type,
            mode='lines+markers',
            line=dict(width=2),
            marker=dict(size=4)
        ))

    fig.update_layout(
        title=title,
        xaxis_title="Timestamp",
        yaxis_title="Valor",
        height=400,
        showlegend=True,
        hovermode='x unified'
    )

    return fig

def create_anomaly_chart(anomalies: List[Dict]) -> go.Figure:
    """Criar gráfico de anomalias."""
    if not anomalies:
        return go.Figure().add_annotation(
            text="Nenhuma anomalia encontrada",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False
        )

    df = pd.DataFrame(anomalies)
    df['detected_at'] = pd.to_datetime(df['detected_at'])

    # Mapear severidade para cores
    severity_colors = {
        'low': 'green',
        'medium': 'orange', 
        'high': 'red',
        'critical': 'darkred'
    }

    df['color'] = df['severity'].map(severity_colors)

    fig = go.Figure()

    for severity in df['severity'].unique():
        severity_data = df[df['severity'] == severity]
        fig.add_trace(go.Scatter(
            x=severity_data['detected_at'],
            y=severity_data['anomaly_score'],
            mode='markers',
            name=f"Severidade: {severity}",
            marker=dict(
                color=severity_colors.get(severity, 'blue'),
                size=10,
                opacity=0.7
            ),
            text=severity_data.apply(lambda row: 
                f"Estação: {row['station_id']}<br>"
                f"Sensor: {row['sensor_type']}<br>"
                f"Score: {row['anomaly_score']:.3f}<br>"
                f"Valor: {row['sensor_value']}", axis=1),
            hovertemplate="%{text}<extra></extra>"
        ))

    fig.update_layout(
        title="Anomalias Detectadas ao Longo do Tempo",
        xaxis_title="Data/Hora",
        yaxis_title="Score de Anomalia",
        height=400,
        showlegend=True
    )

    return fig

# Interface principal
def main():
    st.title("⛽ CrewAI Fuel OP Dashboard")
    st.markdown("---")

    # Sidebar para controles
    with st.sidebar:
        st.header("🔧 Controles")

        # Auto-refresh
        auto_refresh = st.checkbox("Auto-refresh", value=True)
        if auto_refresh:
            refresh_interval = st.slider("Intervalo (s)", 10, 300, REFRESH_INTERVAL)

        st.markdown("---")

        # Filtros
        st.header("🔍 Filtros")

        # Carregar estações
        stations_data = load_stations()
        station_options = ["Todas"] + [s["station_id"] for s in stations_data.get("stations", [])]
        selected_station = st.selectbox("Estação", station_options)

        # Filtro de severidade
        severity_options = ["Todas", "low", "medium", "high", "critical"]
        selected_severity = st.selectbox("Severidade", severity_options)

        # Período de tempo
        time_range = st.selectbox("Período", ["1h", "6h", "24h", "7d"], index=2)
        hours_map = {"1h": 1, "6h": 6, "24h": 24, "7d": 168}
        hours_back = hours_map[time_range]

        st.markdown("---")

        # Ações de ML
        st.header("🤖 Machine Learning")

        if st.button("🔄 Retreinar Modelo de Anomalias"):
            with st.spinner("Treinando modelo..."):
                result = api.post("/retrain/anomaly-model", {"contamination": 0.1})
                if result:
                    st.success("Modelo retreinado com sucesso!")
                    st.cache_data.clear()

        if st.button("🔄 Retreinar Modelo de Demanda"):
            with st.spinner("Treinando modelo..."):
                result = api.post("/retrain/demand-model")
                if result:
                    st.success("Modelo retreinado com sucesso!")
                    st.cache_data.clear()

    # Carregar dados
    with st.spinner("Carregando dados..."):
        dashboard_data = load_dashboard_stats()

    if not dashboard_data:
        st.error("Erro ao carregar dados do dashboard")
        return

    # Seção de visão geral
    st.header("📊 Visão Geral")

    overview = dashboard_data.get("overview", {})

    col1, col2, col3, col4, col5 = st.columns(5)

    with col1:
        st.metric(
            label="🏭 Estações Ativas", 
            value=overview.get("active_stations", 0),
            delta=None
        )

    with col2:
        st.metric(
            label="📡 Total de Sensores", 
            value=overview.get("total_sensors", 0),
            delta=None
        )

    with col3:
        st.metric(
            label="📈 Dados Recentes", 
            value=overview.get("recent_data_points", 0),
            delta=None
        )

    with col4:
        st.metric(
            label="⚠️ Anomalias Abertas", 
            value=overview.get("unresolved_anomalies", 0),
            delta=None
        )

    with col5:
        # Status geral
        if overview.get("unresolved_anomalies", 0) == 0:
            st.success("✅ Sistema OK")
        elif overview.get("unresolved_anomalies", 0) < 5:
            st.warning("⚠️ Atenção")
        else:
            st.error("🚨 Crítico")

    st.markdown("---")

    # Tabs para diferentes seções
    tab1, tab2, tab3, tab4 = st.tabs(["📈 Sensores", "⚠️ Anomalias", "🔮 Previsões", "⚙️ Sistema"])

    with tab1:
        st.header("📈 Dados dos Sensores")

        if selected_station != "Todas":
            # Dados específicos da estação
            sensor_data = load_sensor_data(selected_station, hours_back)

            if sensor_data.get("sensor_data"):
                # Gráfico de série temporal
                fig = create_time_series_chart(
                    sensor_data["sensor_data"], 
                    f"Dados dos Sensores - {selected_station}"
                )
                st.plotly_chart(fig, use_container_width=True)

                # Tabela de dados recentes
                st.subheader("📋 Dados Recentes")
                df = pd.DataFrame(sensor_data["sensor_data"][:20])
                if not df.empty:
                    df['timestamp'] = pd.to_datetime(df['timestamp'])
                    df = df.sort_values('timestamp', ascending=False)
                    st.dataframe(df, use_container_width=True)
            else:
                st.info("Nenhum dado encontrado para a estação selecionada")

        else:
            # Visão geral de todas as estações
            sensors_data = dashboard_data.get("sensors", {})
            recent_data = sensors_data.get("recent_data", [])

            if recent_data:
                # Gráfico geral
                fig = create_time_series_chart(recent_data, "Dados Recentes de Todas as Estações")
                st.plotly_chart(fig, use_container_width=True)

                # Estatísticas por estação
                st.subheader("📊 Estatísticas por Estação")
                df = pd.DataFrame(recent_data)
                if not df.empty:
                    stats = df.groupby(['station_id', 'sensor_type']).agg({
                        'value': ['mean', 'min', 'max', 'count']
                    }).round(2)
                    st.dataframe(stats, use_container_width=True)

    with tab2:
        st.header("⚠️ Anomalias")

        # Carregar anomalias com filtros
        station_filter = selected_station if selected_station != "Todas" else None
        severity_filter = selected_severity if selected_severity != "Todas" else None

        anomalies_data = load_anomalies(station_filter, severity_filter)
        anomalies = anomalies_data.get("anomalies", [])

        if anomalies:
            # Gráfico de anomalias
            fig = create_anomaly_chart(anomalies)
            st.plotly_chart(fig, use_container_width=True)

            # Estatísticas de anomalias
            col1, col2 = st.columns(2)

            with col1:
                st.subheader("📊 Por Severidade")
                anomaly_stats = dashboard_data.get("anomalies", {}).get("by_severity", {})

                fig_pie = px.pie(
                    values=list(anomaly_stats.values()),
                    names=list(anomaly_stats.keys()),
                    title="Distribuição de Severidade"
                )
                st.plotly_chart(fig_pie, use_container_width=True)

            with col2:
                st.subheader("📋 Anomalias Recentes")
                df_anomalies = pd.DataFrame(anomalies[:10])
                if not df_anomalies.empty:
                    df_anomalies['detected_at'] = pd.to_datetime(df_anomalies['detected_at'])
                    df_display = df_anomalies[[
                        'station_id', 'sensor_type', 'severity', 
                        'anomaly_score', 'detected_at'
                    ]].sort_values('detected_at', ascending=False)
                    st.dataframe(df_display, use_container_width=True)
        else:
            st.info("Nenhuma anomalia encontrada com os filtros aplicados")

    with tab3:
        st.header("🔮 Previsão de Demanda")

        # Interface para previsão
        col1, col2 = st.columns([2, 1])

        with col1:
            pred_station = st.selectbox(
                "Estação para Previsão", 
                [s["station_id"] for s in stations_data.get("stations", [])],
                key="pred_station"
            )
            pred_hours = st.slider("Horas à frente", 1, 168, 24, key="pred_hours")

        with col2:
            if st.button("🔮 Gerar Previsão", key="predict_btn"):
                with st.spinner("Gerando previsão..."):
                    prediction_data = {
                        "station_id": pred_station,
                        "hours_ahead": pred_hours
                    }
                    result = api.post("/predict/demand", prediction_data)

                    if result and "prediction" in result:
                        prediction = result["prediction"]

                        # Gráfico de previsão
                        pred_df = pd.DataFrame(prediction["predictions"])
                        pred_df['timestamp'] = pd.to_datetime(pred_df['timestamp'])

                        fig = go.Figure()
                        fig.add_trace(go.Scatter(
                            x=pred_df['timestamp'],
                            y=pred_df['predicted_consumption'],
                            mode='lines+markers',
                            name='Consumo Previsto',
                            line=dict(color='blue', width=3)
                        ))

                        fig.update_layout(
                            title=f"Previsão de Consumo - {pred_station}",
                            xaxis_title="Data/Hora",
                            yaxis_title="Consumo Previsto (L)",
                            height=400
                        )

                        st.plotly_chart(fig, use_container_width=True)

                        # Estatísticas da previsão
                        total_consumption = prediction.get("total_predicted_consumption", 0)
                        st.metric(
                            label="💧 Consumo Total Previsto",
                            value=f"{total_consumption:.2f} L",
                            delta=None
                        )
                    else:
                        st.error("Erro ao gerar previsão")

    with tab4:
        st.header("⚙️ Status do Sistema")

        # Health check
        system_data = dashboard_data.get("system", {})

        if system_data:
            col1, col2 = st.columns(2)

            with col1:
                st.subheader("💾 Banco de Dados")
                db_data = system_data.get("database", {})

                if db_data.get("connected", False):
                    st.success("✅ Conectado")
                    st.metric("Total de Sensores", db_data.get("total_sensors", 0))
                    st.metric("Dados Recentes", db_data.get("recent_data", 0))
                else:
                    st.error("❌ Desconectado")

            with col2:
                st.subheader("📊 Estatísticas Gerais")
                stats = dashboard_data.get("anomalies", {})
                st.metric("Total de Anomalias", stats.get("total", 0))
                st.metric("Últimas 24h", stats.get("last_24h", 0))
                st.metric("Não Resolvidas", stats.get("unresolved", 0))

        # Logs recentes (placeholder)
        st.subheader("📜 Logs do Sistema")
        st.info("Logs do sistema serão exibidos aqui em versões futuras")

    # Auto-refresh
    if auto_refresh:
        time.sleep(refresh_interval)
        st.rerun()

if __name__ == "__main__":
    main()
