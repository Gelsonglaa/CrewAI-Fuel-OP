# 🚀 CrewAI Fuel OP System

Sistema inteligente de monitoramento de combustível com IA, desenvolvido com CrewAI, FastAPI, Machine Learning e Streamlit.

![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green.svg)
![CrewAI](https://img.shields.io/badge/CrewAI-0.28+-orange.svg)
![License](https://img.shields.io/badge/License-MIT-blue.svg)

## 📋 Índice

- [Visão Geral](#visão-geral)
- [Arquitetura](#arquitetura)
- [Funcionalidades](#funcionalidades)
- [Instalação](#instalação)
- [Uso](#uso)
- [API](#api)
- [Dashboard](#dashboard)
- [Machine Learning](#machine-learning)
- [Deploy com Docker](#deploy-com-docker)
- [Desenvolvimento](#desenvolvimento)
- [Contribuição](#contribuição)
- [Licença](#licença)

## 🎯 Visão Geral

O **CrewAI Fuel OP** é um sistema completo de monitoramento inteligente para estações de combustível que utiliza:

- **🤖 Agentes IA Autônomos** com CrewAI para análise e tomada de decisões
- **🔍 Detecção de Anomalias** com Isolation Forest
- **📈 Previsão de Demanda** com Random Forest
- **📊 Dashboard Interativo** em tempo real
- **🔌 API REST** completa e documentada
- **🎭 Simulador** de sensores realístico

## 🏗️ Arquitetura

```
CrewAI_Fuel_OP/
├── app/
│   ├── core/           # Módulos principais
│   │   ├── config.py   # Configurações centralizadas
│   │   ├── database.py # ORM e modelos de dados
│   │   └── tools.py    # Ferramentas para agentes
│   ├── ml/             # Machine Learning
│   │   ├── anomaly_detection_service.py
│   │   ├── demand_forecasting_service.py
│   │   └── models/     # Modelos treinados
│   └── api/            # API REST
│       └── main.py     # FastAPI principal
├── dashboard/          # Interface web
│   └── visualization_app.py
├── simulators/         # Simulação de dados
│   └── sensor_simulator.py
├── data/              # Banco de dados SQLite
├── logs/              # Logs do sistema
└── docs/              # Documentação
```

## ✨ Funcionalidades

### 🔍 Monitoramento Inteligente
- **Detecção automática de anomalias** em sensores
- **Alertas em tempo real** via SMS, WhatsApp e email
- **Análise preditiva** de demanda de combustível
- **Qualidade de dados** e validação automática

### 🤖 Agentes IA Autônomos
- **Monitor Agent**: Coleta e analisa dados dos sensores
- **Diagnosis Agent**: Diagnostica problemas e anomalias
- **Action Agent**: Executa ações corretivas automáticas
- **Learner Agent**: Aprende com feedbacks e melhora o sistema
- **Report Agent**: Gera relatórios inteligentes

### 📊 Dashboard Interativo
- **Visualização em tempo real** com Plotly
- **Filtros avançados** por estação, período e severidade
- **KPIs dinâmicos** e métricas operacionais
- **Previsões de demanda** interativas
- **Auto-refresh** configurável

### 🔌 API REST Completa
- **Documentação automática** com Swagger/OpenAPI
- **Endpoints** para sensores, anomalias, previsões
- **Autenticação** e validação de dados
- **Health checks** e monitoramento

## 🚀 Instalação

### Pré-requisitos
- Python 3.11+
- Docker e Docker Compose (opcional)
- 4GB RAM mínimo
- 2GB espaço em disco

### Instalação Rápida com Docker

```bash
# Clonar o repositório
git clone https://github.com/your-org/crewai-fuel-op.git
cd crewai-fuel-op

# Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com suas configurações

# Iniciar com Docker Compose
docker-compose up -d

# Verificar status
docker-compose ps
```

### Instalação Manual

```bash
# Clonar repositório
git clone https://github.com/your-org/crewai-fuel-op.git
cd crewai-fuel-op

# Criar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate  # Windows

# Instalar dependências
pip install -r requirements.txt

# Configurar ambiente
cp .env.example .env
# Editar .env conforme necessário

# Inicializar banco de dados
python -c "from app.core.database import init_database; init_database()"

# Executar API
uvicorn app.api.main:app --reload --host 0.0.0.0 --port 8000
```

## 🎮 Uso

### 1. Iniciar API
```bash
# Com Docker
docker-compose up api

# Manual
uvicorn app.api.main:app --host 0.0.0.0 --port 8000
```

### 2. Iniciar Dashboard
```bash
# Com Docker
docker-compose up dashboard

# Manual
streamlit run dashboard/visualization_app.py --server.port 8501
```

### 3. Iniciar Simulador
```bash
# Com Docker
docker-compose up simulator

# Manual
python simulators/sensor_simulator.py
```

### 4. Acessar Interfaces
- **API**: http://localhost:8000
- **Documentação**: http://localhost:8000/docs
- **Dashboard**: http://localhost:8501

## 🔌 API

### Endpoints Principais

#### Health Check
```bash
GET /health
# Retorna status detalhado do sistema
```

#### Sensores
```bash
GET /sensor-data/{station_id}?hours_back=24
POST /sensor-data
# Dados de sensores por estação
```

#### Anomalias
```bash
GET /anomalies?severity=high&station_id=STATION_001
POST /anomalies
# Gerenciamento de anomalias
```

#### Machine Learning
```bash
POST /predict/anomaly
POST /predict/demand
POST /retrain/anomaly-model
POST /retrain/demand-model
# Serviços de IA e ML
```

#### Exemplos de Uso

```bash
# Obter dados de sensores
curl -X GET "http://localhost:8000/sensor-data/STATION_001?hours_back=24"

# Enviar dados de sensor
curl -X POST "http://localhost:8000/sensor-data" \
  -H "Content-Type: application/json" \
  -d '{
    "station_id": "STATION_001",
    "sensor_type": "fuel_level",
    "value": 75.5,
    "unit": "percent"
  }'

# Detectar anomalia
curl -X POST "http://localhost:8000/predict/anomaly" \
  -H "Content-Type: application/json" \
  -d '{
    "station_id": "STATION_001",
    "sensor_type": "pressure",
    "value": 8.5,
    "timestamp": "2024-01-01T12:00:00"
  }'

# Prever demanda
curl -X POST "http://localhost:8000/predict/demand" \
  -H "Content-Type: application/json" \
  -d '{
    "station_id": "STATION_001",
    "hours_ahead": 24
  }'
```

## 📊 Dashboard

### Funcionalidades

- **📈 Visualização em Tempo Real**: Gráficos interativos com Plotly
- **🔍 Filtros Avançados**: Por estação, período, severidade
- **📊 KPIs Dinâmicos**: Métricas operacionais importantes
- **⚠️ Alertas Visuais**: Anomalias destacadas por cores
- **🔮 Previsões Interativas**: Gráficos de demanda futura
- **⚙️ Controles ML**: Retreinamento de modelos via interface

### Seções do Dashboard

1. **📊 Visão Geral**: KPIs e status geral
2. **📈 Sensores**: Dados históricos e atuais
3. **⚠️ Anomalias**: Detecções e análises
4. **🔮 Previsões**: Demanda futura estimada
5. **⚙️ Sistema**: Status e configurações

## 🧠 Machine Learning

### Detecção de Anomalias

**Algoritmo**: Isolation Forest
- **Features**: Valor, qualidade, lag temporal, rolling statistics
- **Threshold**: Configurável (padrão: 0.7)
- **Retreinamento**: Automático com novos dados

### Previsão de Demanda

**Algoritmo**: Random Forest Regressor
- **Features**: Temporais, lag, médias móveis, sazonalidade
- **Horizonte**: 1 a 168 horas (1 semana)
- **Avaliação**: MSE, MAE, R² score

### Uso dos Modelos

```python
# Detectar anomalia
from app.ml.anomaly_detection_service import detect_anomaly

result = detect_anomaly({
    "station_id": "STATION_001",
    "sensor_type": "pressure",
    "value": 8.5,
    "timestamp": "2024-01-01T12:00:00"
})

# Prever demanda
from app.ml.demand_forecasting_service import predict_fuel_demand

prediction = predict_fuel_demand(
    hours_ahead=24,
    station_id="STATION_001"
)
```

## 🐳 Deploy com Docker

### Arquivos de Configuração

- **Dockerfile**: Imagem multi-stage otimizada
- **docker-compose.yml**: Stack completa com todos os serviços
- **nginx.conf**: Reverse proxy (opcional)
- **prometheus.yml**: Métricas (opcional)

### Comandos Docker

```bash
# Build da imagem
docker build -t crewai-fuel-op .

# Executar stack completa
docker-compose up -d

# Ver logs
docker-compose logs -f api

# Parar serviços
docker-compose down

# Rebuild após mudanças
docker-compose up --build
```

### Variáveis de Ambiente

```env
# Banco de Dados
DATABASE_URL=sqlite:///./data/fuel_op.db

# MQTT (opcional)
MQTT_BROKER_URL=broker.hivemq.com
MQTT_USERNAME=
MQTT_PASSWORD=

# Twilio (alertas)
TWILIO_SID=
TWILIO_AUTH_TOKEN=
TWILIO_PHONE_NUMBER=

# Email (alertas)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=

# Segurança
JWT_SECRET_KEY=your-super-secret-key
```

## 🛠️ Desenvolvimento

### Estrutura de Testes

```bash
# Executar todos os testes
pytest app/tests/ -v

# Com cobertura
pytest app/tests/ -v --cov=app --cov-report=html

# Testes específicos
pytest app/tests/test_api_endpoints.py -v
```

### Comandos de Desenvolvimento

```bash
# Formatar código
black app/ dashboard/ simulators/

# Verificar style
flake8 app/

# Type checking
mypy app/

# Atualizar dependências
pip-compile requirements.in
```

### Estrutura de Commits

```bash
# Formato
<tipo>: <descrição>

# Tipos
feat: nova funcionalidade
fix: correção de bug
docs: documentação
style: formatação
refactor: refatoração
test: testes
chore: manutenção
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'feat: add AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

### Guidelines
- Siga os padrões de código estabelecidos
- Adicione testes para novas funcionalidades
- Atualize a documentação quando necessário
- Mantenha commits pequenos e focados

## 📈 Roadmap

- [ ] **Integração com IoT**: Conectores para sensores reais
- [ ] **Mobile App**: Aplicativo móvel para monitoramento
- [ ] **Advanced ML**: Modelos de deep learning
- [ ] **Multi-tenant**: Suporte para múltiplas empresas
- [ ] **Blockchain**: Rastreabilidade de combustível
- [ ] **Edge Computing**: Processamento local

## 🔒 Segurança

- **Autenticação JWT** para API
- **Validação** de entrada rigorosa
- **Rate limiting** para prevenir abuso
- **Logs de auditoria** completos
- **Containers** sem privilégios root
- **Secrets** gerenciados via variáveis de ambiente

## 📊 Performance

- **Cache** estratégico com Redis (opcional)
- **Compressão** de responses
- **Connection pooling** para banco
- **Async/await** para operações I/O
- **Índices** otimizados no banco
- **CDN** para assets estáticos (produção)

## 🆘 Troubleshooting

### Problemas Comuns

**1. Erro de conexão com API**
```bash
# Verificar se API está rodando
curl http://localhost:8000/health

# Verificar logs
docker-compose logs api
```

**2. Dashboard não carrega dados**
```bash
# Verificar URL da API no dashboard
# Verificar se API está acessível
# Verificar logs do Streamlit
```

**3. Modelos ML não encontrados**
```bash
# Treinar modelos iniciais
curl -X POST http://localhost:8000/retrain/anomaly-model
curl -X POST http://localhost:8000/retrain/demand-model
```

### Logs e Monitoramento

```bash
# Logs da API
tail -f logs/app.log

# Logs do Docker
docker-compose logs -f

# Métricas (se Prometheus configurado)
curl http://localhost:9090/metrics
```

## 📞 Suporte

- **Issues**: [GitHub Issues](https://github.com/your-org/crewai-fuel-op/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/crewai-fuel-op/discussions)
- **Wiki**: [Documentação detalhada](https://github.com/your-org/crewai-fuel-op/wiki)

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🙏 Agradecimentos

- **CrewAI** pela framework de agentes IA
- **FastAPI** pelo framework web moderno
- **Streamlit** pela interface de dashboard
- **Scikit-learn** pelos algoritmos de ML
- **Plotly** pelas visualizações interativas

---

**Desenvolvido com ❤️ para o futuro do monitoramento inteligente de combustível**

## 📸 Screenshots

### Dashboard Principal
![Dashboard](docs/images/dashboard-overview.png)

### API Documentation
![API Docs](docs/images/api-docs.png)

### Anomalies Detection
![Anomalies](docs/images/anomalies.png)

---

**⭐ Se este projeto foi útil, por favor considere dar uma estrela!**
