import React, { useState, useEffect } from 'react'
import { 
  Activity, 
  AlertTriangle, 
  BarChart3, 
  Database, 
  Fuel, 
  Gauge, 
  Settings, 
  TrendingUp,
  Zap,
  Shield,
  Clock,
  MapPin,
  Bell,
  RefreshCw,
  Filter,
  Calendar,
  Download,
  Eye,
  EyeOff
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import './App.css'

// Dados simulados para demonstração
const mockData = {
  overview: {
    activeStations: 12,
    totalSensors: 48,
    recentDataPoints: 1247,
    unresolvedAnomalies: 3,
    systemUptime: 99.2
  },
  stations: [
    { id: 'STATION_001', name: 'Posto Central', status: 'online', lastUpdate: '2 min ago', fuelLevel: 85 },
    { id: 'STATION_002', name: 'Posto Norte', status: 'online', lastUpdate: '1 min ago', fuelLevel: 67 },
    { id: 'STATION_003', name: 'Posto Sul', status: 'warning', lastUpdate: '5 min ago', fuelLevel: 23 },
    { id: 'STATION_004', name: 'Posto Leste', status: 'online', lastUpdate: '3 min ago', fuelLevel: 92 }
  ],
  sensorData: [
    { time: '00:00', fuel_level: 85, pressure: 2.3, temperature: 24, flow_rate: 45 },
    { time: '04:00', fuel_level: 82, pressure: 2.4, temperature: 23, flow_rate: 38 },
    { time: '08:00', fuel_level: 78, pressure: 2.2, temperature: 26, flow_rate: 52 },
    { time: '12:00', fuel_level: 74, pressure: 2.5, temperature: 28, flow_rate: 61 },
    { time: '16:00', fuel_level: 69, pressure: 2.3, temperature: 27, flow_rate: 48 },
    { time: '20:00', fuel_level: 65, pressure: 2.4, temperature: 25, flow_rate: 42 }
  ],
  anomalies: [
    { id: 1, station: 'STATION_003', sensor: 'fuel_level', severity: 'high', score: 0.89, time: '14:23', description: 'Nível baixo de combustível' },
    { id: 2, station: 'STATION_001', sensor: 'pressure', severity: 'medium', score: 0.72, time: '13:45', description: 'Pressão acima do normal' },
    { id: 3, station: 'STATION_002', sensor: 'temperature', severity: 'low', score: 0.65, time: '12:30', description: 'Variação de temperatura' }
  ],
  predictions: [
    { time: '22:00', predicted: 58, confidence: 95 },
    { time: '02:00', predicted: 52, confidence: 92 },
    { time: '06:00', predicted: 48, confidence: 88 },
    { time: '10:00', predicted: 44, confidence: 85 },
    { time: '14:00', predicted: 39, confidence: 82 },
    { time: '18:00', predicted: 35, confidence: 79 }
  ]
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8']

function App() {
  const [selectedStation, setSelectedStation] = useState('all')
  const [selectedTimeRange, setSelectedTimeRange] = useState('24h')
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [showRawData, setShowRawData] = useState(false)
  const [darkMode, setDarkMode] = useState(false)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Simulação de auto-refresh
  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(() => {
        setLastUpdate(new Date())
      }, 30000) // 30 segundos

      return () => clearInterval(interval)
    }
  }, [autoRefresh])

  // Toggle dark mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [darkMode])

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-red-500'
      case 'high': return 'bg-orange-500'
      case 'medium': return 'bg-yellow-500'
      case 'low': return 'bg-green-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'online': return 'text-green-500'
      case 'warning': return 'text-yellow-500'
      case 'offline': return 'text-red-500'
      default: return 'text-gray-500'
    }
  }

  const MetricCard = ({ title, value, unit, icon: Icon, trend, color = "blue" }) => (
    <Card className="relative overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className={`h-4 w-4 text-${color}-600`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">
          {unit && <span className="text-muted-foreground">{unit}</span>}
          {trend && (
            <span className={`ml-2 ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {trend > 0 ? '↗' : '↘'} {Math.abs(trend)}%
            </span>
          )}
        </p>
      </CardContent>
    </Card>
  )

  const AlertCard = ({ anomaly }) => (
    <Alert className={`border-l-4 ${getSeverityColor(anomaly.severity).replace('bg-', 'border-l-')}`}>
      <AlertTriangle className="h-4 w-4" />
      <AlertDescription>
        <div className="flex justify-between items-start">
          <div>
            <strong>{anomaly.station}</strong> - {anomaly.sensor}
            <p className="text-sm text-muted-foreground mt-1">{anomaly.description}</p>
          </div>
          <div className="text-right">
            <Badge variant="outline" className={getSeverityColor(anomaly.severity)}>
              {anomaly.severity}
            </Badge>
            <p className="text-xs text-muted-foreground mt-1">{anomaly.time}</p>
          </div>
        </div>
      </AlertDescription>
    </Alert>
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Fuel className="h-8 w-8 text-blue-600" />
                <div>
                  <h1 className="text-2xl font-bold">CrewAI Fuel OP</h1>
                  <p className="text-sm text-muted-foreground">Sistema de Monitoramento Inteligente</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Label htmlFor="dark-mode">Modo Escuro</Label>
                <Switch
                  id="dark-mode"
                  checked={darkMode}
                  onCheckedChange={setDarkMode}
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Label htmlFor="auto-refresh">Auto-refresh</Label>
                <Switch
                  id="auto-refresh"
                  checked={autoRefresh}
                  onCheckedChange={setAutoRefresh}
                />
              </div>
              
              <Button variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Atualizar
              </Button>
              
              <div className="text-sm text-muted-foreground">
                Última atualização: {lastUpdate.toLocaleTimeString()}
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Filtros */}
        <div className="mb-6 p-4 bg-card rounded-lg border">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4" />
                <Label>Filtros:</Label>
              </div>
              
              <Select value={selectedStation} onValueChange={setSelectedStation}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Selecionar estação" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">🌐 Todas as Estações</SelectItem>
                  {mockData.stations.map(station => (
                    <SelectItem key={station.id} value={station.id}>
                      🏭 {station.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">1 Hora</SelectItem>
                  <SelectItem value="6h">6 Horas</SelectItem>
                  <SelectItem value="24h">24 Horas</SelectItem>
                  <SelectItem value="7d">7 Dias</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Exportar
              </Button>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowRawData(!showRawData)}
              >
                {showRawData ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
                {showRawData ? 'Ocultar' : 'Mostrar'} Dados
              </Button>
            </div>
          </div>
        </div>

        {/* Alertas em Tempo Real */}
        {mockData.anomalies.filter(a => a.severity === 'high' || a.severity === 'critical').length > 0 && (
          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-3 flex items-center">
              <Bell className="h-5 w-5 mr-2 text-red-500" />
              Alertas Críticos
            </h2>
            <div className="space-y-2">
              {mockData.anomalies
                .filter(a => a.severity === 'high' || a.severity === 'critical')
                .map(anomaly => (
                  <AlertCard key={anomaly.id} anomaly={anomaly} />
                ))}
            </div>
          </div>
        )}

        {/* Métricas Principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
          <MetricCard
            title="Estações Ativas"
            value={mockData.overview.activeStations}
            icon={MapPin}
            color="blue"
            trend={2.1}
          />
          <MetricCard
            title="Sensores Ativos"
            value={mockData.overview.totalSensors}
            icon={Activity}
            color="green"
            trend={1.5}
          />
          <MetricCard
            title="Dados Recentes"
            value={mockData.overview.recentDataPoints}
            icon={Database}
            color="purple"
            trend={-0.8}
          />
          <MetricCard
            title="Anomalias Abertas"
            value={mockData.overview.unresolvedAnomalies}
            icon={AlertTriangle}
            color="orange"
            trend={-12.3}
          />
          <MetricCard
            title="Uptime do Sistema"
            value={`${mockData.overview.systemUptime}%`}
            icon={Shield}
            color="green"
            trend={0.2}
          />
        </div>

        {/* Tabs Principais */}
        <Tabs defaultValue="monitoring" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="monitoring">📈 Monitoramento</TabsTrigger>
            <TabsTrigger value="anomalies">⚠️ Anomalias</TabsTrigger>
            <TabsTrigger value="predictions">🔮 Previsões</TabsTrigger>
            <TabsTrigger value="stations">🏭 Estações</TabsTrigger>
            <TabsTrigger value="system">⚙️ Sistema</TabsTrigger>
          </TabsList>

          <TabsContent value="monitoring" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gráfico de Sensores */}
              <Card>
                <CardHeader>
                  <CardTitle>Dados dos Sensores em Tempo Real</CardTitle>
                  <CardDescription>Últimas 24 horas</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={mockData.sensorData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="fuel_level" stroke="#8884d8" name="Nível (%)" />
                      <Line type="monotone" dataKey="pressure" stroke="#82ca9d" name="Pressão (bar)" />
                      <Line type="monotone" dataKey="temperature" stroke="#ffc658" name="Temperatura (°C)" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Gráfico de Vazão */}
              <Card>
                <CardHeader>
                  <CardTitle>Vazão de Combustível</CardTitle>
                  <CardDescription>Litros por minuto</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={mockData.sensorData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Area type="monotone" dataKey="flow_rate" stroke="#ff7300" fill="#ff7300" fillOpacity={0.3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Status das Estações */}
            <Card>
              <CardHeader>
                <CardTitle>Status das Estações</CardTitle>
                <CardDescription>Visão geral em tempo real</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {mockData.stations.map(station => (
                    <Card key={station.id} className="relative">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-sm">{station.name}</CardTitle>
                          <div className={`h-2 w-2 rounded-full ${getStatusColor(station.status).replace('text-', 'bg-')}`} />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Nível de Combustível</span>
                            <span>{station.fuelLevel}%</span>
                          </div>
                          <Progress value={station.fuelLevel} className="h-2" />
                          <p className="text-xs text-muted-foreground">{station.lastUpdate}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="anomalies" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Distribuição de Anomalias */}
              <Card>
                <CardHeader>
                  <CardTitle>Distribuição por Severidade</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Baixa', value: 12, color: '#10B981' },
                          { name: 'Média', value: 8, color: '#F59E0B' },
                          { name: 'Alta', value: 3, color: '#EF4444' },
                          { name: 'Crítica', value: 1, color: '#DC2626' }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {[
                          { name: 'Baixa', value: 12, color: '#10B981' },
                          { name: 'Média', value: 8, color: '#F59E0B' },
                          { name: 'Alta', value: 3, color: '#EF4444' },
                          { name: 'Crítica', value: 1, color: '#DC2626' }
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Timeline de Anomalias */}
              <Card>
                <CardHeader>
                  <CardTitle>Timeline de Anomalias</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockData.anomalies.map(anomaly => (
                      <div key={anomaly.id} className="flex items-center space-x-4 p-3 border rounded-lg">
                        <div className={`h-3 w-3 rounded-full ${getSeverityColor(anomaly.severity)}`} />
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium">{anomaly.station}</p>
                              <p className="text-sm text-muted-foreground">{anomaly.description}</p>
                            </div>
                            <div className="text-right">
                              <Badge variant="outline">{anomaly.severity}</Badge>
                              <p className="text-xs text-muted-foreground mt-1">{anomaly.time}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="predictions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Previsão de Consumo</CardTitle>
                <CardDescription>Próximas 24 horas baseado em IA</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={mockData.predictions}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="predicted" 
                      stroke="#2563eb" 
                      strokeWidth={3}
                      name="Consumo Previsto (L)" 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="confidence" 
                      stroke="#10b981" 
                      strokeDasharray="5 5"
                      name="Confiança (%)" 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <MetricCard
                title="Consumo Total Previsto"
                value="285.4L"
                icon={Fuel}
                color="blue"
              />
              <MetricCard
                title="Pico de Consumo"
                value="58.2L"
                icon={TrendingUp}
                color="orange"
              />
              <MetricCard
                title="Confiança Média"
                value="87%"
                icon={Gauge}
                color="green"
              />
            </div>
          </TabsContent>

          <TabsContent value="stations" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockData.stations.map(station => (
                <Card key={station.id} className="relative">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>{station.name}</CardTitle>
                      <Badge variant={station.status === 'online' ? 'default' : 'destructive'}>
                        {station.status}
                      </Badge>
                    </div>
                    <CardDescription>{station.id}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Nível de Combustível</span>
                          <span>{station.fuelLevel}%</span>
                        </div>
                        <Progress 
                          value={station.fuelLevel} 
                          className={`h-3 ${station.fuelLevel < 30 ? 'bg-red-100' : 'bg-green-100'}`}
                        />
                      </div>
                      
                      <Separator />
                      
                      <div className="flex items-center justify-between text-sm">
                        <span className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          Última atualização
                        </span>
                        <span>{station.lastUpdate}</span>
                      </div>
                      
                      <Button variant="outline" className="w-full">
                        <Settings className="h-4 w-4 mr-2" />
                        Configurar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="system" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Status do Sistema</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>API Principal</span>
                    <Badge variant="default">Online</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Banco de Dados</span>
                    <Badge variant="default">Conectado</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Serviço de ML</span>
                    <Badge variant="default">Ativo</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>MQTT Broker</span>
                    <Badge variant="secondary">Standby</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas do Sistema</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Uptime</span>
                    <span className="font-mono">99.2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Memória Utilizada</span>
                    <span className="font-mono">2.4GB / 8GB</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CPU</span>
                    <span className="font-mono">23%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Requisições/min</span>
                    <span className="font-mono">1,247</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Dados Brutos (se habilitado) */}
        {showRawData && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Dados Brutos</CardTitle>
              <CardDescription>Últimos dados recebidos dos sensores</CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="text-xs bg-muted p-4 rounded-md overflow-auto max-h-96">
                {JSON.stringify(mockData, null, 2)}
              </pre>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default App

