#!/bin/bash

# =============================================================================
# Script de Setup - CrewAI Fuel OP
# =============================================================================

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log colorido
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] AVISO:${NC} $1"
}

error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERRO:${NC} $1"
}

info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] INFO:${NC} $1"
}

# Banner
echo -e "${BLUE}"
cat << "EOF"
  ____                    _    ___   _____          _    ___  ____  
 / ___|_ __ _____      __/ \  |_ _| |  ___|   _  ___| |  / _ \|  _ \ 
| |   | '__/ _ \ \ /\ / / _ \  | |  | |_ | | | |/ _ \ | | | | | |_) |
| |___| | |  __/\ V  V / ___ \ | |  |  _|| |_| |  __/ | | |_| |  __/ 
 \____|_|  \___| \_/\_/_/   \_\___| |_|   \__,_|\___|_|  \___/|_|    
                                                                     
EOF
echo -e "${NC}"

log "🚀 Iniciando setup do CrewAI Fuel OP..."

# Verificar se está no diretório correto
if [ ! -f "requirements.txt" ]; then
    error "❌ Arquivo requirements.txt não encontrado. Execute este script no diretório raiz do projeto."
    exit 1
fi

# Verificar Python
log "🐍 Verificando Python..."
if ! command -v python3 &> /dev/null; then
    error "❌ Python 3 não está instalado. Instale Python 3.11+ e tente novamente."
    exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print('.'.join(map(str, sys.version_info[:2])))")
REQUIRED_VERSION="3.11"

if ! python3 -c "import sys; exit(0 if sys.version_info >= (3, 11) else 1)"; then
    error "❌ Python $REQUIRED_VERSION+ é necessário. Versão atual: $PYTHON_VERSION"
    exit 1
fi

log "✅ Python $PYTHON_VERSION encontrado"

# Verificar Node.js (para dashboard React)
log "📦 Verificando Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    log "✅ Node.js $NODE_VERSION encontrado"
    
    # Verificar pnpm
    if ! command -v pnpm &> /dev/null; then
        warn "⚠️  pnpm não encontrado. Instalando..."
        npm install -g pnpm
    fi
else
    warn "⚠️  Node.js não encontrado. Dashboard React não será configurado."
fi

# Criar ambiente virtual
log "🔧 Configurando ambiente virtual Python..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    log "✅ Ambiente virtual criado"
else
    log "ℹ️  Ambiente virtual já existe"
fi

# Ativar ambiente virtual
source venv/bin/activate
log "✅ Ambiente virtual ativado"

# Atualizar pip
log "📦 Atualizando pip..."
pip install --upgrade pip setuptools wheel

# Instalar dependências Python
log "📦 Instalando dependências Python..."
pip install -r requirements.txt

# Configurar arquivo .env
log "⚙️  Configurando arquivo de ambiente..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    log "✅ Arquivo .env criado a partir do .env.example"
    warn "⚠️  Configure as variáveis de ambiente no arquivo .env antes de executar a aplicação"
else
    log "ℹ️  Arquivo .env já existe"
fi

# Gerar SECRET_KEY se necessário
if grep -q "your-super-secret-key-change-this-in-production" .env; then
    warn "⚠️  Gerando SECRET_KEY aleatória..."
    SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
    sed -i "s/your-super-secret-key-change-this-in-production/$SECRET_KEY/" .env
    log "✅ SECRET_KEY gerada e configurada"
fi

# Criar diretórios necessários
log "📁 Criando diretórios necessários..."
mkdir -p logs uploads models backups
log "✅ Diretórios criados"

# Configurar banco de dados
log "🗃️  Configurando banco de dados..."
if grep -q "sqlite" .env; then
    log "ℹ️  Usando SQLite para desenvolvimento"
    python3 -c "
from app.core.database import create_tables
try:
    create_tables()
    print('✅ Tabelas do banco de dados criadas')
except Exception as e:
    print(f'❌ Erro ao criar tabelas: {e}')
    exit(1)
"
else
    log "ℹ️  Configuração PostgreSQL detectada"
    if command -v alembic &> /dev/null; then
        log "🔄 Executando migrações Alembic..."
        alembic upgrade head
        log "✅ Migrações executadas"
    else
        warn "⚠️  Alembic não encontrado. Execute 'alembic upgrade head' manualmente"
    fi
fi

# Configurar dashboard React
if command -v node &> /dev/null && [ -d "fuel-op-dashboard" ]; then
    log "⚛️  Configurando dashboard React..."
    cd fuel-op-dashboard
    
    if [ -f "package.json" ]; then
        pnpm install
        log "✅ Dependências React instaladas"
    else
        warn "⚠️  package.json não encontrado no diretório fuel-op-dashboard"
    fi
    
    cd ..
fi

# Executar testes básicos
log "🧪 Executando testes básicos..."
if command -v pytest &> /dev/null; then
    pytest tests/ -v --tb=short -x -q || warn "⚠️  Alguns testes falharam. Verifique a configuração."
else
    warn "⚠️  pytest não encontrado. Testes não executados."
fi

# Verificar serviços opcionais
log "🔍 Verificando serviços opcionais..."

# PostgreSQL
if command -v psql &> /dev/null; then
    log "✅ PostgreSQL client encontrado"
else
    info "ℹ️  PostgreSQL client não encontrado. Para usar PostgreSQL, instale: sudo apt-get install postgresql-client"
fi

# Redis
if command -v redis-cli &> /dev/null; then
    log "✅ Redis client encontrado"
else
    info "ℹ️  Redis client não encontrado. Para usar Redis, instale: sudo apt-get install redis-tools"
fi

# Mosquitto (MQTT)
if command -v mosquitto_pub &> /dev/null; then
    log "✅ Mosquitto client encontrado"
else
    info "ℹ️  Mosquitto client não encontrado. Para usar MQTT, instale: sudo apt-get install mosquitto-clients"
fi

# Docker
if command -v docker &> /dev/null; then
    log "✅ Docker encontrado"
    if command -v docker-compose &> /dev/null; then
        log "✅ Docker Compose encontrado"
    else
        info "ℹ️  Docker Compose não encontrado. Para deploy com Docker, instale docker-compose"
    fi
else
    info "ℹ️  Docker não encontrado. Para deploy com containers, instale Docker"
fi

# Criar usuário administrador padrão
log "👤 Criando usuário administrador padrão..."
python3 -c "
from app.auth.auth_service import AuthService
from app.core.database import SessionLocal

db = SessionLocal()
auth_service = AuthService(db)

admin_user = {
    'username': 'admin',
    'email': 'admin@fuel-op.com',
    'password': 'admin123',
    'full_name': 'Administrador do Sistema',
    'is_active': True
}

try:
    existing_user = auth_service.get_user_by_username('admin')
    if not existing_user:
        user = auth_service.create_user(admin_user)
        if user:
            print('✅ Usuário administrador criado: admin / admin123')
        else:
            print('❌ Erro ao criar usuário administrador')
    else:
        print('ℹ️  Usuário administrador já existe')
except Exception as e:
    print(f'❌ Erro ao configurar usuário: {e}')
finally:
    db.close()
"

# Resumo final
echo ""
log "🎉 Setup concluído com sucesso!"
echo ""
echo -e "${GREEN}📋 Próximos passos:${NC}"
echo ""
echo "1. Configure as variáveis de ambiente no arquivo .env"
echo "2. Para desenvolvimento, execute:"
echo -e "   ${BLUE}source venv/bin/activate${NC}"
echo -e "   ${BLUE}uvicorn app.api.main:app --reload${NC}"
echo ""
echo "3. Para dashboard Streamlit:"
echo -e "   ${BLUE}streamlit run dashboard/enhanced_dashboard.py${NC}"
echo ""
echo "4. Para dashboard React:"
echo -e "   ${BLUE}cd fuel-op-dashboard && pnpm run dev${NC}"
echo ""
echo "5. Para executar testes:"
echo -e "   ${BLUE}pytest${NC}"
echo ""
echo "6. Para deploy com Docker:"
echo -e "   ${BLUE}cd deployment && docker-compose up -d${NC}"
echo ""
echo -e "${GREEN}🌐 URLs de acesso:${NC}"
echo "• API: http://localhost:8000"
echo "• Documentação: http://localhost:8000/docs"
echo "• Dashboard Streamlit: http://localhost:8501"
echo "• Dashboard React: http://localhost:3000"
echo ""
echo -e "${GREEN}👤 Credenciais padrão:${NC}"
echo "• Usuário: admin"
echo "• Senha: admin123"
echo ""
echo -e "${YELLOW}⚠️  Lembre-se de alterar as credenciais padrão em produção!${NC}"
echo ""
log "✨ CrewAI Fuel OP está pronto para uso!"

