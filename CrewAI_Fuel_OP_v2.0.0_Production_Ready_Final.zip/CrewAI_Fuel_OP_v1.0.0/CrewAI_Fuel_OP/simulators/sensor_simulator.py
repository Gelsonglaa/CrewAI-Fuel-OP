"""
Simulador de sensores para o sistema CrewAI Fuel OP.
Gera dados realistas de sensores para teste e desenvolvimento.
"""

import logging
import random
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import requests
import json
from dataclasses import dataclass
import numpy as np

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class SensorConfig:
    """Configuração de um sensor."""
    sensor_type: str
    unit: str
    min_value: float
    max_value: float
    base_value: float
    noise_level: float
    anomaly_probability: float = 0.02  # 2% de chance de anomalia

class SensorSimulator:
    """
    Simulador de sensores para estações de combustível.
    """

    def __init__(self, api_url: str = "http://localhost:8000"):
        self.api_url = api_url
        self.running = False
        self.threads = []

        # Configurações dos sensores
        self.sensor_configs = {
            "fuel_level": SensorConfig(
                sensor_type="fuel_level",
                unit="percent",
                min_value=5.0,
                max_value=100.0,
                base_value=70.0,
                noise_level=2.0,
                anomaly_probability=0.03
            ),
            "pressure": SensorConfig(
                sensor_type="pressure",
                unit="bar",
                min_value=0.5,
                max_value=6.0,
                base_value=3.0,
                noise_level=0.1,
                anomaly_probability=0.02
            ),
            "temperature": SensorConfig(
                sensor_type="temperature",
                unit="celsius",
                min_value=10.0,
                max_value=50.0,
                base_value=25.0,
                noise_level=2.0,
                anomaly_probability=0.015
            ),
            "flow_rate": SensorConfig(
                sensor_type="flow_rate",
                unit="L/min",
                min_value=0.0,
                max_value=120.0,
                base_value=40.0,
                noise_level=5.0,
                anomaly_probability=0.025
            )
        }

        # Estado dos sensores (para continuidade)
        self.sensor_states = {}

        # Estatísticas
        self.stats = {
            "total_readings": 0,
            "anomalies_generated": 0,
            "api_errors": 0,
            "start_time": None
        }

    def generate_sensor_reading(self, station_id: str, sensor_config: SensorConfig) -> Dict:
        """
        Gerar leitura de sensor realista.

        Args:
            station_id: ID da estação
            sensor_config: Configuração do sensor

        Returns:
            Dados do sensor
        """
        sensor_key = f"{station_id}_{sensor_config.sensor_type}"

        # Obter estado anterior ou inicializar
        if sensor_key not in self.sensor_states:
            self.sensor_states[sensor_key] = {
                "value": sensor_config.base_value,
                "trend": 0.0,
                "last_anomaly": None,
                "fuel_consumption_rate": random.uniform(0.1, 0.5),  # Para fuel_level
                "last_refill": None
            }

        state = self.sensor_states[sensor_key]
        current_time = datetime.utcnow()

        # Gerar valor base com tendência
        if sensor_config.sensor_type == "fuel_level":
            value = self._generate_fuel_level(state, current_time)
        elif sensor_config.sensor_type == "pressure":
            value = self._generate_pressure(state, current_time)
        elif sensor_config.sensor_type == "temperature":
            value = self._generate_temperature(state, current_time)
        elif sensor_config.sensor_type == "flow_rate":
            value = self._generate_flow_rate(state, current_time)
        else:
            value = sensor_config.base_value

        # Adicionar ruído
        noise = random.gauss(0, sensor_config.noise_level)
        value += noise

        # Verificar anomalia
        quality_score = 1.0
        if random.random() < sensor_config.anomaly_probability:
            # Gerar anomalia
            anomaly_types = ["spike", "drop", "drift", "noise"]
            anomaly_type = random.choice(anomaly_types)

            if anomaly_type == "spike":
                value *= random.uniform(1.5, 3.0)
            elif anomaly_type == "drop":
                value *= random.uniform(0.3, 0.7)
            elif anomaly_type == "drift":
                value += random.uniform(-20, 20)
            elif anomaly_type == "noise":
                value += random.gauss(0, sensor_config.noise_level * 3)
                quality_score = random.uniform(0.3, 0.7)

            state["last_anomaly"] = current_time
            self.stats["anomalies_generated"] += 1
            logger.info(f"Anomalia gerada: {anomaly_type} em {station_id}:{sensor_config.sensor_type}")

        # Aplicar limites
        value = max(sensor_config.min_value, min(sensor_config.max_value, value))

        # Atualizar estado
        state["value"] = value

        # Criar registro
        reading = {
            "station_id": station_id,
            "sensor_type": sensor_config.sensor_type,
            "value": round(value, 2),
            "unit": sensor_config.unit,
            "quality_score": round(quality_score, 3)
        }

        self.stats["total_readings"] += 1
        return reading

    def _generate_fuel_level(self, state: Dict, current_time: datetime) -> float:
        """Gerar nível de combustível com padrão realista."""
        # Simular consumo gradual
        if state["last_refill"] is None:
            state["last_refill"] = current_time - timedelta(hours=random.randint(1, 48))

        # Calcular consumo desde o último update
        time_diff = (current_time - state.get("last_update", current_time)).total_seconds() / 3600
        consumption = state["fuel_consumption_rate"] * time_diff

        # Padrão de consumo baseado na hora
        hour = current_time.hour
        if 6 <= hour <= 18:  # Dia - maior consumo
            consumption *= 1.5
        elif 18 <= hour <= 22:  # Tarde - consumo médio
            consumption *= 1.2
        else:  # Noite - menor consumo
            consumption *= 0.8

        new_value = state["value"] - consumption

        # Simular reabastecimento
        if new_value < 15 and random.random() < 0.1:  # 10% chance de reabastecimento quando baixo
            new_value = random.uniform(90, 100)
            state["last_refill"] = current_time
            logger.info(f"Reabastecimento simulado: {new_value:.1f}%")

        state["last_update"] = current_time
        return max(5.0, new_value)

    def _generate_pressure(self, state: Dict, current_time: datetime) -> float:
        """Gerar pressão com variações realistas."""
        # Variação sazonal suave
        base_pressure = 3.0 + 0.5 * np.sin(current_time.hour * np.pi / 12)

        # Adicionar pequena tendência
        if "trend" not in state:
            state["trend"] = random.uniform(-0.01, 0.01)

        state["trend"] += random.uniform(-0.005, 0.005)
        state["trend"] = max(-0.05, min(0.05, state["trend"]))

        return base_pressure + state["trend"]

    def _generate_temperature(self, state: Dict, current_time: datetime) -> float:
        """Gerar temperatura com padrão diário."""
        # Padrão diário de temperatura
        hour = current_time.hour
        daily_temp = 20 + 10 * np.sin((hour - 6) * np.pi / 12)

        # Variação sazonal (aproximada)
        seasonal_variation = 5 * np.sin(current_time.timetuple().tm_yday * 2 * np.pi / 365)

        return daily_temp + seasonal_variation

    def _generate_flow_rate(self, state: Dict, current_time: datetime) -> float:
        """Gerar taxa de fluxo com padrão de uso."""
        # Padrão baseado na hora
        hour = current_time.hour

        if 6 <= hour <= 9:  # Manhã - pico
            base_flow = random.uniform(60, 100)
        elif 17 <= hour <= 20:  # Tarde - pico
            base_flow = random.uniform(50, 90)
        elif 10 <= hour <= 16:  # Dia - médio
            base_flow = random.uniform(30, 70)
        else:  # Noite - baixo
            base_flow = random.uniform(5, 30)

        return base_flow

    def send_to_api(self, sensor_reading: Dict) -> bool:
        """
        Enviar leitura para a API.

        Args:
            sensor_reading: Dados do sensor

        Returns:
            True se enviado com sucesso
        """
        try:
            url = f"{self.api_url}/sensor-data"
            response = requests.post(url, json=sensor_reading, timeout=5)
            response.raise_for_status()
            return True
        except Exception as e:
            logger.error(f"Erro ao enviar para API: {e}")
            self.stats["api_errors"] += 1
            return False

    def simulate_station(self, station_id: str, interval: int = 10):
        """
        Simular uma estação de combustível.

        Args:
            station_id: ID da estação
            interval: Intervalo entre leituras (segundos)
        """
        logger.info(f"Iniciando simulação da estação {station_id}")

        while self.running:
            try:
                # Gerar leitura para cada sensor
                for sensor_config in self.sensor_configs.values():
                    reading = self.generate_sensor_reading(station_id, sensor_config)

                    # Enviar para API
                    success = self.send_to_api(reading)

                    if success:
                        logger.debug(f"Enviado: {station_id}:{sensor_config.sensor_type} = {reading['value']}")

                    time.sleep(0.1)  # Pequeno delay entre sensores

                # Aguardar próxima leitura
                time.sleep(interval)

            except Exception as e:
                logger.error(f"Erro na simulação da estação {station_id}: {e}")
                time.sleep(interval)

    def start_simulation(self, stations: List[str], interval: int = 10):
        """
        Iniciar simulação para múltiplas estações.

        Args:
            stations: Lista de IDs das estações
            interval: Intervalo entre leituras (segundos)
        """
        if self.running:
            logger.warning("Simulação já está rodando")
            return

        self.running = True
        self.stats["start_time"] = datetime.utcnow()

        logger.info(f"Iniciando simulação para {len(stations)} estações")

        # Criar thread para cada estação
        for station_id in stations:
            thread = threading.Thread(
                target=self.simulate_station,
                args=(station_id, interval),
                daemon=True
            )
            thread.start()
            self.threads.append(thread)

        logger.info("Simulação iniciada com sucesso")

    def stop_simulation(self):
        """Parar simulação."""
        if not self.running:
            logger.warning("Simulação não está rodando")
            return

        logger.info("Parando simulação...")
        self.running = False

        # Aguardar threads terminarem
        for thread in self.threads:
            thread.join(timeout=1)

        self.threads.clear()
        logger.info("Simulação parada")

    def get_stats(self) -> Dict:
        """Obter estatísticas da simulação."""
        stats = self.stats.copy()
        if stats["start_time"]:
            stats["uptime"] = str(datetime.utcnow() - stats["start_time"])
        return stats

    def run_batch_simulation(self, stations: List[str], duration_minutes: int = 60):
        """
        Executar simulação em lote por tempo determinado.

        Args:
            stations: Lista de estações
            duration_minutes: Duração em minutos
        """
        logger.info(f"Iniciando simulação em lote por {duration_minutes} minutos")

        self.start_simulation(stations, interval=30)  # Leitura a cada 30 segundos

        try:
            time.sleep(duration_minutes * 60)
        except KeyboardInterrupt:
            logger.info("Simulação interrompida pelo usuário")
        finally:
            self.stop_simulation()

        # Exibir estatísticas
        stats = self.get_stats()
        logger.info(f"Simulação concluída. Estatísticas: {stats}")

def main():
    """Função principal para executar o simulador."""
    # Configurar simulador
    simulator = SensorSimulator()

    # Estações para simular
    stations = ["STATION_001", "STATION_002", "STATION_003"]

    try:
        # Executar simulação
        simulator.run_batch_simulation(stations, duration_minutes=30)
    except KeyboardInterrupt:
        logger.info("Simulação interrompida")
    finally:
        simulator.stop_simulation()

if __name__ == "__main__":
    main()
