"""
Testes para módulos de integração (MQTT, Webhooks, APIs externas).
"""

import pytest
import json
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime, timedelta

from app.integration.mqtt_client import MQTTClientService
from app.integration.webhook_handler import WebhookHandler
from app.integration.external_api import ExternalAPIService
from app.integration.data_processor import DataProcessor

@pytest.mark.integration
class TestMQTTClientService:
    """Testes para o serviço cliente MQTT."""
    
    def test_mqtt_client_initialization(self):
        """Testar inicialização do cliente MQTT."""
        mqtt_service = MQTTClientService()
        
        assert mqtt_service.client is not None
        assert mqtt_service.is_connected is False
        assert mqtt_service.message_count == 0
        assert mqtt_service.error_count == 0
        assert isinstance(mqtt_service.topics, dict)
        assert "sensor_data" in mqtt_service.topics
    
    @patch('paho.mqtt.client.Client')
    def test_mqtt_connect_success(self, mock_mqtt_client):
        """Testar conexão MQTT bem-sucedida."""
        # Configurar mock
        mock_client_instance = Mock()
        mock_mqtt_client.return_value = mock_client_instance
        mock_client_instance.connect.return_value = 0  # MQTT_ERR_SUCCESS
        
        mqtt_service = MQTTClientService()
        result = mqtt_service.connect()
        
        assert result is True
        mock_client_instance.connect.assert_called_once()
        mock_client_instance.loop_start.assert_called_once()
    
    @patch('paho.mqtt.client.Client')
    def test_mqtt_connect_failure(self, mock_mqtt_client):
        """Testar falha na conexão MQTT."""
        # Configurar mock
        mock_client_instance = Mock()
        mock_mqtt_client.return_value = mock_client_instance
        mock_client_instance.connect.return_value = 1  # Erro de conexão
        
        mqtt_service = MQTTClientService()
        result = mqtt_service.connect()
        
        assert result is False
    
    def test_mqtt_message_processing(self, mock_sensor_data_batch, test_db):
        """Testar processamento de mensagens MQTT."""
        mqtt_service = MQTTClientService()
        
        # Simular mensagem MQTT
        mock_msg = Mock()
        mock_msg.topic = "fuel_op/sensors/STATION_001/data"
        mock_msg.payload.decode.return_value = json.dumps({
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 75.5,
            "unit": "percent",
            "quality_score": 0.95
        })
        
        # Processar mensagem
        with patch.object(mqtt_service, '_handle_sensor_data') as mock_handler:
            mqtt_service._on_message(None, None, mock_msg)
            
            assert mqtt_service.message_count == 1
            mock_handler.assert_called_once()
    
    def test_mqtt_invalid_json_handling(self):
        """Testar tratamento de JSON inválido."""
        mqtt_service = MQTTClientService()
        
        # Simular mensagem com JSON inválido
        mock_msg = Mock()
        mock_msg.topic = "fuel_op/sensors/STATION_001/data"
        mock_msg.payload.decode.return_value = "invalid json"
        
        mqtt_service._on_message(None, None, mock_msg)
        
        assert mqtt_service.error_count == 1
    
    def test_mqtt_publish_message(self):
        """Testar publicação de mensagem MQTT."""
        mqtt_service = MQTTClientService()
        mqtt_service.is_connected = True
        
        # Mock do cliente
        mqtt_service.client = Mock()
        mock_result = Mock()
        mock_result.rc = 0  # MQTT_ERR_SUCCESS
        mqtt_service.client.publish.return_value = mock_result
        
        # Publicar mensagem
        data = {"test": "message"}
        result = mqtt_service.publish("test/topic", data)
        
        assert result is True
        mqtt_service.client.publish.assert_called_once()
    
    def test_mqtt_subscribe_topic(self):
        """Testar inscrição em tópico MQTT."""
        mqtt_service = MQTTClientService()
        mqtt_service.is_connected = True
        
        # Mock do cliente
        mqtt_service.client = Mock()
        mqtt_service.client.subscribe.return_value = (0, 1)  # Success, message_id
        
        # Inscrever em tópico
        result = mqtt_service.subscribe("test/topic")
        
        assert result is True
        mqtt_service.client.subscribe.assert_called_once_with("test/topic", qos=1)
    
    def test_mqtt_get_stats(self):
        """Testar obtenção de estatísticas MQTT."""
        mqtt_service = MQTTClientService()
        mqtt_service.message_count = 10
        mqtt_service.error_count = 2
        
        stats = mqtt_service.get_stats()
        
        assert stats["message_count"] == 10
        assert stats["error_count"] == 2
        assert "is_connected" in stats
        assert "broker_host" in stats
        assert "subscribed_topics" in stats

@pytest.mark.integration
class TestWebhookHandler:
    """Testes para o handler de webhooks."""
    
    def test_webhook_handler_initialization(self):
        """Testar inicialização do handler de webhooks."""
        handler = WebhookHandler()
        
        assert isinstance(handler.webhook_configs, dict)
        assert "fuel_supplier" in handler.webhook_configs
        assert "iot_platform" in handler.webhook_configs
        assert handler.webhook_stats["total_received"] == 0
    
    @pytest.mark.asyncio
    async def test_process_webhook_unknown_provider(self, mock_webhook_payload):
        """Testar processamento de webhook de provedor desconhecido."""
        handler = WebhookHandler()
        
        # Mock da requisição
        mock_request = Mock()
        
        with pytest.raises(Exception):  # Deve levantar HTTPException
            await handler.process_webhook("unknown_provider", mock_request, mock_webhook_payload)
    
    @pytest.mark.asyncio
    async def test_process_fuel_supplier_webhook(self, mock_webhook_payload):
        """Testar processamento de webhook do fornecedor de combustível."""
        handler = WebhookHandler()
        
        # Mock da requisição sem verificação de assinatura
        mock_request = Mock()
        
        # Remover verificação de assinatura para teste
        handler.webhook_configs["fuel_supplier"]["secret_key"] = None
        
        with patch('app.integration.webhook_handler.SessionLocal') as mock_session:
            mock_db = Mock()
            mock_session.return_value.__enter__.return_value = mock_db
            
            result = await handler._process_fuel_supplier_webhook(mock_webhook_payload)
            
            assert result["status"] == "success"
            assert result["event_type"] == "sensor_data"
            assert "processed_count" in result
    
    @pytest.mark.asyncio
    async def test_process_iot_platform_webhook(self):
        """Testar processamento de webhook da plataforma IoT."""
        handler = WebhookHandler()
        
        payload = {
            "event": "device_data",
            "device": {
                "id": "DEVICE_001",
                "measurements": [
                    {
                        "sensor_type": "temperature",
                        "value": 25.5,
                        "unit": "celsius",
                        "confidence": 0.95
                    }
                ]
            }
        }
        
        with patch('app.integration.webhook_handler.SessionLocal') as mock_session:
            mock_db = Mock()
            mock_session.return_value.__enter__.return_value = mock_db
            
            result = await handler._process_iot_platform_webhook(payload)
            
            assert result["status"] == "success"
            assert result["event_type"] == "device_data"
            assert result["device_id"] == "DEVICE_001"
    
    def test_webhook_stats_tracking(self):
        """Testar rastreamento de estatísticas de webhook."""
        handler = WebhookHandler()
        
        # Simular processamento de webhooks
        handler.webhook_stats["total_received"] = 10
        handler.webhook_stats["successful_processed"] = 8
        handler.webhook_stats["failed_processed"] = 2
        
        stats = handler.get_webhook_stats()
        
        assert stats["total_received"] == 10
        assert stats["successful_processed"] == 8
        assert stats["failed_processed"] == 2
        assert stats["success_rate"] == 80.0
    
    def test_configure_webhook(self):
        """Testar configuração de webhook."""
        handler = WebhookHandler()
        
        new_config = {
            "secret_key": "new_secret",
            "signature_header": "X-New-Signature",
            "event_types": ["new_event"]
        }
        
        handler.configure_webhook("new_provider", new_config)
        
        assert "new_provider" in handler.webhook_configs
        assert handler.webhook_configs["new_provider"] == new_config

@pytest.mark.integration
class TestExternalAPIService:
    """Testes para o serviço de API externa."""
    
    def test_external_api_initialization(self):
        """Testar inicialização do serviço de API externa."""
        api_service = ExternalAPIService()
        
        assert api_service.session is not None
        assert api_service.base_timeout == 30
        assert api_service.max_retries == 3
    
    @patch('requests.Session.get')
    def test_fetch_fuel_prices_success(self, mock_get):
        """Testar busca bem-sucedida de preços de combustível."""
        # Mock da resposta
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "prices": [
                {"fuel_type": "gasoline", "price": 5.50, "currency": "BRL"},
                {"fuel_type": "diesel", "price": 4.80, "currency": "BRL"}
            ]
        }
        mock_get.return_value = mock_response
        
        api_service = ExternalAPIService()
        result = api_service.fetch_fuel_prices("SP")
        
        assert result is not None
        assert "prices" in result
        assert len(result["prices"]) == 2
    
    @patch('requests.Session.get')
    def test_fetch_fuel_prices_failure(self, mock_get):
        """Testar falha na busca de preços de combustível."""
        # Mock de erro de requisição
        mock_get.side_effect = Exception("Connection error")
        
        api_service = ExternalAPIService()
        result = api_service.fetch_fuel_prices("SP")
        
        assert result is None
    
    @patch('requests.Session.post')
    def test_send_alert_notification_success(self, mock_post):
        """Testar envio bem-sucedido de notificação de alerta."""
        # Mock da resposta
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "sent"}
        mock_post.return_value = mock_response
        
        api_service = ExternalAPIService()
        alert_data = {
            "station_id": "STATION_001",
            "message": "Nível baixo de combustível",
            "severity": "high"
        }
        
        result = api_service.send_alert_notification(alert_data)
        
        assert result is True
        mock_post.assert_called_once()
    
    def test_get_api_stats(self):
        """Testar obtenção de estatísticas da API."""
        api_service = ExternalAPIService()
        api_service.request_count = 15
        api_service.error_count = 2
        
        stats = api_service.get_api_stats()
        
        assert stats["total_requests"] == 15
        assert stats["error_count"] == 2
        assert stats["success_rate"] == (13/15) * 100

@pytest.mark.unit
class TestDataProcessor:
    """Testes para o processador de dados."""
    
    def test_data_processor_initialization(self):
        """Testar inicialização do processador de dados."""
        processor = DataProcessor()
        
        assert isinstance(processor.sensor_type_mappings, dict)
        assert isinstance(processor.unit_mappings, dict)
        assert isinstance(processor.sensor_ranges, dict)
        assert "fuel_level" in processor.sensor_type_mappings
    
    def test_normalize_sensor_data_valid(self):
        """Testar normalização de dados válidos."""
        processor = DataProcessor()
        
        raw_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 75.5,
            "unit": "percent",
            "quality_score": 0.95
        }
        
        normalized, errors = processor.normalize_sensor_data(raw_data)
        
        assert len(errors) == 0
        assert normalized["station_id"] == "STATION_001"
        assert normalized["sensor_type"] == "fuel_level"
        assert normalized["value"] == 75.5
        assert normalized["unit"] == "percent"
        assert normalized["quality_score"] == 0.95
    
    def test_normalize_sensor_data_missing_fields(self):
        """Testar normalização com campos obrigatórios ausentes."""
        processor = DataProcessor()
        
        raw_data = {
            "sensor_type": "fuel_level",
            "value": 75.5
            # station_id ausente
        }
        
        normalized, errors = processor.normalize_sensor_data(raw_data)
        
        assert len(errors) > 0
        assert any("station_id" in error for error in errors)
    
    def test_normalize_sensor_data_invalid_value(self):
        """Testar normalização com valor inválido."""
        processor = DataProcessor()
        
        raw_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": "invalid_number",
            "unit": "percent"
        }
        
        normalized, errors = processor.normalize_sensor_data(raw_data)
        
        assert len(errors) > 0
        assert any("numérico" in error for error in errors)
    
    def test_normalize_sensor_type_mapping(self):
        """Testar mapeamento de tipos de sensor."""
        processor = DataProcessor()
        
        # Testar mapeamentos existentes
        assert processor._normalize_sensor_type("tank_level") == "fuel_level"
        assert processor._normalize_sensor_type("temp") == "temperature"
        assert processor._normalize_sensor_type("pressao") == "pressure"
        
        # Testar tipo não mapeado
        assert processor._normalize_sensor_type("unknown_sensor") == "unknown_sensor"
    
    def test_normalize_unit_mapping(self):
        """Testar mapeamento de unidades."""
        processor = DataProcessor()
        
        # Testar mapeamentos existentes
        assert processor._normalize_unit("%") == "percent"
        assert processor._normalize_unit("°c") == "celsius"
        assert processor._normalize_unit("pressure_bar") == "bar"
        
        # Testar unidade não mapeada
        assert processor._normalize_unit("unknown_unit") == "unknown_unit"
    
    def test_validate_sensor_range_valid(self):
        """Testar validação de range válido."""
        processor = DataProcessor()
        
        # Valor dentro do range
        errors = processor._validate_sensor_range("fuel_level", 50.0)
        assert len(errors) == 0
        
        # Valor no limite inferior
        errors = processor._validate_sensor_range("fuel_level", 0.0)
        assert len(errors) == 0
        
        # Valor no limite superior
        errors = processor._validate_sensor_range("fuel_level", 100.0)
        assert len(errors) == 0
    
    def test_validate_sensor_range_invalid(self):
        """Testar validação de range inválido."""
        processor = DataProcessor()
        
        # Valor abaixo do range
        errors = processor._validate_sensor_range("fuel_level", -10.0)
        assert len(errors) > 0
        
        # Valor acima do range
        errors = processor._validate_sensor_range("fuel_level", 150.0)
        assert len(errors) > 0
    
    def test_batch_normalize_data(self, mock_sensor_data_batch):
        """Testar normalização em lote."""
        processor = DataProcessor()
        
        normalized_data, stats = processor.batch_normalize_data(mock_sensor_data_batch)
        
        assert stats["total_records"] == len(mock_sensor_data_batch)
        assert stats["successful_normalizations"] > 0
        assert len(normalized_data) == stats["successful_normalizations"]
        assert len(stats["sensor_types_found"]) > 0
        assert len(stats["stations_found"]) > 0
    
    def test_enrich_sensor_data(self):
        """Testar enriquecimento de dados de sensor."""
        processor = DataProcessor()
        
        sensor_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 75.0,
            "unit": "percent",
            "quality_score": 0.95
        }
        
        enriched = processor.enrich_sensor_data(sensor_data)
        
        assert "expected_unit" in enriched
        assert "valid_range" in enriched
        assert "range_percentage" in enriched
        assert "quality_classification" in enriched
        assert "processed_at" in enriched
        assert enriched["quality_classification"] == "excellent"
    
    def test_add_sensor_type_mapping(self):
        """Testar adição de mapeamento de tipo de sensor."""
        processor = DataProcessor()
        
        # Adicionar novo mapeamento
        processor.add_sensor_type_mapping("custom_sensor", ["custom", "special"])
        
        assert "custom_sensor" in processor.sensor_type_mappings
        assert "custom" in processor.sensor_type_mappings["custom_sensor"]
        assert "special" in processor.sensor_type_mappings["custom_sensor"]
    
    def test_set_sensor_range(self):
        """Testar definição de range de sensor."""
        processor = DataProcessor()
        
        # Definir novo range
        processor.set_sensor_range("custom_sensor", 0.0, 50.0, "custom_unit")
        
        assert "custom_sensor" in processor.sensor_ranges
        range_info = processor.sensor_ranges["custom_sensor"]
        assert range_info["min"] == 0.0
        assert range_info["max"] == 50.0
        assert range_info["unit"] == "custom_unit"

@pytest.mark.integration
class TestIntegrationEndpoints:
    """Testes para endpoints de integração."""
    
    def test_webhook_endpoint_fuel_supplier(self, client, mock_webhook_payload):
        """Testar endpoint de webhook do fornecedor."""
        response = client.post("/webhooks/fuel_supplier", json=mock_webhook_payload)
        
        # Pode falhar devido à verificação de assinatura, mas deve processar
        assert response.status_code in [200, 401]
    
    def test_mqtt_status_endpoint(self, client, authenticated_headers):
        """Testar endpoint de status MQTT."""
        response = client.get("/integration/mqtt/status", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        assert "is_connected" in data
        assert "message_count" in data
    
    def test_external_api_status_endpoint(self, client, authenticated_headers):
        """Testar endpoint de status da API externa."""
        response = client.get("/integration/external-api/status", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        assert "total_requests" in data
        assert "success_rate" in data

