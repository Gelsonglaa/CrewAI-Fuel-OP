"""
Testes para módulos de machine learning (detecção de anomalias e previsão de demanda).
"""

import pytest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from unittest.mock import Mock, patch

from app.ml.anomaly_detection_service import (
    AnomalyDetectionService,
    detect_anomaly,
    retrain_anomaly_model
)
from app.ml.demand_prediction_service import (
    DemandPredictionService,
    predict_consumption,
    retrain_demand_model
)

@pytest.mark.ml
class TestAnomalyDetectionService:
    """Testes para o serviço de detecção de anomalias."""
    
    def test_anomaly_service_initialization(self):
        """Testar inicialização do serviço de detecção de anomalias."""
        service = AnomalyDetectionService()
        
        assert service.model is not None
        assert service.contamination == 0.1
        assert service.is_trained is False
        assert service.feature_columns is not None
    
    def test_prepare_features_valid_data(self):
        """Testar preparação de features com dados válidos."""
        service = AnomalyDetectionService()
        
        sensor_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 75.5,
            "quality_score": 0.95,
            "timestamp": datetime.utcnow()
        }
        
        features = service._prepare_features(sensor_data)
        
        assert isinstance(features, np.ndarray)
        assert len(features) == len(service.feature_columns)
        assert not np.isnan(features).any()
    
    def test_prepare_features_missing_data(self):
        """Testar preparação de features com dados ausentes."""
        service = AnomalyDetectionService()
        
        sensor_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level"
            # value e quality_score ausentes
        }
        
        features = service._prepare_features(sensor_data)
        
        assert isinstance(features, np.ndarray)
        assert len(features) == len(service.feature_columns)
        # Valores ausentes devem ser preenchidos com 0
        assert features[service.feature_columns.index("value")] == 0.0
        assert features[service.feature_columns.index("quality_score")] == 0.0
    
    def test_encode_categorical_features(self):
        """Testar codificação de features categóricas."""
        service = AnomalyDetectionService()
        
        # Testar codificação de station_id
        encoded = service._encode_station_id("STATION_001")
        assert isinstance(encoded, (int, float))
        
        # Mesmo station_id deve ter mesma codificação
        encoded2 = service._encode_station_id("STATION_001")
        assert encoded == encoded2
        
        # Station_ids diferentes devem ter codificações diferentes
        encoded3 = service._encode_station_id("STATION_002")
        assert encoded != encoded3
    
    def test_train_model_with_data(self, mock_sensor_data_batch):
        """Testar treinamento do modelo com dados."""
        service = AnomalyDetectionService()
        
        # Converter dados para DataFrame
        df = pd.DataFrame(mock_sensor_data_batch)
        
        result = service.train_model(df)
        
        assert result is True
        assert service.is_trained is True
        assert service.training_stats is not None
        assert "training_samples" in service.training_stats
    
    def test_train_model_insufficient_data(self):
        """Testar treinamento com dados insuficientes."""
        service = AnomalyDetectionService()
        
        # DataFrame com poucos dados
        df = pd.DataFrame([{
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 75.0,
            "quality_score": 0.95
        }])
        
        result = service.train_model(df)
        
        assert result is False
        assert service.is_trained is False
    
    def test_detect_anomaly_trained_model(self, mock_ml_model):
        """Testar detecção de anomalia com modelo treinado."""
        service = AnomalyDetectionService()
        service.model = mock_ml_model
        service.is_trained = True
        
        sensor_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 15.0,  # Valor baixo que deve ser anomalia
            "quality_score": 0.95
        }
        
        result = service.detect_anomaly(sensor_data)
        
        assert isinstance(result, dict)
        assert "is_anomaly" in result
        assert "anomaly_score" in result
        assert "confidence" in result
        assert isinstance(result["is_anomaly"], bool)
    
    def test_detect_anomaly_untrained_model(self):
        """Testar detecção de anomalia com modelo não treinado."""
        service = AnomalyDetectionService()
        
        sensor_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 75.0,
            "quality_score": 0.95
        }
        
        result = service.detect_anomaly(sensor_data)
        
        assert result["is_anomaly"] is False
        assert result["anomaly_score"] == 0.0
    
    def test_get_model_info(self, mock_ml_model):
        """Testar obtenção de informações do modelo."""
        service = AnomalyDetectionService()
        service.model = mock_ml_model
        service.is_trained = True
        service.training_stats = {"training_samples": 100}
        
        info = service.get_model_info()
        
        assert "is_trained" in info
        assert "model_type" in info
        assert "contamination" in info
        assert "training_stats" in info
        assert info["is_trained"] is True
    
    def test_batch_detect_anomalies(self, mock_ml_model, mock_sensor_data_batch):
        """Testar detecção de anomalias em lote."""
        service = AnomalyDetectionService()
        service.model = mock_ml_model
        service.is_trained = True
        
        results = service.batch_detect_anomalies(mock_sensor_data_batch)
        
        assert isinstance(results, list)
        assert len(results) == len(mock_sensor_data_batch)
        
        for result in results:
            assert "is_anomaly" in result
            assert "anomaly_score" in result
            assert "sensor_data" in result

@pytest.mark.ml
class TestDemandPredictionService:
    """Testes para o serviço de previsão de demanda."""
    
    def test_demand_service_initialization(self):
        """Testar inicialização do serviço de previsão de demanda."""
        service = DemandPredictionService()
        
        assert service.model is not None
        assert service.is_trained is False
        assert service.feature_columns is not None
        assert service.lookback_hours == 24
    
    def test_prepare_time_series_features(self):
        """Testar preparação de features de série temporal."""
        service = DemandPredictionService()
        
        # Criar dados de série temporal
        base_time = datetime.utcnow()
        data = []
        
        for i in range(48):  # 48 horas de dados
            data.append({
                "timestamp": base_time - timedelta(hours=i),
                "value": 50 + np.sin(i * 0.1) * 10,  # Padrão senoidal
                "station_id": "STATION_001",
                "sensor_type": "fuel_level"
            })
        
        df = pd.DataFrame(data)
        df = df.sort_values("timestamp")
        
        features = service._prepare_time_series_features(df, "STATION_001")
        
        assert isinstance(features, np.ndarray)
        assert features.shape[1] == len(service.feature_columns)
        assert features.shape[0] > 0
    
    def test_extract_temporal_features(self):
        """Testar extração de features temporais."""
        service = DemandPredictionService()
        
        timestamp = datetime(2024, 1, 15, 14, 30, 0)  # Segunda-feira, 14:30
        
        features = service._extract_temporal_features(timestamp)
        
        assert len(features) == 4  # hour, day_of_week, day_of_month, month
        assert features[0] == 14  # hour
        assert features[1] == 0   # Monday (0-indexed)
        assert features[2] == 15  # day of month
        assert features[3] == 1   # January (1-indexed)
    
    def test_train_model_with_data(self):
        """Testar treinamento do modelo de previsão."""
        service = DemandPredictionService()
        
        # Criar dados de treinamento
        base_time = datetime.utcnow()
        data = []
        
        for i in range(100):  # 100 pontos de dados
            data.append({
                "timestamp": base_time - timedelta(hours=i),
                "value": 50 + np.random.normal(0, 5),
                "station_id": "STATION_001",
                "sensor_type": "fuel_level"
            })
        
        df = pd.DataFrame(data)
        
        result = service.train_model(df)
        
        assert result is True
        assert service.is_trained is True
        assert service.training_stats is not None
    
    def test_train_model_insufficient_data(self):
        """Testar treinamento com dados insuficientes."""
        service = DemandPredictionService()
        
        # Poucos dados para treinamento
        data = [{
            "timestamp": datetime.utcnow(),
            "value": 50.0,
            "station_id": "STATION_001",
            "sensor_type": "fuel_level"
        }]
        
        df = pd.DataFrame(data)
        
        result = service.train_model(df)
        
        assert result is False
        assert service.is_trained is False
    
    def test_predict_consumption_trained_model(self, mock_ml_model):
        """Testar previsão de consumo com modelo treinado."""
        service = DemandPredictionService()
        service.model = mock_ml_model
        service.is_trained = True
        
        # Mock do scaler
        service.scaler = Mock()
        service.scaler.transform.return_value = np.array([[0.5, 0.3, 0.2, 0.1]])
        service.scaler.inverse_transform.return_value = np.array([[45.0]])
        
        # Dados históricos
        historical_data = pd.DataFrame([{
            "timestamp": datetime.utcnow() - timedelta(hours=1),
            "value": 50.0,
            "station_id": "STATION_001",
            "sensor_type": "fuel_level"
        }])
        
        result = service.predict_consumption("STATION_001", historical_data, hours_ahead=6)
        
        assert isinstance(result, dict)
        assert "predictions" in result
        assert "total_predicted_consumption" in result
        assert "confidence_interval" in result
        assert len(result["predictions"]) == 6
    
    def test_predict_consumption_untrained_model(self):
        """Testar previsão com modelo não treinado."""
        service = DemandPredictionService()
        
        historical_data = pd.DataFrame([{
            "timestamp": datetime.utcnow(),
            "value": 50.0,
            "station_id": "STATION_001",
            "sensor_type": "fuel_level"
        }])
        
        result = service.predict_consumption("STATION_001", historical_data, hours_ahead=6)
        
        assert result is None
    
    def test_calculate_consumption_rate(self):
        """Testar cálculo de taxa de consumo."""
        service = DemandPredictionService()
        
        # Dados com tendência decrescente (consumo)
        base_time = datetime.utcnow()
        data = []
        
        for i in range(10):
            data.append({
                "timestamp": base_time - timedelta(hours=i),
                "value": 100 - i * 2,  # Decréscimo de 2 por hora
                "station_id": "STATION_001",
                "sensor_type": "fuel_level"
            })
        
        df = pd.DataFrame(data).sort_values("timestamp")
        
        consumption_rate = service._calculate_consumption_rate(df)
        
        assert consumption_rate > 0  # Taxa positiva indica consumo
        assert abs(consumption_rate - 2.0) < 0.5  # Aproximadamente 2 por hora
    
    def test_get_model_performance_metrics(self, mock_ml_model):
        """Testar obtenção de métricas de performance."""
        service = DemandPredictionService()
        service.model = mock_ml_model
        service.is_trained = True
        service.training_stats = {
            "training_samples": 100,
            "mse": 0.05,
            "mae": 0.15,
            "r2_score": 0.95
        }
        
        metrics = service.get_model_performance_metrics()
        
        assert "is_trained" in metrics
        assert "training_samples" in metrics
        assert "mse" in metrics
        assert "mae" in metrics
        assert "r2_score" in metrics
        assert metrics["is_trained"] is True

@pytest.mark.ml
class TestMLServiceFunctions:
    """Testes para funções de serviço de ML."""
    
    @patch('app.ml.anomaly_detection_service.anomaly_detection_service')
    def test_detect_anomaly_function(self, mock_service):
        """Testar função de detecção de anomalia."""
        # Configurar mock
        mock_service.detect_anomaly.return_value = {
            "is_anomaly": True,
            "anomaly_score": 0.85,
            "confidence": 0.92
        }
        
        sensor_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 15.0,
            "quality_score": 0.95
        }
        
        result = detect_anomaly(sensor_data)
        
        assert result["is_anomaly"] is True
        assert result["anomaly_score"] == 0.85
        mock_service.detect_anomaly.assert_called_once_with(sensor_data)
    
    @patch('app.ml.anomaly_detection_service.anomaly_detection_service')
    @patch('app.ml.anomaly_detection_service.SessionLocal')
    def test_retrain_anomaly_model_function(self, mock_session, mock_service):
        """Testar função de retreinamento do modelo de anomalia."""
        # Mock da sessão de banco
        mock_db = Mock()
        mock_session.return_value.__enter__.return_value = mock_db
        mock_db.query.return_value.all.return_value = []
        
        # Mock do serviço
        mock_service.train_model.return_value = True
        
        result = retrain_anomaly_model(contamination=0.15)
        
        assert result["status"] == "success"
        assert result["contamination"] == 0.15
        mock_service.train_model.assert_called_once()
    
    @patch('app.ml.demand_prediction_service.demand_prediction_service')
    def test_predict_consumption_function(self, mock_service):
        """Testar função de previsão de consumo."""
        # Configurar mock
        mock_service.predict_consumption.return_value = {
            "predictions": [
                {"timestamp": "2024-01-01T12:00:00", "predicted_consumption": 45.2},
                {"timestamp": "2024-01-01T13:00:00", "predicted_consumption": 43.8}
            ],
            "total_predicted_consumption": 89.0,
            "confidence_interval": {"lower": 85.0, "upper": 93.0}
        }
        
        # Mock da sessão de banco
        with patch('app.ml.demand_prediction_service.SessionLocal') as mock_session:
            mock_db = Mock()
            mock_session.return_value.__enter__.return_value = mock_db
            mock_db.query.return_value.filter.return_value.all.return_value = []
            
            result = predict_consumption("STATION_001", hours_ahead=2)
            
            assert result is not None
            assert "predictions" in result
            assert len(result["predictions"]) == 2
    
    @patch('app.ml.demand_prediction_service.demand_prediction_service')
    @patch('app.ml.demand_prediction_service.SessionLocal')
    def test_retrain_demand_model_function(self, mock_session, mock_service):
        """Testar função de retreinamento do modelo de demanda."""
        # Mock da sessão de banco
        mock_db = Mock()
        mock_session.return_value.__enter__.return_value = mock_db
        mock_db.query.return_value.all.return_value = []
        
        # Mock do serviço
        mock_service.train_model.return_value = True
        
        result = retrain_demand_model()
        
        assert result["status"] == "success"
        mock_service.train_model.assert_called_once()

@pytest.mark.ml
@pytest.mark.api
class TestMLEndpoints:
    """Testes para endpoints de ML."""
    
    def test_anomaly_detection_endpoint(self, client, authenticated_headers, sample_sensor_data):
        """Testar endpoint de detecção de anomalia."""
        response = client.post(
            "/ml/detect-anomaly",
            json=sample_sensor_data,
            headers=authenticated_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "is_anomaly" in data
        assert "anomaly_score" in data
    
    def test_retrain_anomaly_model_endpoint(self, client, authenticated_headers):
        """Testar endpoint de retreinamento do modelo de anomalia."""
        payload = {"contamination": 0.15}
        
        response = client.post(
            "/ml/retrain/anomaly-model",
            json=payload,
            headers=authenticated_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
    
    def test_predict_consumption_endpoint(self, client, authenticated_headers):
        """Testar endpoint de previsão de consumo."""
        payload = {
            "station_id": "STATION_001",
            "hours_ahead": 6
        }
        
        response = client.post(
            "/ml/predict/consumption",
            json=payload,
            headers=authenticated_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "predictions" in data or "error" in data
    
    def test_retrain_demand_model_endpoint(self, client, authenticated_headers):
        """Testar endpoint de retreinamento do modelo de demanda."""
        response = client.post(
            "/ml/retrain/demand-model",
            headers=authenticated_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
    
    def test_ml_model_status_endpoint(self, client, authenticated_headers):
        """Testar endpoint de status dos modelos ML."""
        response = client.get("/ml/status", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        assert "anomaly_detection" in data
        assert "demand_prediction" in data
    
    def test_ml_endpoints_unauthorized(self, client, sample_sensor_data):
        """Testar endpoints ML sem autenticação."""
        # Testar detecção de anomalia sem auth
        response = client.post("/ml/detect-anomaly", json=sample_sensor_data)
        assert response.status_code == 401
        
        # Testar retreinamento sem auth
        response = client.post("/ml/retrain/anomaly-model", json={"contamination": 0.1})
        assert response.status_code == 401
        
        # Testar previsão sem auth
        response = client.post("/ml/predict/consumption", json={"station_id": "STATION_001"})
        assert response.status_code == 401

@pytest.mark.ml
@pytest.mark.slow
class TestMLIntegration:
    """Testes de integração para módulos de ML."""
    
    def test_anomaly_detection_integration(self, test_db, mock_sensor_data_batch):
        """Testar integração completa de detecção de anomalias."""
        # Inserir dados no banco
        from app.core.database import SensorData
        
        for data in mock_sensor_data_batch:
            sensor = SensorData(**data)
            test_db.add(sensor)
        test_db.commit()
        
        # Testar detecção de anomalia
        anomaly_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 5.0,  # Valor muito baixo
            "quality_score": 0.95
        }
        
        result = detect_anomaly(anomaly_data)
        
        assert isinstance(result, dict)
        assert "is_anomaly" in result
        assert "anomaly_score" in result
    
    def test_demand_prediction_integration(self, test_db):
        """Testar integração completa de previsão de demanda."""
        # Inserir dados históricos no banco
        from app.core.database import SensorData
        
        base_time = datetime.utcnow()
        for i in range(50):
            sensor = SensorData(
                station_id="STATION_001",
                sensor_type="fuel_level",
                value=100 - i * 0.5,  # Consumo gradual
                unit="percent",
                quality_score=0.95,
                timestamp=base_time - timedelta(hours=i)
            )
            test_db.add(sensor)
        test_db.commit()
        
        # Testar previsão
        result = predict_consumption("STATION_001", hours_ahead=6)
        
        # Pode retornar None se modelo não estiver treinado
        assert result is None or isinstance(result, dict)

