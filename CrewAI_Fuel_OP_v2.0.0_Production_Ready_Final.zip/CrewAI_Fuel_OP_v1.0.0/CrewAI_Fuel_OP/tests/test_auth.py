"""
Testes para o módulo de autenticação.
"""

import pytest
from datetime import datetime, timedelta
from jose import jwt

from app.auth.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    verify_token
)
from app.auth.auth_service import AuthService
from app.auth.models import User
from app.core.config import settings

class TestPasswordSecurity:
    """Testes para funções de segurança de senha."""
    
    def test_password_hashing(self):
        """Testar hash de senha."""
        password = "test_password_123"
        hashed = get_password_hash(password)
        
        # Hash deve ser diferente da senha original
        assert hashed != password
        assert len(hashed) > 50  # Hash deve ter tamanho razoável
        
        # Verificar se a senha pode ser verificada
        assert verify_password(password, hashed) is True
        assert verify_password("wrong_password", hashed) is False
    
    def test_password_hashing_consistency(self):
        """Testar consistência do hash de senha."""
        password = "consistent_password"
        hash1 = get_password_hash(password)
        hash2 = get_password_hash(password)
        
        # Hashes devem ser diferentes (devido ao salt)
        assert hash1 != hash2
        
        # Mas ambos devem verificar a mesma senha
        assert verify_password(password, hash1) is True
        assert verify_password(password, hash2) is True

class TestTokenManagement:
    """Testes para gerenciamento de tokens JWT."""
    
    def test_create_access_token(self):
        """Testar criação de token de acesso."""
        data = {"sub": "testuser", "user_id": 1}
        token = create_access_token(data)
        
        # Token deve ser uma string não vazia
        assert isinstance(token, str)
        assert len(token) > 50
        
        # Decodificar token para verificar conteúdo
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        assert payload["sub"] == "testuser"
        assert payload["user_id"] == 1
        assert "exp" in payload
    
    def test_create_access_token_with_expiration(self):
        """Testar criação de token com expiração customizada."""
        data = {"sub": "testuser"}
        expires_delta = timedelta(minutes=15)
        token = create_access_token(data, expires_delta)
        
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        
        # Verificar se expiração está correta
        exp_timestamp = payload["exp"]
        expected_exp = datetime.utcnow() + expires_delta
        actual_exp = datetime.fromtimestamp(exp_timestamp)
        
        # Permitir diferença de alguns segundos
        assert abs((actual_exp - expected_exp).total_seconds()) < 5
    
    def test_verify_valid_token(self):
        """Testar verificação de token válido."""
        data = {"sub": "testuser", "user_id": 1}
        token = create_access_token(data)
        
        payload = verify_token(token)
        assert payload is not None
        assert payload["sub"] == "testuser"
        assert payload["user_id"] == 1
    
    def test_verify_invalid_token(self):
        """Testar verificação de token inválido."""
        invalid_token = "invalid.token.here"
        payload = verify_token(invalid_token)
        assert payload is None
    
    def test_verify_expired_token(self):
        """Testar verificação de token expirado."""
        data = {"sub": "testuser"}
        # Criar token que expira imediatamente
        expires_delta = timedelta(seconds=-1)
        token = create_access_token(data, expires_delta)
        
        payload = verify_token(token)
        assert payload is None

@pytest.mark.api
class TestAuthService:
    """Testes para o serviço de autenticação."""
    
    def test_create_user(self, test_db, sample_user_data):
        """Testar criação de usuário."""
        auth_service = AuthService(test_db)
        
        user = auth_service.create_user(sample_user_data)
        
        assert user is not None
        assert user.username == sample_user_data["username"]
        assert user.email == sample_user_data["email"]
        assert user.full_name == sample_user_data["full_name"]
        assert user.is_active == sample_user_data["is_active"]
        
        # Senha deve estar hasheada
        assert user.hashed_password != sample_user_data["password"]
        assert verify_password(sample_user_data["password"], user.hashed_password)
    
    def test_create_duplicate_user(self, test_db, sample_user_data):
        """Testar criação de usuário duplicado."""
        auth_service = AuthService(test_db)
        
        # Criar primeiro usuário
        user1 = auth_service.create_user(sample_user_data)
        assert user1 is not None
        
        # Tentar criar usuário duplicado
        user2 = auth_service.create_user(sample_user_data)
        assert user2 is None
    
    def test_authenticate_user_valid(self, test_db, sample_user_data):
        """Testar autenticação com credenciais válidas."""
        auth_service = AuthService(test_db)
        
        # Criar usuário
        created_user = auth_service.create_user(sample_user_data)
        assert created_user is not None
        
        # Autenticar
        authenticated_user = auth_service.authenticate_user(
            sample_user_data["username"],
            sample_user_data["password"]
        )
        
        assert authenticated_user is not None
        assert authenticated_user.id == created_user.id
        assert authenticated_user.username == sample_user_data["username"]
    
    def test_authenticate_user_invalid_username(self, test_db, sample_user_data):
        """Testar autenticação com username inválido."""
        auth_service = AuthService(test_db)
        
        # Criar usuário
        auth_service.create_user(sample_user_data)
        
        # Tentar autenticar com username incorreto
        authenticated_user = auth_service.authenticate_user(
            "wrong_username",
            sample_user_data["password"]
        )
        
        assert authenticated_user is None
    
    def test_authenticate_user_invalid_password(self, test_db, sample_user_data):
        """Testar autenticação com senha inválida."""
        auth_service = AuthService(test_db)
        
        # Criar usuário
        auth_service.create_user(sample_user_data)
        
        # Tentar autenticar com senha incorreta
        authenticated_user = auth_service.authenticate_user(
            sample_user_data["username"],
            "wrong_password"
        )
        
        assert authenticated_user is None
    
    def test_authenticate_inactive_user(self, test_db, sample_user_data):
        """Testar autenticação de usuário inativo."""
        auth_service = AuthService(test_db)
        
        # Criar usuário inativo
        sample_user_data["is_active"] = False
        created_user = auth_service.create_user(sample_user_data)
        assert created_user is not None
        
        # Tentar autenticar
        authenticated_user = auth_service.authenticate_user(
            sample_user_data["username"],
            sample_user_data["password"]
        )
        
        assert authenticated_user is None
    
    def test_get_user_by_username(self, test_db, sample_user_data):
        """Testar busca de usuário por username."""
        auth_service = AuthService(test_db)
        
        # Criar usuário
        created_user = auth_service.create_user(sample_user_data)
        
        # Buscar usuário
        found_user = auth_service.get_user_by_username(sample_user_data["username"])
        
        assert found_user is not None
        assert found_user.id == created_user.id
        assert found_user.username == sample_user_data["username"]
    
    def test_get_user_by_email(self, test_db, sample_user_data):
        """Testar busca de usuário por email."""
        auth_service = AuthService(test_db)
        
        # Criar usuário
        created_user = auth_service.create_user(sample_user_data)
        
        # Buscar usuário
        found_user = auth_service.get_user_by_email(sample_user_data["email"])
        
        assert found_user is not None
        assert found_user.id == created_user.id
        assert found_user.email == sample_user_data["email"]
    
    def test_update_user_password(self, test_db, sample_user_data):
        """Testar atualização de senha do usuário."""
        auth_service = AuthService(test_db)
        
        # Criar usuário
        created_user = auth_service.create_user(sample_user_data)
        old_password_hash = created_user.hashed_password
        
        # Atualizar senha
        new_password = "new_password_123"
        updated = auth_service.update_user_password(
            created_user.id,
            sample_user_data["password"],  # senha atual
            new_password
        )
        
        assert updated is True
        
        # Verificar se senha foi alterada
        updated_user = auth_service.get_user_by_username(sample_user_data["username"])
        assert updated_user.hashed_password != old_password_hash
        assert verify_password(new_password, updated_user.hashed_password)
        
        # Verificar se senha antiga não funciona mais
        assert verify_password(sample_user_data["password"], updated_user.hashed_password) is False
    
    def test_update_user_password_wrong_current(self, test_db, sample_user_data):
        """Testar atualização de senha com senha atual incorreta."""
        auth_service = AuthService(test_db)
        
        # Criar usuário
        created_user = auth_service.create_user(sample_user_data)
        
        # Tentar atualizar com senha atual incorreta
        updated = auth_service.update_user_password(
            created_user.id,
            "wrong_current_password",
            "new_password_123"
        )
        
        assert updated is False

@pytest.mark.api
class TestAuthEndpoints:
    """Testes para endpoints de autenticação."""
    
    def test_register_user(self, client, sample_user_data):
        """Testar endpoint de registro."""
        response = client.post("/auth/register", json=sample_user_data)
        
        assert response.status_code == 201
        data = response.json()
        
        assert data["username"] == sample_user_data["username"]
        assert data["email"] == sample_user_data["email"]
        assert data["full_name"] == sample_user_data["full_name"]
        assert data["is_active"] == sample_user_data["is_active"]
        assert "id" in data
        assert "hashed_password" not in data  # Não deve retornar senha
    
    def test_register_duplicate_user(self, client, sample_user_data):
        """Testar registro de usuário duplicado."""
        # Registrar primeiro usuário
        response1 = client.post("/auth/register", json=sample_user_data)
        assert response1.status_code == 201
        
        # Tentar registrar usuário duplicado
        response2 = client.post("/auth/register", json=sample_user_data)
        assert response2.status_code == 400
        assert "já existe" in response2.json()["detail"].lower()
    
    def test_login_valid_credentials(self, client, sample_user_data):
        """Testar login com credenciais válidas."""
        # Registrar usuário
        client.post("/auth/register", json=sample_user_data)
        
        # Fazer login
        login_data = {
            "username": sample_user_data["username"],
            "password": sample_user_data["password"]
        }
        response = client.post("/auth/login", data=login_data)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "access_token" in data
        assert data["token_type"] == "bearer"
        assert len(data["access_token"]) > 50
    
    def test_login_invalid_credentials(self, client, sample_user_data):
        """Testar login com credenciais inválidas."""
        # Registrar usuário
        client.post("/auth/register", json=sample_user_data)
        
        # Tentar login com senha incorreta
        login_data = {
            "username": sample_user_data["username"],
            "password": "wrong_password"
        }
        response = client.post("/auth/login", data=login_data)
        
        assert response.status_code == 401
        assert "credenciais" in response.json()["detail"].lower()
    
    def test_get_current_user(self, client, authenticated_headers, sample_user_data):
        """Testar endpoint para obter usuário atual."""
        response = client.get("/auth/me", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["username"] == sample_user_data["username"]
        assert data["email"] == sample_user_data["email"]
        assert "hashed_password" not in data
    
    def test_get_current_user_unauthorized(self, client):
        """Testar endpoint sem autenticação."""
        response = client.get("/auth/me")
        
        assert response.status_code == 401
    
    def test_get_current_user_invalid_token(self, client):
        """Testar endpoint com token inválido."""
        headers = {"Authorization": "Bearer invalid_token"}
        response = client.get("/auth/me", headers=headers)
        
        assert response.status_code == 401
    
    def test_change_password(self, client, authenticated_headers, sample_user_data):
        """Testar endpoint de mudança de senha."""
        password_data = {
            "current_password": sample_user_data["password"],
            "new_password": "new_secure_password_123"
        }
        
        response = client.post("/auth/change-password", 
                             json=password_data, 
                             headers=authenticated_headers)
        
        assert response.status_code == 200
        assert response.json()["message"] == "Senha alterada com sucesso"
        
        # Verificar se nova senha funciona
        login_data = {
            "username": sample_user_data["username"],
            "password": password_data["new_password"]
        }
        login_response = client.post("/auth/login", data=login_data)
        assert login_response.status_code == 200
    
    def test_change_password_wrong_current(self, client, authenticated_headers):
        """Testar mudança de senha com senha atual incorreta."""
        password_data = {
            "current_password": "wrong_current_password",
            "new_password": "new_secure_password_123"
        }
        
        response = client.post("/auth/change-password", 
                             json=password_data, 
                             headers=authenticated_headers)
        
        assert response.status_code == 400
        assert "atual" in response.json()["detail"].lower()

@pytest.mark.unit
class TestAuthModels:
    """Testes para modelos de autenticação."""
    
    def test_user_model_creation(self, test_db, sample_user_data):
        """Testar criação do modelo User."""
        hashed_password = get_password_hash(sample_user_data["password"])
        
        user = User(
            username=sample_user_data["username"],
            email=sample_user_data["email"],
            full_name=sample_user_data["full_name"],
            hashed_password=hashed_password,
            is_active=sample_user_data["is_active"]
        )
        
        test_db.add(user)
        test_db.commit()
        test_db.refresh(user)
        
        assert user.id is not None
        assert user.username == sample_user_data["username"]
        assert user.email == sample_user_data["email"]
        assert user.created_at is not None
        assert user.updated_at is not None
    
    def test_user_model_str_representation(self, sample_user_data):
        """Testar representação string do modelo User."""
        user = User(
            username=sample_user_data["username"],
            email=sample_user_data["email"],
            full_name=sample_user_data["full_name"],
            hashed_password="hashed",
            is_active=True
        )
        
        str_repr = str(user)
        assert sample_user_data["username"] in str_repr

