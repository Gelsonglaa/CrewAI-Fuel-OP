"""
Configurações e fixtures para testes do CrewAI Fuel OP.
"""

import pytest
import tempfile
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

from app.core.database import Base, get_db, SensorData, AnomalyEvent
from app.api.main import app
from app.core.config import settings

# Configuração de banco de dados de teste
TEST_DATABASE_URL = "sqlite:///./test.db"

@pytest.fixture(scope="session")
def test_engine():
    """Criar engine de teste."""
    engine = create_engine(TEST_DATABASE_URL, connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    yield engine
    Base.metadata.drop_all(bind=engine)
    # Limpar arquivo de teste
    if os.path.exists("./test.db"):
        os.remove("./test.db")

@pytest.fixture(scope="function")
def test_db(test_engine):
    """Criar sessão de banco de dados de teste."""
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)
    
    # Criar sessão
    db = TestingSessionLocal()
    
    try:
        yield db
    finally:
        db.close()
        
        # Limpar dados após cada teste
        for table in reversed(Base.metadata.sorted_tables):
            db.execute(table.delete())
        db.commit()

@pytest.fixture(scope="function")
def client(test_db):
    """Criar cliente de teste FastAPI."""
    def override_get_db():
        try:
            yield test_db
        finally:
            test_db.close()
    
    app.dependency_overrides[get_db] = override_get_db
    
    with TestClient(app) as test_client:
        yield test_client
    
    app.dependency_overrides.clear()

@pytest.fixture
def sample_sensor_data():
    """Dados de sensor de exemplo."""
    return {
        "station_id": "STATION_001",
        "sensor_type": "fuel_level",
        "value": 75.5,
        "unit": "percent",
        "quality_score": 0.95,
        "timestamp": datetime.utcnow()
    }

@pytest.fixture
def sample_anomaly_data():
    """Dados de anomalia de exemplo."""
    return {
        "station_id": "STATION_001",
        "sensor_type": "fuel_level",
        "sensor_value": 15.2,
        "anomaly_score": 0.89,
        "severity": "high",
        "description": "Nível de combustível criticamente baixo",
        "detected_at": datetime.utcnow()
    }

@pytest.fixture
def sample_user_data():
    """Dados de usuário de exemplo."""
    return {
        "username": "testuser",
        "email": "test@example.com",
        "password": "testpassword123",
        "full_name": "Test User",
        "is_active": True
    }

@pytest.fixture
def authenticated_headers(client, sample_user_data):
    """Headers de autenticação para testes."""
    # Criar usuário
    response = client.post("/auth/register", json=sample_user_data)
    assert response.status_code == 201
    
    # Fazer login
    login_data = {
        "username": sample_user_data["username"],
        "password": sample_user_data["password"]
    }
    response = client.post("/auth/login", data=login_data)
    assert response.status_code == 200
    
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}

@pytest.fixture
def mock_sensor_data_batch():
    """Lote de dados de sensores para testes."""
    base_time = datetime.utcnow()
    
    return [
        {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 85.0,
            "unit": "percent",
            "quality_score": 0.98,
            "timestamp": base_time - timedelta(minutes=30)
        },
        {
            "station_id": "STATION_001",
            "sensor_type": "pressure",
            "value": 2.3,
            "unit": "bar",
            "quality_score": 0.95,
            "timestamp": base_time - timedelta(minutes=25)
        },
        {
            "station_id": "STATION_002",
            "sensor_type": "fuel_level",
            "value": 45.2,
            "unit": "percent",
            "quality_score": 0.92,
            "timestamp": base_time - timedelta(minutes=20)
        },
        {
            "station_id": "STATION_002",
            "sensor_type": "temperature",
            "value": 28.5,
            "unit": "celsius",
            "quality_score": 0.97,
            "timestamp": base_time - timedelta(minutes=15)
        }
    ]

@pytest.fixture
def mock_webhook_payload():
    """Payload de webhook de exemplo."""
    return {
        "event_type": "sensor_data",
        "data": {
            "sensors": [
                {
                    "station_id": "STATION_001",
                    "type": "fuel_level",
                    "value": 67.8,
                    "unit": "percent",
                    "quality": 0.94
                },
                {
                    "station_id": "STATION_001", 
                    "type": "pressure",
                    "value": 2.1,
                    "unit": "bar",
                    "quality": 0.96
                }
            ]
        },
        "timestamp": datetime.utcnow().isoformat()
    }

@pytest.fixture
def mock_mqtt_message():
    """Mensagem MQTT de exemplo."""
    return {
        "topic": "fuel_op/sensors/STATION_001/data",
        "payload": {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level",
            "value": 72.3,
            "unit": "percent",
            "quality_score": 0.93,
            "timestamp": datetime.utcnow().isoformat()
        }
    }

@pytest.fixture
def temp_file():
    """Arquivo temporário para testes."""
    with tempfile.NamedTemporaryFile(mode='w+', delete=False) as f:
        yield f.name
    
    # Limpar arquivo após teste
    if os.path.exists(f.name):
        os.remove(f.name)

@pytest.fixture
def mock_ml_model():
    """Mock de modelo de ML para testes."""
    class MockMLModel:
        def __init__(self):
            self.is_trained = True
            self.model_version = "test_v1.0"
        
        def predict(self, data):
            # Simular predição
            if isinstance(data, list):
                return [0.1 if i % 3 == 0 else 0.05 for i in range(len(data))]
            return 0.1 if data.get("value", 0) < 20 else 0.05
        
        def fit(self, X, y=None):
            return self
        
        def score(self, X, y=None):
            return 0.95
    
    return MockMLModel()

# Configurações de teste
@pytest.fixture(autouse=True)
def setup_test_environment(monkeypatch):
    """Configurar ambiente de teste."""
    # Configurar variáveis de ambiente para teste
    monkeypatch.setenv("TESTING", "true")
    monkeypatch.setenv("DATABASE_URL", TEST_DATABASE_URL)
    monkeypatch.setenv("SECRET_KEY", "test_secret_key_for_testing_only")
    monkeypatch.setenv("ALGORITHM", "HS256")
    monkeypatch.setenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30")

# Marcadores de teste
def pytest_configure(config):
    """Configurar marcadores de teste."""
    config.addinivalue_line(
        "markers", "unit: marca testes unitários"
    )
    config.addinivalue_line(
        "markers", "integration: marca testes de integração"
    )
    config.addinivalue_line(
        "markers", "api: marca testes de API"
    )
    config.addinivalue_line(
        "markers", "ml: marca testes de machine learning"
    )
    config.addinivalue_line(
        "markers", "slow: marca testes lentos"
    )

# Configurações de coleta de testes
def pytest_collection_modifyitems(config, items):
    """Modificar coleta de testes."""
    # Adicionar marcador 'unit' para testes que não têm outros marcadores
    for item in items:
        if not any(marker.name in ['integration', 'api', 'ml', 'slow'] 
                  for marker in item.iter_markers()):
            item.add_marker(pytest.mark.unit)

