# Módulo de testes para CrewAI Fuel OP

