"""
Testes para endpoints da API principal.
"""

import pytest
from datetime import datetime, timedelta

from app.core.database import SensorData, AnomalyEvent

@pytest.mark.api
class TestHealthEndpoints:
    """Testes para endpoints de saúde do sistema."""
    
    def test_health_check(self, client):
        """Testar endpoint de health check."""
        response = client.get("/health")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "status" in data
        assert "timestamp" in data
        assert "database" in data
        assert data["status"] in ["healthy", "unhealthy"]
    
    def test_health_detailed(self, client, authenticated_headers):
        """Testar endpoint de health check detalhado."""
        response = client.get("/health/detailed", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "status" in data
        assert "database" in data
        assert "ml_services" in data
        assert "system_info" in data

@pytest.mark.api
class TestStationsEndpoints:
    """Testes para endpoints de estações."""
    
    def test_get_stations_empty(self, client, authenticated_headers):
        """Testar listagem de estações vazia."""
        response = client.get("/stations", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "stations" in data
        assert isinstance(data["stations"], list)
    
    def test_get_stations_with_data(self, client, authenticated_headers, test_db, mock_sensor_data_batch):
        """Testar listagem de estações com dados."""
        # Inserir dados de sensores
        for sensor_data in mock_sensor_data_batch:
            sensor = SensorData(**sensor_data)
            test_db.add(sensor)
        test_db.commit()
        
        response = client.get("/stations", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "stations" in data
        assert len(data["stations"]) > 0
        
        # Verificar estrutura da estação
        station = data["stations"][0]
        assert "station_id" in station
        assert "last_update" in station
        assert "sensor_count" in station
    
    def test_get_station_detail(self, client, authenticated_headers, test_db, mock_sensor_data_batch):
        """Testar detalhes de estação específica."""
        # Inserir dados
        for sensor_data in mock_sensor_data_batch:
            sensor = SensorData(**sensor_data)
            test_db.add(sensor)
        test_db.commit()
        
        station_id = mock_sensor_data_batch[0]["station_id"]
        response = client.get(f"/stations/{station_id}", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["station_id"] == station_id
        assert "sensors" in data
        assert "last_update" in data
        assert "status" in data
    
    def test_get_station_not_found(self, client, authenticated_headers):
        """Testar busca de estação inexistente."""
        response = client.get("/stations/NONEXISTENT", headers=authenticated_headers)
        
        assert response.status_code == 404
        assert "não encontrada" in response.json()["detail"].lower()

@pytest.mark.api
class TestSensorDataEndpoints:
    """Testes para endpoints de dados de sensores."""
    
    def test_get_sensor_data_empty(self, client, authenticated_headers):
        """Testar busca de dados de sensor sem dados."""
        response = client.get("/sensor-data/STATION_001", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "sensor_data" in data
        assert isinstance(data["sensor_data"], list)
        assert len(data["sensor_data"]) == 0
    
    def test_get_sensor_data_with_data(self, client, authenticated_headers, test_db, mock_sensor_data_batch):
        """Testar busca de dados de sensor com dados."""
        # Inserir dados
        for sensor_data in mock_sensor_data_batch:
            sensor = SensorData(**sensor_data)
            test_db.add(sensor)
        test_db.commit()
        
        station_id = mock_sensor_data_batch[0]["station_id"]
        response = client.get(f"/sensor-data/{station_id}", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "sensor_data" in data
        assert len(data["sensor_data"]) > 0
        
        # Verificar estrutura dos dados
        sensor_data = data["sensor_data"][0]
        assert "station_id" in sensor_data
        assert "sensor_type" in sensor_data
        assert "value" in sensor_data
        assert "timestamp" in sensor_data
    
    def test_get_sensor_data_with_filters(self, client, authenticated_headers, test_db, mock_sensor_data_batch):
        """Testar busca de dados com filtros."""
        # Inserir dados
        for sensor_data in mock_sensor_data_batch:
            sensor = SensorData(**sensor_data)
            test_db.add(sensor)
        test_db.commit()
        
        station_id = mock_sensor_data_batch[0]["station_id"]
        
        # Testar filtro por tipo de sensor
        response = client.get(
            f"/sensor-data/{station_id}",
            params={"sensor_type": "fuel_level"},
            headers=authenticated_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        
        # Todos os dados devem ser do tipo especificado
        for sensor_data in data["sensor_data"]:
            assert sensor_data["sensor_type"] == "fuel_level"
        
        # Testar filtro por período
        response = client.get(
            f"/sensor-data/{station_id}",
            params={"hours_back": 1},
            headers=authenticated_headers
        )
        
        assert response.status_code == 200
    
    def test_post_sensor_data(self, client, authenticated_headers, sample_sensor_data):
        """Testar inserção de dados de sensor."""
        # Remover timestamp para testar geração automática
        sensor_data = sample_sensor_data.copy()
        del sensor_data["timestamp"]
        
        response = client.post("/sensor-data", json=sensor_data, headers=authenticated_headers)
        
        assert response.status_code == 201
        data = response.json()
        
        assert data["station_id"] == sensor_data["station_id"]
        assert data["sensor_type"] == sensor_data["sensor_type"]
        assert data["value"] == sensor_data["value"]
        assert "id" in data
        assert "timestamp" in data
    
    def test_post_sensor_data_invalid(self, client, authenticated_headers):
        """Testar inserção de dados inválidos."""
        invalid_data = {
            "station_id": "STATION_001",
            "sensor_type": "fuel_level"
            # value ausente
        }
        
        response = client.post("/sensor-data", json=invalid_data, headers=authenticated_headers)
        
        assert response.status_code == 422  # Validation error
    
    def test_post_sensor_data_batch(self, client, authenticated_headers, mock_sensor_data_batch):
        """Testar inserção em lote de dados de sensor."""
        # Remover timestamps para testar geração automática
        batch_data = []
        for sensor_data in mock_sensor_data_batch:
            data = sensor_data.copy()
            del data["timestamp"]
            batch_data.append(data)
        
        response = client.post("/sensor-data/batch", json={"sensor_data": batch_data}, headers=authenticated_headers)
        
        assert response.status_code == 201
        data = response.json()
        
        assert "inserted_count" in data
        assert data["inserted_count"] == len(batch_data)
        assert "sensor_data" in data

@pytest.mark.api
class TestAnomaliesEndpoints:
    """Testes para endpoints de anomalias."""
    
    def test_get_anomalies_empty(self, client, authenticated_headers):
        """Testar busca de anomalias sem dados."""
        response = client.get("/anomalies", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "anomalies" in data
        assert isinstance(data["anomalies"], list)
        assert len(data["anomalies"]) == 0
    
    def test_get_anomalies_with_data(self, client, authenticated_headers, test_db, sample_anomaly_data):
        """Testar busca de anomalias com dados."""
        # Inserir anomalia
        anomaly = AnomalyEvent(**sample_anomaly_data)
        test_db.add(anomaly)
        test_db.commit()
        
        response = client.get("/anomalies", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "anomalies" in data
        assert len(data["anomalies"]) > 0
        
        # Verificar estrutura da anomalia
        anomaly_data = data["anomalies"][0]
        assert "station_id" in anomaly_data
        assert "sensor_type" in anomaly_data
        assert "severity" in anomaly_data
        assert "anomaly_score" in anomaly_data
    
    def test_get_anomalies_with_filters(self, client, authenticated_headers, test_db):
        """Testar busca de anomalias com filtros."""
        # Inserir anomalias com diferentes severidades
        anomalies = [
            AnomalyEvent(
                station_id="STATION_001",
                sensor_type="fuel_level",
                sensor_value=15.0,
                anomaly_score=0.9,
                severity="high",
                description="Nível baixo",
                detected_at=datetime.utcnow()
            ),
            AnomalyEvent(
                station_id="STATION_002",
                sensor_type="pressure",
                sensor_value=3.5,
                anomaly_score=0.7,
                severity="medium",
                description="Pressão alta",
                detected_at=datetime.utcnow()
            )
        ]
        
        for anomaly in anomalies:
            test_db.add(anomaly)
        test_db.commit()
        
        # Testar filtro por severidade
        response = client.get("/anomalies", params={"severity": "high"}, headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert len(data["anomalies"]) == 1
        assert data["anomalies"][0]["severity"] == "high"
        
        # Testar filtro por estação
        response = client.get("/anomalies", params={"station_id": "STATION_001"}, headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert len(data["anomalies"]) == 1
        assert data["anomalies"][0]["station_id"] == "STATION_001"
    
    def test_post_anomaly(self, client, authenticated_headers, sample_anomaly_data):
        """Testar inserção de anomalia."""
        # Remover timestamp para testar geração automática
        anomaly_data = sample_anomaly_data.copy()
        del anomaly_data["detected_at"]
        
        response = client.post("/anomalies", json=anomaly_data, headers=authenticated_headers)
        
        assert response.status_code == 201
        data = response.json()
        
        assert data["station_id"] == anomaly_data["station_id"]
        assert data["severity"] == anomaly_data["severity"]
        assert "id" in data
        assert "detected_at" in data
    
    def test_resolve_anomaly(self, client, authenticated_headers, test_db, sample_anomaly_data):
        """Testar resolução de anomalia."""
        # Inserir anomalia
        anomaly = AnomalyEvent(**sample_anomaly_data)
        test_db.add(anomaly)
        test_db.commit()
        test_db.refresh(anomaly)
        
        # Resolver anomalia
        response = client.patch(
            f"/anomalies/{anomaly.id}/resolve",
            json={"resolution_notes": "Problema resolvido"},
            headers=authenticated_headers
        )
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["is_resolved"] is True
        assert data["resolution_notes"] == "Problema resolvido"
        assert "resolved_at" in data

@pytest.mark.api
class TestStatsEndpoints:
    """Testes para endpoints de estatísticas."""
    
    def test_dashboard_stats(self, client, authenticated_headers):
        """Testar estatísticas do dashboard."""
        response = client.get("/stats/dashboard", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert "overview" in data
        assert "sensors" in data
        assert "anomalies" in data
        assert "system" in data
        
        # Verificar estrutura do overview
        overview = data["overview"]
        assert "active_stations" in overview
        assert "total_sensors" in overview
        assert "recent_data_points" in overview
        assert "unresolved_anomalies" in overview
    
    def test_dashboard_stats_with_data(self, client, authenticated_headers, test_db, mock_sensor_data_batch):
        """Testar estatísticas com dados."""
        # Inserir dados
        for sensor_data in mock_sensor_data_batch:
            sensor = SensorData(**sensor_data)
            test_db.add(sensor)
        test_db.commit()
        
        response = client.get("/stats/dashboard", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        # Deve ter estações ativas
        assert data["overview"]["active_stations"] > 0
        assert data["overview"]["total_sensors"] > 0
    
    def test_station_stats(self, client, authenticated_headers, test_db, mock_sensor_data_batch):
        """Testar estatísticas de estação específica."""
        # Inserir dados
        for sensor_data in mock_sensor_data_batch:
            sensor = SensorData(**sensor_data)
            test_db.add(sensor)
        test_db.commit()
        
        station_id = mock_sensor_data_batch[0]["station_id"]
        response = client.get(f"/stats/station/{station_id}", headers=authenticated_headers)
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["station_id"] == station_id
        assert "sensor_types" in data
        assert "data_quality" in data
        assert "recent_activity" in data

@pytest.mark.api
class TestAuthenticationRequired:
    """Testes para verificar autenticação obrigatória."""
    
    def test_endpoints_require_auth(self, client):
        """Testar que endpoints protegidos requerem autenticação."""
        protected_endpoints = [
            "/stations",
            "/sensor-data/STATION_001",
            "/anomalies",
            "/stats/dashboard",
            "/ml/status"
        ]
        
        for endpoint in protected_endpoints:
            response = client.get(endpoint)
            assert response.status_code == 401, f"Endpoint {endpoint} should require authentication"
    
    def test_post_endpoints_require_auth(self, client, sample_sensor_data):
        """Testar que endpoints POST protegidos requerem autenticação."""
        # Testar POST sensor-data
        response = client.post("/sensor-data", json=sample_sensor_data)
        assert response.status_code == 401
        
        # Testar POST anomalies
        response = client.post("/anomalies", json={"station_id": "STATION_001"})
        assert response.status_code == 401

@pytest.mark.api
class TestErrorHandling:
    """Testes para tratamento de erros."""
    
    def test_404_not_found(self, client):
        """Testar endpoint inexistente."""
        response = client.get("/nonexistent-endpoint")
        assert response.status_code == 404
    
    def test_method_not_allowed(self, client):
        """Testar método não permitido."""
        response = client.delete("/health")
        assert response.status_code == 405
    
    def test_validation_error(self, client, authenticated_headers):
        """Testar erro de validação."""
        invalid_data = {
            "station_id": "",  # Campo obrigatório vazio
            "sensor_type": "fuel_level",
            "value": "not_a_number"  # Tipo incorreto
        }
        
        response = client.post("/sensor-data", json=invalid_data, headers=authenticated_headers)
        assert response.status_code == 422
        
        error_data = response.json()
        assert "detail" in error_data
        assert isinstance(error_data["detail"], list)

@pytest.mark.api
@pytest.mark.integration
class TestAPIIntegration:
    """Testes de integração da API."""
    
    def test_complete_sensor_data_flow(self, client, authenticated_headers, sample_sensor_data):
        """Testar fluxo completo de dados de sensor."""
        # 1. Inserir dados de sensor
        response = client.post("/sensor-data", json=sample_sensor_data, headers=authenticated_headers)
        assert response.status_code == 201
        
        # 2. Buscar dados inseridos
        station_id = sample_sensor_data["station_id"]
        response = client.get(f"/sensor-data/{station_id}", headers=authenticated_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert len(data["sensor_data"]) > 0
        
        # 3. Verificar estatísticas
        response = client.get("/stats/dashboard", headers=authenticated_headers)
        assert response.status_code == 200
        
        stats = response.json()
        assert stats["overview"]["active_stations"] > 0
    
    def test_complete_anomaly_flow(self, client, authenticated_headers, sample_anomaly_data):
        """Testar fluxo completo de anomalias."""
        # 1. Inserir anomalia
        response = client.post("/anomalies", json=sample_anomaly_data, headers=authenticated_headers)
        assert response.status_code == 201
        
        anomaly_id = response.json()["id"]
        
        # 2. Buscar anomalias
        response = client.get("/anomalies", headers=authenticated_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert len(data["anomalies"]) > 0
        
        # 3. Resolver anomalia
        response = client.patch(
            f"/anomalies/{anomaly_id}/resolve",
            json={"resolution_notes": "Teste resolvido"},
            headers=authenticated_headers
        )
        assert response.status_code == 200
        
        # 4. Verificar resolução
        response = client.get("/anomalies", headers=authenticated_headers)
        resolved_anomaly = next(
            (a for a in response.json()["anomalies"] if a["id"] == anomaly_id),
            None
        )
        assert resolved_anomaly is not None
        assert resolved_anomaly["is_resolved"] is True

