"""
API REST principal do sistema CrewAI Fuel OP.
Fornece endpoints para monitoramento, anomalias, ML e dashboard.
"""

import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any
from fastapi import FastAPI, HTTPException, Depends, Query, Body, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..core.config import settings
from ..core.database import get_db, get_database_stats, SensorData, AnomalyEvent, ActionFeedback
from ..core.tools import (
    query_recent_sensor_data, get_recent_anomalies, 
    save_anomaly_record, log_action_feedback, get_system_status
)
from ..ml.anomaly_detection_service import anomaly_service, detect_anomaly
from ..ml.demand_forecasting_service import demand_service, predict_fuel_demand

logger = logging.getLogger(__name__)

# Modelos Pydantic
class SensorDataCreate(BaseModel):
    station_id: str = Field(..., description="ID da estação")
    sensor_type: str = Field(..., description="Tipo do sensor")
    value: float = Field(..., description="Valor medido")
    unit: str = Field(..., description="Unidade de medida")
    quality_score: Optional[float] = Field(1.0, description="Score de qualidade")

class AnomalyCreate(BaseModel):
    station_id: str
    sensor_type: str
    anomaly_score: float
    sensor_value: float
    threshold: Optional[float] = 0.7
    severity: Optional[str] = "medium"
    description: Optional[str] = None

class ActionFeedbackCreate(BaseModel):
    anomaly_id: int
    action_type: str
    action_description: str
    priority: Optional[str] = "medium"
    assigned_to: Optional[str] = None

class DemandPredictionRequest(BaseModel):
    station_id: str = "STATION_001"
    hours_ahead: int = Field(24, ge=1, le=168)

class HealthResponse(BaseModel):
    status: str
    timestamp: str
    version: str
    database: Dict[str, Any]
    ml_services: Dict[str, Any]

# Criar aplicação FastAPI
app = FastAPI(
    title="CrewAI Fuel OP System API",
    description="API REST para sistema de monitoramento de combustível com IA",
    version=settings.app_version,
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, especificar domínios
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", tags=["Health"])
async def root():
    """
    Endpoint raiz - Health check básico.
    """
    return {
        "message": "CrewAI Fuel OP System API",
        "version": settings.app_version,
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """
    Health check detalhado do sistema.
    """
    try:
        # Verificar banco de dados
        db_stats = get_database_stats()

        # Verificar serviços ML
        anomaly_info = anomaly_service.get_model_info()
        demand_info = demand_service.get_model_info()

        ml_status = {
            "anomaly_detection": {
                "status": "operational" if not anomaly_info.get("error") else "error",
                "model_loaded": anomaly_service.model is not None,
                "info": anomaly_info
            },
            "demand_forecasting": {
                "status": "operational" if not demand_info.get("error") else "error",
                "model_loaded": demand_service.model is not None,
                "info": demand_info
            }
        }

        return HealthResponse(
            status="healthy",
            timestamp=datetime.utcnow().isoformat(),
            version=settings.app_version,
            database=db_stats,
            ml_services=ml_status
        )

    except Exception as e:
        logger.error(f"Erro no health check: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/anomalies", tags=["Anomalies"])
async def get_anomalies(
    station_id: Optional[str] = Query(None, description="Filtrar por estação"),
    severity: Optional[str] = Query(None, description="Filtrar por severidade"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    limit: int = Query(50, ge=1, le=1000, description="Limite de resultados")
):
    """
    Obter lista de anomalias com filtros opcionais.
    """
    try:
        anomalies = get_recent_anomalies(
            station_id=station_id,
            severity=severity,
            status=status,
            limit=limit
        )

        return {
            "anomalies": anomalies,
            "count": len(anomalies),
            "filters": {
                "station_id": station_id,
                "severity": severity,
                "status": status,
                "limit": limit
            },
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Erro ao obter anomalias: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/anomalies", tags=["Anomalies"])
async def create_anomaly(anomaly_data: AnomalyCreate):
    """
    Criar registro de anomalia.
    """
    try:
        result = save_anomaly_record(
            station_id=anomaly_data.station_id,
            sensor_type=anomaly_data.sensor_type,
            anomaly_score=anomaly_data.anomaly_score,
            sensor_value=anomaly_data.sensor_value,
            threshold=anomaly_data.threshold,
            severity=anomaly_data.severity,
            description=anomaly_data.description
        )

        if not result:
            raise HTTPException(status_code=400, detail="Erro ao criar anomalia")

        return {
            "message": "Anomalia criada com sucesso",
            "anomaly": result
        }

    except Exception as e:
        logger.error(f"Erro ao criar anomalia: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/sensor-data/{station_id}", tags=["Sensor Data"])
async def get_sensor_data_by_station(
    station_id: str,
    sensor_type: Optional[str] = Query(None, description="Tipo do sensor"),
    hours_back: int = Query(24, ge=1, le=168, description="Horas para trás"),
    limit: int = Query(100, ge=1, le=1000, description="Limite de resultados")
):
    """
    Obter dados de sensores para uma estação específica.
    """
    try:
        data = query_recent_sensor_data(
            station_id=station_id,
            sensor_type=sensor_type,
            hours_back=hours_back,
            limit=limit
        )

        return {
            "station_id": station_id,
            "sensor_data": data,
            "count": len(data),
            "parameters": {
                "sensor_type": sensor_type,
                "hours_back": hours_back,
                "limit": limit
            },
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Erro ao obter dados do sensor: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/sensor-data", tags=["Sensor Data"])
async def create_sensor_data(
    sensor_data: SensorDataCreate,
    db: Session = Depends(get_db)
):
    """
    Criar novo registro de dados do sensor.
    """
    try:
        # Criar registro no banco
        db_sensor = SensorData(
            station_id=sensor_data.station_id,
            sensor_type=sensor_data.sensor_type,
            value=sensor_data.value,
            unit=sensor_data.unit,
            quality_score=sensor_data.quality_score
        )

        db.add(db_sensor)
        db.commit()
        db.refresh(db_sensor)

        # Verificar anomalia
        sensor_dict = {
            "station_id": sensor_data.station_id,
            "sensor_type": sensor_data.sensor_type,
            "value": sensor_data.value,
            "quality_score": sensor_data.quality_score,
            "timestamp": db_sensor.timestamp.isoformat()
        }

        anomaly_result = detect_anomaly(sensor_dict)

        return {
            "message": "Dados do sensor criados com sucesso",
            "sensor_data": {
                "id": db_sensor.id,
                "station_id": db_sensor.station_id,
                "sensor_type": db_sensor.sensor_type,
                "value": db_sensor.value,
                "timestamp": db_sensor.timestamp.isoformat()
            },
            "anomaly_check": anomaly_result
        }

    except Exception as e:
        logger.error(f"Erro ao criar dados do sensor: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/retrain/anomaly-model", tags=["Machine Learning"])
async def retrain_anomaly_model(
    contamination: float = Body(0.1, embed=True, description="Proporção de anomalias")
):
    """
    Retreinar modelo de detecção de anomalias.
    """
    try:
        success = anomaly_service.train_model(contamination=contamination)

        if success:
            return {
                "message": "Modelo de detecção de anomalias retreinado com sucesso",
                "timestamp": datetime.utcnow().isoformat(),
                "model_info": anomaly_service.get_model_info()
            }
        else:
            raise HTTPException(status_code=500, detail="Falha no retreinamento")

    except Exception as e:
        logger.error(f"Erro no retreinamento: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/retrain/demand-model", tags=["Machine Learning"])
async def retrain_demand_model():
    """
    Retreinar modelo de previsão de demanda.
    """
    try:
        success = demand_service.train_model()

        if success:
            return {
                "message": "Modelo de previsão de demanda retreinado com sucesso",
                "timestamp": datetime.utcnow().isoformat(),
                "model_info": demand_service.get_model_info()
            }
        else:
            raise HTTPException(status_code=500, detail="Falha no retreinamento")

    except Exception as e:
        logger.error(f"Erro no retreinamento: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/demand", tags=["Machine Learning"])
async def predict_demand(request: DemandPredictionRequest):
    """
    Fazer previsão de demanda de combustível.
    """
    try:
        prediction = predict_fuel_demand(
            hours_ahead=request.hours_ahead,
            station_id=request.station_id
        )

        if "error" in prediction:
            raise HTTPException(status_code=400, detail=prediction["error"])

        return {
            "message": "Previsão gerada com sucesso",
            "prediction": prediction,
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Erro na previsão: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/anomaly", tags=["Machine Learning"])
async def predict_anomaly(sensor_data: Dict[str, Any] = Body(...)):
    """
    Detectar anomalia em dados do sensor.
    """
    try:
        result = detect_anomaly(sensor_data)

        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])

        return {
            "message": "Análise de anomalia concluída",
            "result": result,
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Erro na detecção de anomalia: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/stats/dashboard", tags=["Dashboard"])
async def get_dashboard_stats():
    """
    Obter estatísticas para dashboard.
    """
    try:
        # Estatísticas do sistema
        system_status = get_system_status()
        db_stats = get_database_stats()

        # Estatísticas de anomalias por severidade
        recent_anomalies = get_recent_anomalies(limit=100)
        anomaly_stats = {"low": 0, "medium": 0, "high": 0, "critical": 0}

        for anomaly in recent_anomalies:
            severity = anomaly.get("severity", "medium")
            anomaly_stats[severity] = anomaly_stats.get(severity, 0) + 1

        # Dados recentes dos sensores
        recent_sensor_data = query_recent_sensor_data(hours_back=1, limit=50)

        # Estações ativas
        stations = list(set(data["station_id"] for data in recent_sensor_data))

        dashboard_stats = {
            "overview": {
                "total_stations": len(stations),
                "active_stations": len(stations),
                "total_sensors": db_stats.get("sensor_data_count", 0),
                "recent_data_points": len(recent_sensor_data),
                "unresolved_anomalies": db_stats.get("unresolved_anomalies", 0)
            },
            "anomalies": {
                "by_severity": anomaly_stats,
                "recent": recent_anomalies[:10],  # Últimas 10 anomalias
                "total": db_stats.get("anomaly_events_count", 0)
            },
            "sensors": {
                "recent_data": recent_sensor_data[:20],  # Últimos 20 dados
                "stations": stations
            },
            "system": system_status,
            "timestamp": datetime.utcnow().isoformat()
        }

        return dashboard_stats

    except Exception as e:
        logger.error(f"Erro ao obter estatísticas do dashboard: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/stations", tags=["Stations"])
async def get_stations():
    """
    Obter lista de estações disponíveis.
    """
    try:
        # Obter estações únicas dos dados recentes
        recent_data = query_recent_sensor_data(hours_back=24, limit=1000)
        stations = {}

        for data in recent_data:
            station_id = data["station_id"]
            if station_id not in stations:
                stations[station_id] = {
                    "station_id": station_id,
                    "sensor_types": [],
                    "last_update": None,
                    "status": "active"
                }

            sensor_type = data["sensor_type"]
            if sensor_type not in stations[station_id]["sensor_types"]:
                stations[station_id]["sensor_types"].append(sensor_type)

            # Atualizar último timestamp
            data_timestamp = data["timestamp"]
            if (not stations[station_id]["last_update"] or 
                data_timestamp > stations[station_id]["last_update"]):
                stations[station_id]["last_update"] = data_timestamp

        return {
            "stations": list(stations.values()),
            "count": len(stations),
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Erro ao obter estações: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/actions", tags=["Actions"])
async def create_action_feedback(action: ActionFeedbackCreate):
    """
    Criar feedback de ação.
    """
    try:
        result = log_action_feedback(
            anomaly_id=action.anomaly_id,
            action_type=action.action_type,
            action_description=action.action_description,
            priority=action.priority,
            assigned_to=action.assigned_to
        )

        if not result:
            raise HTTPException(status_code=400, detail="Erro ao criar ação")

        return {
            "message": "Ação registrada com sucesso",
            "action": result
        }

    except Exception as e:
        logger.error(f"Erro ao criar ação: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Handler para exceções globais
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.error(f"Erro global na API: {exc}")
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Erro interno do servidor",
            "timestamp": datetime.utcnow().isoformat()
        }
    )

# Evento de inicialização
@app.on_event("startup")
async def startup_event():
    """
    Evento executado na inicialização da aplicação.
    """
    logger.info("Iniciando CrewAI Fuel OP API...")
    logger.info(f"Versão: {settings.app_version}")
    logger.info(f"Ambiente: {settings.environment}")

# Evento de finalização
@app.on_event("shutdown")
async def shutdown_event():
    """
    Evento executado no shutdown da aplicação.
    """
    logger.info("Finalizando CrewAI Fuel OP API...")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
        log_level=settings.log_level.lower()
    )
