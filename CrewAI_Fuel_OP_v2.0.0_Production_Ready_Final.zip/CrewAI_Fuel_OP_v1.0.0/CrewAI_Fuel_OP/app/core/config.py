"""
Módulo de configuração centralizada do sistema CrewAI Fuel OP.
Gerencia todas as variáveis de ambiente e configurações da aplicação.
"""

import os
import logging
from pathlib import Path
from typing import Optional
from pydantic import BaseSettings, Field
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

class Settings(BaseSettings):
    """Configurações centralizadas da aplicação."""

    # Aplicação
    app_name: str = Field(default="CrewAI Fuel OP System", env="APP_NAME")
    app_version: str = Field(default="1.0.0", env="APP_VERSION")
    debug: bool = Field(default=False, env="DEBUG")
    environment: str = Field(default="production", env="ENVIRONMENT")

    # Banco de Dados
    database_url: str = Field(default="sqlite:///./data/fuel_op.db", env="DATABASE_URL")

    # MQTT
    mqtt_broker_url: str = Field(default="broker.hivemq.com", env="MQTT_BROKER_URL")
    mqtt_username: Optional[str] = Field(default=None, env="MQTT_USERNAME")
    mqtt_password: Optional[str] = Field(default=None, env="MQTT_PASSWORD")
    mqtt_port: int = Field(default=1883, env="MQTT_PORT")

    # Twilio
    twilio_sid: Optional[str] = Field(default=None, env="TWILIO_SID")
    twilio_auth_token: Optional[str] = Field(default=None, env="TWILIO_AUTH_TOKEN")
    twilio_phone_number: Optional[str] = Field(default=None, env="TWILIO_PHONE_NUMBER")
    whatsapp_phone_number: Optional[str] = Field(default=None, env="WHATSAPP_PHONE_NUMBER")

    # Email
    smtp_host: str = Field(default="smtp.gmail.com", env="SMTP_HOST")
    smtp_port: int = Field(default=587, env="SMTP_PORT")
    smtp_user: Optional[str] = Field(default=None, env="SMTP_USER")
    smtp_password: Optional[str] = Field(default=None, env="SMTP_PASSWORD")
    alert_email_receiver: Optional[str] = Field(default=None, env="ALERT_EMAIL_RECEIVER")

    # Segurança
    jwt_secret_key: str = Field(default="default-secret-key", env="JWT_SECRET_KEY")
    jwt_algorithm: str = Field(default="HS256", env="JWT_ALGORITHM")
    jwt_access_token_expire_minutes: int = Field(default=30, env="JWT_ACCESS_TOKEN_EXPIRE_MINUTES")

    # Logging
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    log_file: str = Field(default="logs/app.log", env="LOG_FILE")

    # Machine Learning
    ml_model_update_interval: int = Field(default=24, env="ML_MODEL_UPDATE_INTERVAL")
    anomaly_threshold: float = Field(default=0.7, env="ANOMALY_THRESHOLD")

    class Config:
        env_file = ".env"
        case_sensitive = False

def setup_logging(settings: Settings) -> None:
    """Configurar sistema de logging."""
    log_path = Path(settings.log_file)
    log_path.parent.mkdir(exist_ok=True)

    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_path),
            logging.StreamHandler()
        ]
    )

def validate_critical_settings(settings: Settings) -> None:
    """Validar configurações críticas para produção."""
    critical_errors = []

    if settings.environment == "production":
        if settings.jwt_secret_key == "default-secret-key":
            critical_errors.append("JWT_SECRET_KEY deve ser definida em produção")

        if not settings.database_url:
            critical_errors.append("DATABASE_URL deve ser definida")

    if critical_errors:
        error_message = "Configurações críticas faltando:\n" + "\n".join(critical_errors)
        raise ValueError(error_message)

# Instância global das configurações
settings = Settings()

# Configurar logging
setup_logging(settings)

# Validar configurações críticas
validate_critical_settings(settings)

# Logger para este módulo
logger = logging.getLogger(__name__)
logger.info(f"Configurações carregadas para ambiente: {settings.environment}")
