"""
Processador de dados para normalização e validação de dados de integração.
"""

import logging
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from sqlalchemy.orm import Session

from ..core.database import SessionLocal, SensorData, AnomalyEvent
from ..ml.anomaly_detection_service import detect_anomaly

logger = logging.getLogger(__name__)

class DataProcessor:
    """
    Processador para normalização, validação e enriquecimento de dados.
    """
    
    def __init__(self):
        # Mapeamentos de tipos de sensor
        self.sensor_type_mappings = {
            # Variações de nível de combustível
            "fuel_level": ["fuel_level", "tank_level", "level", "combustivel_nivel"],
            "pressure": ["pressure", "pressao", "press", "bar"],
            "temperature": ["temperature", "temp", "temperatura", "celsius"],
            "flow_rate": ["flow_rate", "flow", "vazao", "fluxo", "rate"],
            "humidity": ["humidity", "umidade", "humid"],
            "ph": ["ph", "acidity", "acidez"],
            "density": ["density", "densidade", "specific_gravity"]
        }
        
        # Mapeamentos de unidades
        self.unit_mappings = {
            # Percentual
            "percent": ["percent", "%", "percentage", "pct"],
            # Pressão
            "bar": ["bar", "bars", "pressure_bar"],
            "psi": ["psi", "pressure_psi"],
            "kpa": ["kpa", "kilopascal"],
            # Temperatura
            "celsius": ["celsius", "c", "°c", "degc"],
            "fahrenheit": ["fahrenheit", "f", "°f", "degf"],
            "kelvin": ["kelvin", "k"],
            # Vazão
            "l/min": ["l/min", "lpm", "liters_per_minute"],
            "m3/h": ["m3/h", "cubic_meters_per_hour"],
            "gal/min": ["gal/min", "gpm", "gallons_per_minute"],
            # Volume
            "liters": ["liters", "l", "litros"],
            "gallons": ["gallons", "gal", "galoes"],
            "m3": ["m3", "cubic_meters", "metros_cubicos"]
        }
        
        # Ranges válidos por tipo de sensor
        self.sensor_ranges = {
            "fuel_level": {"min": 0, "max": 100, "unit": "percent"},
            "pressure": {"min": 0, "max": 10, "unit": "bar"},
            "temperature": {"min": -40, "max": 80, "unit": "celsius"},
            "flow_rate": {"min": 0, "max": 1000, "unit": "l/min"},
            "humidity": {"min": 0, "max": 100, "unit": "percent"},
            "ph": {"min": 0, "max": 14, "unit": "ph"},
            "density": {"min": 0.5, "max": 2.0, "unit": "g/ml"}
        }
    
    def normalize_sensor_data(
        self, 
        raw_data: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], List[str]]:
        """
        Normalizar dados de sensor para formato padrão.
        
        Args:
            raw_data: Dados brutos do sensor
            
        Returns:
            Tupla (dados_normalizados, lista_de_erros)
        """
        errors = []
        normalized = {}
        
        try:
            # Normalizar station_id
            station_id = raw_data.get("station_id") or raw_data.get("stationId") or raw_data.get("id")
            if not station_id:
                errors.append("station_id é obrigatório")
            else:
                normalized["station_id"] = str(station_id).upper().strip()
            
            # Normalizar sensor_type
            sensor_type = raw_data.get("sensor_type") or raw_data.get("type") or raw_data.get("sensor")
            if not sensor_type:
                errors.append("sensor_type é obrigatório")
            else:
                normalized["sensor_type"] = self._normalize_sensor_type(str(sensor_type).lower().strip())
            
            # Normalizar value
            value = raw_data.get("value") or raw_data.get("measurement") or raw_data.get("reading")
            if value is None:
                errors.append("value é obrigatório")
            else:
                try:
                    normalized["value"] = float(value)
                except (ValueError, TypeError):
                    errors.append(f"value deve ser numérico: {value}")
            
            # Normalizar unit
            unit = raw_data.get("unit") or raw_data.get("units") or raw_data.get("measure_unit")
            if not unit:
                # Tentar inferir unidade baseada no tipo de sensor
                if "sensor_type" in normalized:
                    unit = self.sensor_ranges.get(normalized["sensor_type"], {}).get("unit", "unknown")
            
            normalized["unit"] = self._normalize_unit(str(unit).lower().strip())
            
            # Normalizar quality_score
            quality = raw_data.get("quality_score") or raw_data.get("quality") or raw_data.get("confidence")
            if quality is not None:
                try:
                    quality_score = float(quality)
                    # Garantir que está entre 0 e 1
                    if quality_score > 1:
                        quality_score = quality_score / 100  # Assumir que está em percentual
                    normalized["quality_score"] = max(0, min(1, quality_score))
                except (ValueError, TypeError):
                    normalized["quality_score"] = 1.0
            else:
                normalized["quality_score"] = 1.0
            
            # Normalizar timestamp
            timestamp = raw_data.get("timestamp") or raw_data.get("time") or raw_data.get("datetime")
            if timestamp:
                normalized["timestamp"] = self._normalize_timestamp(timestamp)
            else:
                normalized["timestamp"] = datetime.utcnow()
            
            # Validar ranges se não houver erros críticos
            if not errors and "sensor_type" in normalized and "value" in normalized:
                range_errors = self._validate_sensor_range(
                    normalized["sensor_type"], 
                    normalized["value"]
                )
                errors.extend(range_errors)
            
            return normalized, errors
            
        except Exception as e:
            logger.error(f"Erro na normalização de dados: {e}")
            errors.append(f"Erro interno na normalização: {str(e)}")
            return {}, errors
    
    def _normalize_sensor_type(self, sensor_type: str) -> str:
        """Normalizar tipo de sensor."""
        for standard_type, variations in self.sensor_type_mappings.items():
            if sensor_type in variations:
                return standard_type
        
        # Se não encontrou mapeamento, retornar o tipo original limpo
        return sensor_type.replace(" ", "_").replace("-", "_")
    
    def _normalize_unit(self, unit: str) -> str:
        """Normalizar unidade de medida."""
        for standard_unit, variations in self.unit_mappings.items():
            if unit in variations:
                return standard_unit
        
        # Se não encontrou mapeamento, retornar a unidade original limpa
        return unit.replace(" ", "_").replace("-", "_")
    
    def _normalize_timestamp(self, timestamp: Any) -> datetime:
        """Normalizar timestamp."""
        try:
            if isinstance(timestamp, datetime):
                return timestamp
            elif isinstance(timestamp, str):
                # Tentar vários formatos
                formats = [
                    "%Y-%m-%dT%H:%M:%S.%fZ",
                    "%Y-%m-%dT%H:%M:%SZ",
                    "%Y-%m-%d %H:%M:%S",
                    "%Y-%m-%d %H:%M:%S.%f",
                    "%d/%m/%Y %H:%M:%S",
                    "%Y-%m-%d"
                ]
                
                for fmt in formats:
                    try:
                        return datetime.strptime(timestamp, fmt)
                    except ValueError:
                        continue
                
                # Se nenhum formato funcionou, tentar parsing automático
                return pd.to_datetime(timestamp).to_pydatetime()
            
            elif isinstance(timestamp, (int, float)):
                # Assumir timestamp Unix
                return datetime.fromtimestamp(timestamp)
            
            else:
                return datetime.utcnow()
                
        except Exception as e:
            logger.warning(f"Erro ao normalizar timestamp {timestamp}: {e}")
            return datetime.utcnow()
    
    def _validate_sensor_range(self, sensor_type: str, value: float) -> List[str]:
        """Validar se valor está dentro do range esperado."""
        errors = []
        
        if sensor_type in self.sensor_ranges:
            range_info = self.sensor_ranges[sensor_type]
            min_val = range_info["min"]
            max_val = range_info["max"]
            
            if value < min_val or value > max_val:
                errors.append(
                    f"Valor {value} fora do range válido para {sensor_type}: "
                    f"{min_val} - {max_val}"
                )
        
        return errors
    
    def batch_normalize_data(
        self, 
        raw_data_list: List[Dict[str, Any]]
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Normalizar lote de dados.
        
        Args:
            raw_data_list: Lista de dados brutos
            
        Returns:
            Tupla (dados_normalizados, estatísticas)
        """
        normalized_data = []
        stats = {
            "total_records": len(raw_data_list),
            "successful_normalizations": 0,
            "failed_normalizations": 0,
            "validation_errors": [],
            "sensor_types_found": set(),
            "stations_found": set()
        }
        
        for raw_data in raw_data_list:
            normalized, errors = self.normalize_sensor_data(raw_data)
            
            if not errors:
                normalized_data.append(normalized)
                stats["successful_normalizations"] += 1
                
                # Coletar estatísticas
                if "sensor_type" in normalized:
                    stats["sensor_types_found"].add(normalized["sensor_type"])
                if "station_id" in normalized:
                    stats["stations_found"].add(normalized["station_id"])
            else:
                stats["failed_normalizations"] += 1
                stats["validation_errors"].extend(errors)
        
        # Converter sets para listas para serialização JSON
        stats["sensor_types_found"] = list(stats["sensor_types_found"])
        stats["stations_found"] = list(stats["stations_found"])
        
        return normalized_data, stats
    
    def enrich_sensor_data(
        self, 
        sensor_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Enriquecer dados do sensor com informações adicionais.
        
        Args:
            sensor_data: Dados do sensor
            
        Returns:
            Dados enriquecidos
        """
        enriched = sensor_data.copy()
        
        try:
            # Adicionar metadados baseados no tipo de sensor
            sensor_type = sensor_data.get("sensor_type")
            if sensor_type in self.sensor_ranges:
                range_info = self.sensor_ranges[sensor_type]
                enriched["expected_unit"] = range_info["unit"]
                enriched["valid_range"] = {
                    "min": range_info["min"],
                    "max": range_info["max"]
                }
            
            # Calcular percentual do range se aplicável
            if "value" in sensor_data and sensor_type in self.sensor_ranges:
                range_info = self.sensor_ranges[sensor_type]
                min_val = range_info["min"]
                max_val = range_info["max"]
                
                if max_val > min_val:
                    percentage = ((sensor_data["value"] - min_val) / (max_val - min_val)) * 100
                    enriched["range_percentage"] = max(0, min(100, percentage))
            
            # Adicionar classificação de qualidade
            quality_score = sensor_data.get("quality_score", 1.0)
            if quality_score >= 0.9:
                enriched["quality_classification"] = "excellent"
            elif quality_score >= 0.7:
                enriched["quality_classification"] = "good"
            elif quality_score >= 0.5:
                enriched["quality_classification"] = "fair"
            else:
                enriched["quality_classification"] = "poor"
            
            # Adicionar timestamp de processamento
            enriched["processed_at"] = datetime.utcnow().isoformat()
            
            return enriched
            
        except Exception as e:
            logger.error(f"Erro ao enriquecer dados: {e}")
            return sensor_data
    
    def detect_data_anomalies(
        self, 
        sensor_data_list: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Detectar anomalias em lote de dados.
        
        Args:
            sensor_data_list: Lista de dados de sensores
            
        Returns:
            Lista de anomalias detectadas
        """
        anomalies = []
        
        for sensor_data in sensor_data_list:
            try:
                # Usar serviço de detecção de anomalias
                anomaly_result = detect_anomaly(sensor_data)
                
                if anomaly_result.get("is_anomaly", False):
                    anomaly_info = {
                        "sensor_data": sensor_data,
                        "anomaly_score": anomaly_result.get("anomaly_score", 0),
                        "anomaly_type": anomaly_result.get("anomaly_type", "unknown"),
                        "detected_at": datetime.utcnow().isoformat()
                    }
                    anomalies.append(anomaly_info)
                    
            except Exception as e:
                logger.error(f"Erro na detecção de anomalia: {e}")
                continue
        
        return anomalies
    
    def generate_data_quality_report(
        self, 
        station_id: Optional[str] = None,
        hours_back: int = 24
    ) -> Dict[str, Any]:
        """
        Gerar relatório de qualidade dos dados.
        
        Args:
            station_id: ID da estação (opcional)
            hours_back: Horas para análise
            
        Returns:
            Relatório de qualidade
        """
        try:
            with SessionLocal() as db:
                # Query base
                query = db.query(SensorData)
                
                # Filtros
                if station_id:
                    query = query.filter(SensorData.station_id == station_id)
                
                time_threshold = datetime.utcnow() - timedelta(hours=hours_back)
                query = query.filter(SensorData.timestamp >= time_threshold)
                
                # Obter dados
                sensor_data = query.all()
                
                if not sensor_data:
                    return {
                        "status": "no_data",
                        "message": "Nenhum dado encontrado para o período",
                        "timestamp": datetime.utcnow().isoformat()
                    }
                
                # Calcular métricas de qualidade
                total_records = len(sensor_data)
                quality_scores = [data.quality_score for data in sensor_data]
                
                avg_quality = sum(quality_scores) / len(quality_scores)
                min_quality = min(quality_scores)
                max_quality = max(quality_scores)
                
                # Contar por qualidade
                excellent_count = sum(1 for q in quality_scores if q >= 0.9)
                good_count = sum(1 for q in quality_scores if 0.7 <= q < 0.9)
                fair_count = sum(1 for q in quality_scores if 0.5 <= q < 0.7)
                poor_count = sum(1 for q in quality_scores if q < 0.5)
                
                # Estatísticas por tipo de sensor
                sensor_types = {}
                for data in sensor_data:
                    sensor_type = data.sensor_type
                    if sensor_type not in sensor_types:
                        sensor_types[sensor_type] = {
                            "count": 0,
                            "avg_quality": 0,
                            "values": []
                        }
                    
                    sensor_types[sensor_type]["count"] += 1
                    sensor_types[sensor_type]["values"].append(data.quality_score)
                
                # Calcular médias por tipo
                for sensor_type, stats in sensor_types.items():
                    values = stats["values"]
                    stats["avg_quality"] = sum(values) / len(values)
                    stats["min_quality"] = min(values)
                    stats["max_quality"] = max(values)
                    del stats["values"]  # Remover para economizar espaço
                
                return {
                    "status": "success",
                    "period": {
                        "hours_back": hours_back,
                        "start_time": time_threshold.isoformat(),
                        "end_time": datetime.utcnow().isoformat()
                    },
                    "overall_quality": {
                        "total_records": total_records,
                        "average_quality": round(avg_quality, 3),
                        "min_quality": round(min_quality, 3),
                        "max_quality": round(max_quality, 3)
                    },
                    "quality_distribution": {
                        "excellent": {"count": excellent_count, "percentage": round((excellent_count/total_records)*100, 1)},
                        "good": {"count": good_count, "percentage": round((good_count/total_records)*100, 1)},
                        "fair": {"count": fair_count, "percentage": round((fair_count/total_records)*100, 1)},
                        "poor": {"count": poor_count, "percentage": round((poor_count/total_records)*100, 1)}
                    },
                    "by_sensor_type": sensor_types,
                    "generated_at": datetime.utcnow().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Erro ao gerar relatório de qualidade: {e}")
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    def add_sensor_type_mapping(self, standard_type: str, variations: List[str]):
        """Adicionar mapeamento de tipo de sensor."""
        if standard_type not in self.sensor_type_mappings:
            self.sensor_type_mappings[standard_type] = []
        
        self.sensor_type_mappings[standard_type].extend(variations)
        logger.info(f"Mapeamento adicionado para {standard_type}: {variations}")
    
    def add_unit_mapping(self, standard_unit: str, variations: List[str]):
        """Adicionar mapeamento de unidade."""
        if standard_unit not in self.unit_mappings:
            self.unit_mappings[standard_unit] = []
        
        self.unit_mappings[standard_unit].extend(variations)
        logger.info(f"Mapeamento de unidade adicionado para {standard_unit}: {variations}")
    
    def set_sensor_range(
        self, 
        sensor_type: str, 
        min_val: float, 
        max_val: float, 
        unit: str
    ):
        """Definir range válido para tipo de sensor."""
        self.sensor_ranges[sensor_type] = {
            "min": min_val,
            "max": max_val,
            "unit": unit
        }
        logger.info(f"Range definido para {sensor_type}: {min_val}-{max_val} {unit}")

# Instância global do processador
data_processor = DataProcessor()

