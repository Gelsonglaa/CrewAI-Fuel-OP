"""
Cliente MQTT para receber dados em tempo real de sensores IoT.
"""

import json
import logging
import asyncio
from datetime import datetime
from typing import Dict, Any, Callable, Optional
import paho.mqtt.client as mqtt
from sqlalchemy.orm import Session

from ..core.database import SessionLocal, SensorData
from ..core.config import settings
from ..ml.anomaly_detection_service import detect_anomaly

logger = logging.getLogger(__name__)

class MQTTClientService:
    """
    Serviço cliente MQTT para receber dados de sensores IoT.
    """
    
    def __init__(self):
        self.client = None
        self.is_connected = False
        self.message_count = 0
        self.error_count = 0
        
        # Tópicos padrão
        self.topics = {
            "sensor_data": "fuel_op/sensors/+/data",
            "alerts": "fuel_op/alerts/+",
            "status": "fuel_op/status/+",
            "commands": "fuel_op/commands/+"
        }
        
        # Callbacks personalizados
        self.message_handlers = {}
        
        # Configurações
        self.broker_host = settings.mqtt_broker_url
        self.broker_port = settings.mqtt_port
        self.username = settings.mqtt_username
        self.password = settings.mqtt_password
        self.client_id = f"fuel_op_client_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Configurar cliente
        self._setup_client()
    
    def _setup_client(self):
        """Configurar cliente MQTT."""
        try:
            self.client = mqtt.Client(client_id=self.client_id)
            
            # Configurar callbacks
            self.client.on_connect = self._on_connect
            self.client.on_disconnect = self._on_disconnect
            self.client.on_message = self._on_message
            self.client.on_subscribe = self._on_subscribe
            self.client.on_unsubscribe = self._on_unsubscribe
            
            # Configurar autenticação se fornecida
            if self.username and self.password:
                self.client.username_pw_set(self.username, self.password)
            
            # Configurar SSL/TLS se necessário
            # self.client.tls_set()
            
            logger.info(f"Cliente MQTT configurado: {self.client_id}")
            
        except Exception as e:
            logger.error(f"Erro ao configurar cliente MQTT: {e}")
            raise
    
    def _on_connect(self, client, userdata, flags, rc):
        """Callback de conexão."""
        if rc == 0:
            self.is_connected = True
            logger.info(f"Conectado ao broker MQTT: {self.broker_host}:{self.broker_port}")
            
            # Inscrever-se nos tópicos padrão
            for topic_name, topic_pattern in self.topics.items():
                client.subscribe(topic_pattern)
                logger.info(f"Inscrito no tópico: {topic_pattern}")
        else:
            self.is_connected = False
            logger.error(f"Falha na conexão MQTT. Código: {rc}")
    
    def _on_disconnect(self, client, userdata, rc):
        """Callback de desconexão."""
        self.is_connected = False
        if rc != 0:
            logger.warning("Desconexão inesperada do broker MQTT")
        else:
            logger.info("Desconectado do broker MQTT")
    
    def _on_message(self, client, userdata, msg):
        """Callback de mensagem recebida."""
        try:
            self.message_count += 1
            topic = msg.topic
            payload = msg.payload.decode('utf-8')
            
            logger.debug(f"Mensagem recebida - Tópico: {topic}, Payload: {payload[:100]}...")
            
            # Tentar decodificar JSON
            try:
                data = json.loads(payload)
            except json.JSONDecodeError:
                logger.warning(f"Payload não é JSON válido: {payload[:100]}...")
                self.error_count += 1
                return
            
            # Processar mensagem baseado no tópico
            if "sensors" in topic and "data" in topic:
                self._handle_sensor_data(topic, data)
            elif "alerts" in topic:
                self._handle_alert(topic, data)
            elif "status" in topic:
                self._handle_status(topic, data)
            elif "commands" in topic:
                self._handle_command(topic, data)
            else:
                # Verificar handlers personalizados
                for pattern, handler in self.message_handlers.items():
                    if pattern in topic:
                        handler(topic, data)
                        break
                else:
                    logger.debug(f"Tópico não reconhecido: {topic}")
            
        except Exception as e:
            logger.error(f"Erro ao processar mensagem MQTT: {e}")
            self.error_count += 1
    
    def _on_subscribe(self, client, userdata, mid, granted_qos):
        """Callback de inscrição."""
        logger.debug(f"Inscrição confirmada - MID: {mid}, QoS: {granted_qos}")
    
    def _on_unsubscribe(self, client, userdata, mid):
        """Callback de cancelamento de inscrição."""
        logger.debug(f"Inscrição cancelada - MID: {mid}")
    
    def _handle_sensor_data(self, topic: str, data: Dict[str, Any]):
        """Processar dados de sensor."""
        try:
            # Extrair station_id do tópico (fuel_op/sensors/STATION_001/data)
            topic_parts = topic.split('/')
            if len(topic_parts) >= 3:
                station_id = topic_parts[2]
                data["station_id"] = station_id
            
            # Validar dados obrigatórios
            required_fields = ["station_id", "sensor_type", "value", "unit"]
            for field in required_fields:
                if field not in data:
                    logger.warning(f"Campo obrigatório ausente em dados MQTT: {field}")
                    return
            
            # Salvar no banco de dados
            with SessionLocal() as db:
                db_sensor = SensorData(
                    station_id=data["station_id"],
                    sensor_type=data["sensor_type"],
                    value=float(data["value"]),
                    unit=data["unit"],
                    quality_score=data.get("quality_score", 1.0),
                    timestamp=datetime.utcnow()
                )
                
                db.add(db_sensor)
                db.commit()
                
                logger.debug(f"Dados de sensor salvos via MQTT: {data['station_id']}/{data['sensor_type']}")
            
            # Verificar anomalia
            anomaly_result = detect_anomaly(data)
            if anomaly_result.get("is_anomaly", False):
                logger.info(f"Anomalia detectada via MQTT: {data['station_id']}/{data['sensor_type']}")
                
                # Publicar alerta de anomalia
                alert_topic = f"fuel_op/alerts/{data['station_id']}"
                alert_data = {
                    "type": "anomaly_detected",
                    "station_id": data["station_id"],
                    "sensor_type": data["sensor_type"],
                    "anomaly_score": anomaly_result.get("anomaly_score", 0),
                    "timestamp": datetime.utcnow().isoformat()
                }
                self.publish(alert_topic, alert_data)
            
        except Exception as e:
            logger.error(f"Erro ao processar dados de sensor MQTT: {e}")
            self.error_count += 1
    
    def _handle_alert(self, topic: str, data: Dict[str, Any]):
        """Processar alerta."""
        try:
            logger.info(f"Alerta recebido via MQTT: {topic} - {data}")
            
            # Aqui você pode implementar lógica específica para alertas
            # Por exemplo, salvar no banco, enviar notificações, etc.
            
        except Exception as e:
            logger.error(f"Erro ao processar alerta MQTT: {e}")
    
    def _handle_status(self, topic: str, data: Dict[str, Any]):
        """Processar status."""
        try:
            logger.debug(f"Status recebido via MQTT: {topic} - {data}")
            
            # Implementar lógica de status se necessário
            
        except Exception as e:
            logger.error(f"Erro ao processar status MQTT: {e}")
    
    def _handle_command(self, topic: str, data: Dict[str, Any]):
        """Processar comando."""
        try:
            logger.info(f"Comando recebido via MQTT: {topic} - {data}")
            
            # Implementar lógica de comandos se necessário
            
        except Exception as e:
            logger.error(f"Erro ao processar comando MQTT: {e}")
    
    def connect(self) -> bool:
        """
        Conectar ao broker MQTT.
        
        Returns:
            True se conectado com sucesso
        """
        try:
            if not self.client:
                self._setup_client()
            
            logger.info(f"Conectando ao broker MQTT: {self.broker_host}:{self.broker_port}")
            
            result = self.client.connect(self.broker_host, self.broker_port, 60)
            
            if result == mqtt.MQTT_ERR_SUCCESS:
                # Iniciar loop em thread separada
                self.client.loop_start()
                return True
            else:
                logger.error(f"Erro na conexão MQTT: {result}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao conectar MQTT: {e}")
            return False
    
    def disconnect(self):
        """Desconectar do broker MQTT."""
        try:
            if self.client and self.is_connected:
                self.client.loop_stop()
                self.client.disconnect()
                logger.info("Desconectado do broker MQTT")
        except Exception as e:
            logger.error(f"Erro ao desconectar MQTT: {e}")
    
    def publish(self, topic: str, data: Dict[str, Any], qos: int = 1) -> bool:
        """
        Publicar mensagem MQTT.
        
        Args:
            topic: Tópico MQTT
            data: Dados a serem publicados
            qos: Qualidade de serviço
            
        Returns:
            True se publicado com sucesso
        """
        try:
            if not self.is_connected:
                logger.warning("Cliente MQTT não conectado")
                return False
            
            payload = json.dumps(data, default=str)
            result = self.client.publish(topic, payload, qos=qos)
            
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                logger.debug(f"Mensagem publicada - Tópico: {topic}")
                return True
            else:
                logger.error(f"Erro ao publicar mensagem: {result.rc}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao publicar MQTT: {e}")
            return False
    
    def subscribe(self, topic: str, qos: int = 1) -> bool:
        """
        Inscrever-se em tópico MQTT.
        
        Args:
            topic: Tópico MQTT
            qos: Qualidade de serviço
            
        Returns:
            True se inscrito com sucesso
        """
        try:
            if not self.is_connected:
                logger.warning("Cliente MQTT não conectado")
                return False
            
            result = self.client.subscribe(topic, qos=qos)
            
            if result[0] == mqtt.MQTT_ERR_SUCCESS:
                logger.info(f"Inscrito no tópico: {topic}")
                return True
            else:
                logger.error(f"Erro ao se inscrever no tópico: {result[0]}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao se inscrever MQTT: {e}")
            return False
    
    def unsubscribe(self, topic: str) -> bool:
        """
        Cancelar inscrição em tópico MQTT.
        
        Args:
            topic: Tópico MQTT
            
        Returns:
            True se cancelado com sucesso
        """
        try:
            if not self.is_connected:
                logger.warning("Cliente MQTT não conectado")
                return False
            
            result = self.client.unsubscribe(topic)
            
            if result[0] == mqtt.MQTT_ERR_SUCCESS:
                logger.info(f"Inscrição cancelada no tópico: {topic}")
                return True
            else:
                logger.error(f"Erro ao cancelar inscrição: {result[0]}")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao cancelar inscrição MQTT: {e}")
            return False
    
    def add_message_handler(self, topic_pattern: str, handler: Callable):
        """
        Adicionar handler personalizado para tópico.
        
        Args:
            topic_pattern: Padrão do tópico
            handler: Função para processar mensagens
        """
        self.message_handlers[topic_pattern] = handler
        logger.info(f"Handler adicionado para padrão: {topic_pattern}")
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Obter estatísticas do cliente MQTT.
        
        Returns:
            Estatísticas do cliente
        """
        return {
            "is_connected": self.is_connected,
            "broker_host": self.broker_host,
            "broker_port": self.broker_port,
            "client_id": self.client_id,
            "message_count": self.message_count,
            "error_count": self.error_count,
            "subscribed_topics": list(self.topics.values()),
            "custom_handlers": len(self.message_handlers)
        }
    
    def send_command(self, station_id: str, command: Dict[str, Any]) -> bool:
        """
        Enviar comando para estação via MQTT.
        
        Args:
            station_id: ID da estação
            command: Comando a ser enviado
            
        Returns:
            True se enviado com sucesso
        """
        try:
            topic = f"fuel_op/commands/{station_id}"
            command_data = {
                "command": command,
                "timestamp": datetime.utcnow().isoformat(),
                "source": "fuel_op_system"
            }
            
            return self.publish(topic, command_data)
            
        except Exception as e:
            logger.error(f"Erro ao enviar comando: {e}")
            return False

# Instância global do serviço
mqtt_client_service = MQTTClientService()

