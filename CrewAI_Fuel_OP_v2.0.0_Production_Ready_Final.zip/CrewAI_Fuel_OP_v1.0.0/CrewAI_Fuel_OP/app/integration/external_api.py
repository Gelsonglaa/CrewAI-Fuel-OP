"""
Serviço para integração com APIs externas e recepção de dados.
"""

import logging
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
import httpx
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from ..core.database import SessionLocal, SensorData
from ..core.config import settings
from ..ml.anomaly_detection_service import detect_anomaly

logger = logging.getLogger(__name__)

class ExternalAPIService:
    """
    Serviço para integração com APIs externas e processamento de dados.
    """
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=30.0)
        self.supported_formats = ["json", "xml", "csv"]
        self.batch_size = 100
        
        # Configurações de APIs externas
        self.external_apis = {
            "fuel_supplier_api": {
                "base_url": "https://api.fuel-supplier.com/v1",
                "auth_header": "X-API-Key",
                "auth_token": None,  # Configurar via variável de ambiente
                "endpoints": {
                    "stations": "/stations",
                    "sensors": "/sensors/data",
                    "alerts": "/alerts"
                }
            },
            "iot_platform": {
                "base_url": "https://iot-platform.com/api/v2",
                "auth_header": "Authorization",
                "auth_token": None,
                "endpoints": {
                    "devices": "/devices",
                    "telemetry": "/telemetry",
                    "commands": "/commands"
                }
            }
        }
    
    async def receive_sensor_data_batch(
        self, 
        sensor_data_list: List[Dict[str, Any]],
        source: str = "external_api"
    ) -> Dict[str, Any]:
        """
        Receber lote de dados de sensores de API externa.
        
        Args:
            sensor_data_list: Lista de dados de sensores
            source: Fonte dos dados
            
        Returns:
            Resultado do processamento
        """
        try:
            processed_count = 0
            anomalies_detected = 0
            errors = []
            
            with SessionLocal() as db:
                for sensor_data in sensor_data_list:
                    try:
                        # Validar dados obrigatórios
                        if not self._validate_sensor_data(sensor_data):
                            errors.append(f"Dados inválidos: {sensor_data}")
                            continue
                        
                        # Normalizar dados
                        normalized_data = self._normalize_sensor_data(sensor_data)
                        
                        # Salvar no banco de dados
                        db_sensor = SensorData(
                            station_id=normalized_data["station_id"],
                            sensor_type=normalized_data["sensor_type"],
                            value=normalized_data["value"],
                            unit=normalized_data["unit"],
                            quality_score=normalized_data.get("quality_score", 1.0),
                            timestamp=normalized_data.get("timestamp", datetime.utcnow())
                        )
                        
                        db.add(db_sensor)
                        processed_count += 1
                        
                        # Verificar anomalia
                        anomaly_result = detect_anomaly(normalized_data)
                        if anomaly_result.get("is_anomaly", False):
                            anomalies_detected += 1
                            logger.info(f"Anomalia detectada em dados externos: {normalized_data['station_id']}")
                        
                        # Commit em lotes para performance
                        if processed_count % self.batch_size == 0:
                            db.commit()
                    
                    except Exception as e:
                        logger.error(f"Erro ao processar sensor data: {e}")
                        errors.append(str(e))
                        continue
                
                # Commit final
                db.commit()
            
            result = {
                "status": "success",
                "processed_count": processed_count,
                "anomalies_detected": anomalies_detected,
                "errors_count": len(errors),
                "errors": errors[:10],  # Limitar erros retornados
                "source": source,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            logger.info(f"Lote processado: {processed_count} registros, {anomalies_detected} anomalias")
            return result
            
        except Exception as e:
            logger.error(f"Erro ao processar lote de dados: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Erro no processamento: {str(e)}"
            )
    
    async def fetch_external_data(
        self, 
        api_name: str, 
        endpoint: str,
        params: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Buscar dados de API externa.
        
        Args:
            api_name: Nome da API configurada
            endpoint: Endpoint a ser chamado
            params: Parâmetros da requisição
            
        Returns:
            Dados da API externa
        """
        try:
            if api_name not in self.external_apis:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"API não configurada: {api_name}"
                )
            
            api_config = self.external_apis[api_name]
            url = f"{api_config['base_url']}{endpoint}"
            
            # Preparar headers
            headers = {"Content-Type": "application/json"}
            if api_config["auth_token"]:
                headers[api_config["auth_header"]] = api_config["auth_token"]
            
            # Fazer requisição
            response = await self.client.get(url, headers=headers, params=params or {})
            response.raise_for_status()
            
            data = response.json()
            
            logger.info(f"Dados obtidos de {api_name}{endpoint}: {len(data) if isinstance(data, list) else 1} registros")
            
            return {
                "status": "success",
                "data": data,
                "source": api_name,
                "endpoint": endpoint,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except httpx.HTTPStatusError as e:
            logger.error(f"Erro HTTP ao buscar dados externos: {e}")
            raise HTTPException(
                status_code=e.response.status_code,
                detail=f"Erro na API externa: {e.response.text}"
            )
        except Exception as e:
            logger.error(f"Erro ao buscar dados externos: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Erro na integração: {str(e)}"
            )
    
    async def send_alert_to_external_system(
        self, 
        alert_data: Dict[str, Any],
        system_name: str
    ) -> bool:
        """
        Enviar alerta para sistema externo.
        
        Args:
            alert_data: Dados do alerta
            system_name: Nome do sistema de destino
            
        Returns:
            True se enviado com sucesso
        """
        try:
            if system_name not in self.external_apis:
                logger.warning(f"Sistema não configurado: {system_name}")
                return False
            
            api_config = self.external_apis[system_name]
            url = f"{api_config['base_url']}{api_config['endpoints']['alerts']}"
            
            # Preparar headers
            headers = {"Content-Type": "application/json"}
            if api_config["auth_token"]:
                headers[api_config["auth_header"]] = api_config["auth_token"]
            
            # Enviar alerta
            response = await self.client.post(url, json=alert_data, headers=headers)
            response.raise_for_status()
            
            logger.info(f"Alerta enviado para {system_name}: {alert_data.get('id', 'N/A')}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao enviar alerta para {system_name}: {e}")
            return False
    
    def _validate_sensor_data(self, data: Dict[str, Any]) -> bool:
        """Validar dados de sensor."""
        required_fields = ["station_id", "sensor_type", "value", "unit"]
        
        for field in required_fields:
            if field not in data:
                logger.warning(f"Campo obrigatório ausente: {field}")
                return False
        
        # Validar tipos
        if not isinstance(data["value"], (int, float)):
            logger.warning(f"Valor do sensor deve ser numérico: {data['value']}")
            return False
        
        # Validar ranges básicos
        if data["value"] < -1000 or data["value"] > 100000:
            logger.warning(f"Valor do sensor fora do range válido: {data['value']}")
            return False
        
        return True
    
    def _normalize_sensor_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalizar dados de sensor para formato padrão."""
        normalized = {
            "station_id": str(data["station_id"]).upper(),
            "sensor_type": str(data["sensor_type"]).lower(),
            "value": float(data["value"]),
            "unit": str(data["unit"]).lower(),
            "quality_score": float(data.get("quality_score", 1.0))
        }
        
        # Processar timestamp se fornecido
        if "timestamp" in data:
            if isinstance(data["timestamp"], str):
                try:
                    normalized["timestamp"] = datetime.fromisoformat(
                        data["timestamp"].replace("Z", "+00:00")
                    )
                except ValueError:
                    normalized["timestamp"] = datetime.utcnow()
            elif isinstance(data["timestamp"], datetime):
                normalized["timestamp"] = data["timestamp"]
            else:
                normalized["timestamp"] = datetime.utcnow()
        else:
            normalized["timestamp"] = datetime.utcnow()
        
        return normalized
    
    async def sync_station_data(self, api_name: str) -> Dict[str, Any]:
        """
        Sincronizar dados de estações de API externa.
        
        Args:
            api_name: Nome da API
            
        Returns:
            Resultado da sincronização
        """
        try:
            # Buscar dados de estações
            stations_data = await self.fetch_external_data(
                api_name, 
                self.external_apis[api_name]["endpoints"]["stations"]
            )
            
            # Buscar dados de sensores
            sensors_data = await self.fetch_external_data(
                api_name,
                self.external_apis[api_name]["endpoints"]["sensors"]
            )
            
            # Processar dados de sensores
            if sensors_data["status"] == "success" and sensors_data["data"]:
                result = await self.receive_sensor_data_batch(
                    sensors_data["data"],
                    source=f"{api_name}_sync"
                )
                
                return {
                    "status": "success",
                    "stations_count": len(stations_data["data"]) if isinstance(stations_data["data"], list) else 1,
                    "sensors_processed": result["processed_count"],
                    "anomalies_detected": result["anomalies_detected"],
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            return {
                "status": "no_data",
                "message": "Nenhum dado de sensor encontrado",
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Erro na sincronização: {e}")
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    def configure_external_api(
        self, 
        api_name: str, 
        config: Dict[str, Any]
    ):
        """
        Configurar API externa.
        
        Args:
            api_name: Nome da API
            config: Configuração da API
        """
        self.external_apis[api_name] = config
        logger.info(f"API externa configurada: {api_name}")
    
    async def test_external_connection(self, api_name: str) -> Dict[str, Any]:
        """
        Testar conexão com API externa.
        
        Args:
            api_name: Nome da API
            
        Returns:
            Resultado do teste
        """
        try:
            if api_name not in self.external_apis:
                return {
                    "status": "error",
                    "message": f"API não configurada: {api_name}"
                }
            
            api_config = self.external_apis[api_name]
            url = f"{api_config['base_url']}/health"
            
            headers = {}
            if api_config["auth_token"]:
                headers[api_config["auth_header"]] = api_config["auth_token"]
            
            response = await self.client.get(url, headers=headers)
            
            return {
                "status": "success" if response.status_code == 200 else "error",
                "status_code": response.status_code,
                "response_time": response.elapsed.total_seconds(),
                "api_name": api_name,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "api_name": api_name,
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def close(self):
        """Fechar cliente HTTP."""
        await self.client.aclose()

# Instância global do serviço
external_api_service = ExternalAPIService()

