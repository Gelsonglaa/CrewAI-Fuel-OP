"""
Handler de webhooks para receber dados de sistemas externos.
"""

import logging
import hmac
import hashlib
from datetime import datetime
from typing import Dict, Any, Optional
from fastapi import HTTPException, Request, status
from sqlalchemy.orm import Session

from ..core.database import SessionLocal, SensorData
from ..core.config import settings
from ..ml.anomaly_detection_service import detect_anomaly

logger = logging.getLogger(__name__)

class WebhookHandler:
    """
    Handler para processar webhooks de sistemas externos.
    """
    
    def __init__(self):
        # Configurações de webhooks por provedor
        self.webhook_configs = {
            "fuel_supplier": {
                "secret_key": "your_fuel_supplier_secret",
                "signature_header": "X-Hub-Signature-256",
                "event_types": ["sensor_data", "alert", "maintenance"]
            },
            "iot_platform": {
                "secret_key": "your_iot_platform_secret", 
                "signature_header": "X-Signature",
                "event_types": ["device_data", "device_status", "alarm"]
            },
            "monitoring_system": {
                "secret_key": "your_monitoring_secret",
                "signature_header": "X-Webhook-Signature",
                "event_types": ["threshold_exceeded", "system_alert", "maintenance_required"]
            }
        }
        
        # Estatísticas
        self.webhook_stats = {
            "total_received": 0,
            "successful_processed": 0,
            "failed_processed": 0,
            "invalid_signatures": 0
        }
    
    async def process_webhook(
        self,
        provider: str,
        request: Request,
        payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Processar webhook de provedor específico.
        
        Args:
            provider: Nome do provedor
            request: Requisição FastAPI
            payload: Dados do webhook
            
        Returns:
            Resultado do processamento
        """
        try:
            self.webhook_stats["total_received"] += 1
            
            # Verificar se provedor é conhecido
            if provider not in self.webhook_configs:
                logger.warning(f"Provedor de webhook desconhecido: {provider}")
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Provedor não suportado: {provider}"
                )
            
            config = self.webhook_configs[provider]
            
            # Verificar assinatura se configurada
            if config.get("secret_key"):
                if not await self._verify_signature(request, config):
                    self.webhook_stats["invalid_signatures"] += 1
                    logger.warning(f"Assinatura inválida para webhook {provider}")
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Assinatura inválida"
                    )
            
            # Processar payload baseado no provedor
            result = await self._process_payload_by_provider(provider, payload)
            
            if result["status"] == "success":
                self.webhook_stats["successful_processed"] += 1
            else:
                self.webhook_stats["failed_processed"] += 1
            
            logger.info(f"Webhook processado: {provider} - {result['status']}")
            
            return result
            
        except HTTPException:
            raise
        except Exception as e:
            self.webhook_stats["failed_processed"] += 1
            logger.error(f"Erro ao processar webhook {provider}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Erro no processamento: {str(e)}"
            )
    
    async def _verify_signature(
        self, 
        request: Request, 
        config: Dict[str, Any]
    ) -> bool:
        """
        Verificar assinatura do webhook.
        
        Args:
            request: Requisição FastAPI
            config: Configuração do provedor
            
        Returns:
            True se assinatura válida
        """
        try:
            signature_header = config["signature_header"]
            secret_key = config["secret_key"]
            
            # Obter assinatura do header
            signature = request.headers.get(signature_header)
            if not signature:
                logger.warning(f"Header de assinatura ausente: {signature_header}")
                return False
            
            # Obter corpo da requisição
            body = await request.body()
            
            # Calcular assinatura esperada
            if signature_header == "X-Hub-Signature-256":
                # GitHub style
                expected_signature = "sha256=" + hmac.new(
                    secret_key.encode(),
                    body,
                    hashlib.sha256
                ).hexdigest()
            else:
                # Generic HMAC
                expected_signature = hmac.new(
                    secret_key.encode(),
                    body,
                    hashlib.sha256
                ).hexdigest()
            
            # Comparar assinaturas
            return hmac.compare_digest(signature, expected_signature)
            
        except Exception as e:
            logger.error(f"Erro ao verificar assinatura: {e}")
            return False
    
    async def _process_payload_by_provider(
        self,
        provider: str,
        payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Processar payload baseado no provedor.
        
        Args:
            provider: Nome do provedor
            payload: Dados do webhook
            
        Returns:
            Resultado do processamento
        """
        try:
            if provider == "fuel_supplier":
                return await self._process_fuel_supplier_webhook(payload)
            elif provider == "iot_platform":
                return await self._process_iot_platform_webhook(payload)
            elif provider == "monitoring_system":
                return await self._process_monitoring_system_webhook(payload)
            else:
                return {
                    "status": "error",
                    "message": f"Processador não implementado para: {provider}"
                }
                
        except Exception as e:
            logger.error(f"Erro ao processar payload do provedor {provider}: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def _process_fuel_supplier_webhook(
        self,
        payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Processar webhook do fornecedor de combustível."""
        try:
            event_type = payload.get("event_type", "unknown")
            data = payload.get("data", {})
            
            if event_type == "sensor_data":
                # Processar dados de sensor
                sensor_data_list = data.get("sensors", [])
                processed_count = 0
                anomalies_detected = 0
                
                with SessionLocal() as db:
                    for sensor_data in sensor_data_list:
                        # Normalizar dados
                        normalized_data = {
                            "station_id": sensor_data.get("station_id"),
                            "sensor_type": sensor_data.get("type"),
                            "value": float(sensor_data.get("value", 0)),
                            "unit": sensor_data.get("unit"),
                            "quality_score": sensor_data.get("quality", 1.0)
                        }
                        
                        # Salvar no banco
                        db_sensor = SensorData(**normalized_data)
                        db.add(db_sensor)
                        processed_count += 1
                        
                        # Verificar anomalia
                        anomaly_result = detect_anomaly(normalized_data)
                        if anomaly_result.get("is_anomaly", False):
                            anomalies_detected += 1
                    
                    db.commit()
                
                return {
                    "status": "success",
                    "event_type": event_type,
                    "processed_count": processed_count,
                    "anomalies_detected": anomalies_detected,
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            elif event_type == "alert":
                # Processar alerta
                alert_data = data.get("alert", {})
                logger.info(f"Alerta recebido do fornecedor: {alert_data}")
                
                return {
                    "status": "success",
                    "event_type": event_type,
                    "alert_processed": True,
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            else:
                return {
                    "status": "ignored",
                    "event_type": event_type,
                    "message": "Tipo de evento não processado"
                }
                
        except Exception as e:
            logger.error(f"Erro ao processar webhook do fornecedor: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def _process_iot_platform_webhook(
        self,
        payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Processar webhook da plataforma IoT."""
        try:
            event_type = payload.get("event", "unknown")
            device_data = payload.get("device", {})
            
            if event_type == "device_data":
                # Processar dados do dispositivo IoT
                device_id = device_data.get("id")
                measurements = device_data.get("measurements", [])
                
                processed_count = 0
                
                with SessionLocal() as db:
                    for measurement in measurements:
                        # Mapear dados do dispositivo para formato padrão
                        normalized_data = {
                            "station_id": device_id,
                            "sensor_type": measurement.get("sensor_type"),
                            "value": float(measurement.get("value", 0)),
                            "unit": measurement.get("unit"),
                            "quality_score": measurement.get("confidence", 1.0)
                        }
                        
                        db_sensor = SensorData(**normalized_data)
                        db.add(db_sensor)
                        processed_count += 1
                    
                    db.commit()
                
                return {
                    "status": "success",
                    "event_type": event_type,
                    "device_id": device_id,
                    "processed_count": processed_count,
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            elif event_type == "device_status":
                # Processar status do dispositivo
                device_id = device_data.get("id")
                status = device_data.get("status")
                
                logger.info(f"Status do dispositivo {device_id}: {status}")
                
                return {
                    "status": "success",
                    "event_type": event_type,
                    "device_id": device_id,
                    "device_status": status,
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            else:
                return {
                    "status": "ignored",
                    "event_type": event_type,
                    "message": "Tipo de evento não processado"
                }
                
        except Exception as e:
            logger.error(f"Erro ao processar webhook da plataforma IoT: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def _process_monitoring_system_webhook(
        self,
        payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Processar webhook do sistema de monitoramento."""
        try:
            event_type = payload.get("type", "unknown")
            alert_data = payload.get("alert", {})
            
            if event_type == "threshold_exceeded":
                # Processar alerta de limiar excedido
                station_id = alert_data.get("station_id")
                sensor_type = alert_data.get("sensor_type")
                current_value = alert_data.get("current_value")
                threshold = alert_data.get("threshold")
                
                logger.warning(
                    f"Limiar excedido - Estação: {station_id}, "
                    f"Sensor: {sensor_type}, Valor: {current_value}, "
                    f"Limiar: {threshold}"
                )
                
                return {
                    "status": "success",
                    "event_type": event_type,
                    "station_id": station_id,
                    "sensor_type": sensor_type,
                    "alert_processed": True,
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            elif event_type == "system_alert":
                # Processar alerta do sistema
                message = alert_data.get("message")
                severity = alert_data.get("severity", "medium")
                
                logger.info(f"Alerta do sistema ({severity}): {message}")
                
                return {
                    "status": "success",
                    "event_type": event_type,
                    "severity": severity,
                    "alert_processed": True,
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            else:
                return {
                    "status": "ignored",
                    "event_type": event_type,
                    "message": "Tipo de evento não processado"
                }
                
        except Exception as e:
            logger.error(f"Erro ao processar webhook do sistema de monitoramento: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def configure_webhook(
        self,
        provider: str,
        config: Dict[str, Any]
    ):
        """
        Configurar webhook para provedor.
        
        Args:
            provider: Nome do provedor
            config: Configuração do webhook
        """
        self.webhook_configs[provider] = config
        logger.info(f"Webhook configurado para provedor: {provider}")
    
    def get_webhook_stats(self) -> Dict[str, Any]:
        """
        Obter estatísticas dos webhooks.
        
        Returns:
            Estatísticas dos webhooks
        """
        return {
            **self.webhook_stats,
            "configured_providers": list(self.webhook_configs.keys()),
            "success_rate": (
                self.webhook_stats["successful_processed"] / 
                max(1, self.webhook_stats["total_received"])
            ) * 100
        }
    
    def reset_stats(self):
        """Resetar estatísticas."""
        self.webhook_stats = {
            "total_received": 0,
            "successful_processed": 0,
            "failed_processed": 0,
            "invalid_signatures": 0
        }
        logger.info("Estatísticas de webhook resetadas")

# Instância global do handler
webhook_handler = WebhookHandler()

