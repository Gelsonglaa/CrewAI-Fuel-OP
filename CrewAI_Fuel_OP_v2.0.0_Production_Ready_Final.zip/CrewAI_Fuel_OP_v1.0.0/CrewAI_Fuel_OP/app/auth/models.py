"""
Modelos de dados para autenticação e autorização.
"""

from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Enum as SQLEnum
from sqlalchemy.ext.declarative import declarative_base

from ..core.database import Base

class UserRole(str, Enum):
    """Roles de usuário no sistema."""
    ADMIN = "admin"
    OPERATOR = "operator"
    VIEWER = "viewer"
    TECHNICIAN = "technician"

class User(Base):
    """Modelo de usuário no banco de dados."""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(100), nullable=True)
    role = Column(SQLEnum(UserRole), default=UserRole.VIEWER, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)

class UserCreate(BaseModel):
    """Schema para criação de usuário."""
    username: str = Field(..., min_length=3, max_length=50, description="Nome de usuário único")
    email: EmailStr = Field(..., description="Email válido")
    password: str = Field(..., min_length=8, description="Senha com pelo menos 8 caracteres")
    full_name: Optional[str] = Field(None, max_length=100, description="Nome completo")
    role: UserRole = Field(UserRole.VIEWER, description="Role do usuário")

class UserUpdate(BaseModel):
    """Schema para atualização de usuário."""
    email: Optional[EmailStr] = None
    full_name: Optional[str] = Field(None, max_length=100)
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None

class UserLogin(BaseModel):
    """Schema para login de usuário."""
    username: str = Field(..., description="Nome de usuário ou email")
    password: str = Field(..., description="Senha")

class UserResponse(BaseModel):
    """Schema para resposta de dados do usuário."""
    id: int
    username: str
    email: str
    full_name: Optional[str]
    role: UserRole
    is_active: bool
    is_verified: bool
    created_at: datetime
    last_login: Optional[datetime]

    class Config:
        from_attributes = True

class Token(BaseModel):
    """Schema para token JWT."""
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserResponse

class TokenData(BaseModel):
    """Schema para dados do token."""
    username: Optional[str] = None
    user_id: Optional[int] = None
    role: Optional[UserRole] = None

class PasswordReset(BaseModel):
    """Schema para reset de senha."""
    token: str
    new_password: str = Field(..., min_length=8)

class PasswordChange(BaseModel):
    """Schema para mudança de senha."""
    current_password: str
    new_password: str = Field(..., min_length=8)

