"""
Módulo de segurança para autenticação JWT e criptografia.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Union
from jose import JWTError, jwt
from passlib.context import CryptContext

from ..core.config import settings

logger = logging.getLogger(__name__)

# Contexto de criptografia para senhas
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verificar se a senha em texto plano corresponde ao hash.
    
    Args:
        plain_password: Senha em texto plano
        hashed_password: Hash da senha armazenada
        
    Returns:
        True se as senhas correspondem, False caso contrário
    """
    try:
        return pwd_context.verify(plain_password, hashed_password)
    except Exception as e:
        logger.error(f"Erro ao verificar senha: {e}")
        return False

def get_password_hash(password: str) -> str:
    """
    Gerar hash da senha.
    
    Args:
        password: Senha em texto plano
        
    Returns:
        Hash da senha
    """
    try:
        return pwd_context.hash(password)
    except Exception as e:
        logger.error(f"Erro ao gerar hash da senha: {e}")
        raise

def create_access_token(
    data: dict, 
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Criar token JWT de acesso.
    
    Args:
        data: Dados para incluir no token
        expires_delta: Tempo de expiração personalizado
        
    Returns:
        Token JWT codificado
    """
    try:
        to_encode = data.copy()
        
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(
                minutes=settings.jwt_access_token_expire_minutes
            )
        
        to_encode.update({"exp": expire, "iat": datetime.utcnow()})
        
        encoded_jwt = jwt.encode(
            to_encode, 
            settings.jwt_secret_key, 
            algorithm=settings.jwt_algorithm
        )
        
        return encoded_jwt
        
    except Exception as e:
        logger.error(f"Erro ao criar token de acesso: {e}")
        raise

def verify_token(token: str) -> Optional[dict]:
    """
    Verificar e decodificar token JWT.
    
    Args:
        token: Token JWT para verificar
        
    Returns:
        Payload do token se válido, None caso contrário
    """
    try:
        payload = jwt.decode(
            token, 
            settings.jwt_secret_key, 
            algorithms=[settings.jwt_algorithm]
        )
        
        # Verificar se o token não expirou
        exp = payload.get("exp")
        if exp and datetime.utcfromtimestamp(exp) < datetime.utcnow():
            logger.warning("Token expirado")
            return None
            
        return payload
        
    except JWTError as e:
        logger.warning(f"Token inválido: {e}")
        return None
    except Exception as e:
        logger.error(f"Erro ao verificar token: {e}")
        return None

def create_refresh_token(user_id: int) -> str:
    """
    Criar token de refresh.
    
    Args:
        user_id: ID do usuário
        
    Returns:
        Token de refresh
    """
    try:
        data = {
            "sub": str(user_id),
            "type": "refresh"
        }
        
        # Refresh token com validade maior (7 dias)
        expires_delta = timedelta(days=7)
        
        return create_access_token(data, expires_delta)
        
    except Exception as e:
        logger.error(f"Erro ao criar refresh token: {e}")
        raise

def generate_password_reset_token(email: str) -> str:
    """
    Gerar token para reset de senha.
    
    Args:
        email: Email do usuário
        
    Returns:
        Token para reset de senha
    """
    try:
        data = {
            "sub": email,
            "type": "password_reset"
        }
        
        # Token de reset válido por 1 hora
        expires_delta = timedelta(hours=1)
        
        return create_access_token(data, expires_delta)
        
    except Exception as e:
        logger.error(f"Erro ao gerar token de reset: {e}")
        raise

def verify_password_reset_token(token: str) -> Optional[str]:
    """
    Verificar token de reset de senha.
    
    Args:
        token: Token de reset
        
    Returns:
        Email do usuário se token válido, None caso contrário
    """
    try:
        payload = verify_token(token)
        
        if not payload:
            return None
            
        token_type = payload.get("type")
        if token_type != "password_reset":
            logger.warning("Tipo de token inválido para reset de senha")
            return None
            
        email = payload.get("sub")
        return email
        
    except Exception as e:
        logger.error(f"Erro ao verificar token de reset: {e}")
        return None

def validate_password_strength(password: str) -> tuple[bool, list[str]]:
    """
    Validar força da senha.
    
    Args:
        password: Senha para validar
        
    Returns:
        Tupla (é_válida, lista_de_erros)
    """
    errors = []
    
    if len(password) < 8:
        errors.append("Senha deve ter pelo menos 8 caracteres")
    
    if not any(c.islower() for c in password):
        errors.append("Senha deve conter pelo menos uma letra minúscula")
    
    if not any(c.isupper() for c in password):
        errors.append("Senha deve conter pelo menos uma letra maiúscula")
    
    if not any(c.isdigit() for c in password):
        errors.append("Senha deve conter pelo menos um número")
    
    if not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
        errors.append("Senha deve conter pelo menos um caractere especial")
    
    return len(errors) == 0, errors

