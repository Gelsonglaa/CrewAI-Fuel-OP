"""
Serviço de autenticação e gerenciamento de usuários.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional
from fastapi import HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from .models import User, UserCreate, UserLogin, UserResponse, Token, TokenData, UserRole
from .security import (
    verify_password, get_password_hash, create_access_token, 
    verify_token, validate_password_strength
)
from ..core.database import get_db, SessionLocal
from ..core.config import settings

logger = logging.getLogger(__name__)

# Esquema de segurança Bearer
security = HTTPBearer()

class AuthService:
    """Serviço de autenticação e gerenciamento de usuários."""
    
    def __init__(self):
        self.db = SessionLocal()
    
    def create_user(self, user_data: UserCreate) -> UserResponse:
        """
        Criar novo usuário.
        
        Args:
            user_data: Dados do usuário a ser criado
            
        Returns:
            Dados do usuário criado
            
        Raises:
            HTTPException: Se usuário já existe ou dados inválidos
        """
        try:
            # Verificar se usuário já existe
            if self.get_user_by_username(user_data.username):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Nome de usuário já existe"
                )
            
            if self.get_user_by_email(user_data.email):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Email já está em uso"
                )
            
            # Validar força da senha
            is_valid, errors = validate_password_strength(user_data.password)
            if not is_valid:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Senha não atende aos critérios: {', '.join(errors)}"
                )
            
            # Criar hash da senha
            hashed_password = get_password_hash(user_data.password)
            
            # Criar usuário no banco
            db_user = User(
                username=user_data.username,
                email=user_data.email,
                hashed_password=hashed_password,
                full_name=user_data.full_name,
                role=user_data.role
            )
            
            self.db.add(db_user)
            self.db.commit()
            self.db.refresh(db_user)
            
            logger.info(f"Usuário criado: {user_data.username}")
            
            return UserResponse.from_orm(db_user)
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Erro ao criar usuário: {e}")
            self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Erro interno do servidor"
            )
    
    def authenticate_user(self, username: str, password: str) -> Optional[User]:
        """
        Autenticar usuário.
        
        Args:
            username: Nome de usuário ou email
            password: Senha
            
        Returns:
            Usuário autenticado ou None
        """
        try:
            # Buscar por username ou email
            user = self.get_user_by_username(username)
            if not user:
                user = self.get_user_by_email(username)
            
            if not user:
                return None
            
            if not verify_password(password, user.hashed_password):
                return None
            
            # Atualizar último login
            user.last_login = datetime.utcnow()
            self.db.commit()
            
            return user
            
        except Exception as e:
            logger.error(f"Erro na autenticação: {e}")
            return None
    
    def login(self, login_data: UserLogin) -> Token:
        """
        Fazer login do usuário.
        
        Args:
            login_data: Dados de login
            
        Returns:
            Token de acesso
            
        Raises:
            HTTPException: Se credenciais inválidas
        """
        try:
            user = self.authenticate_user(login_data.username, login_data.password)
            
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Credenciais inválidas",
                    headers={"WWW-Authenticate": "Bearer"}
                )
            
            if not user.is_active:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Usuário inativo"
                )
            
            # Criar token de acesso
            access_token_expires = timedelta(
                minutes=settings.jwt_access_token_expire_minutes
            )
            
            access_token = create_access_token(
                data={
                    "sub": user.username,
                    "user_id": user.id,
                    "role": user.role.value
                },
                expires_delta=access_token_expires
            )
            
            logger.info(f"Login realizado: {user.username}")
            
            return Token(
                access_token=access_token,
                token_type="bearer",
                expires_in=settings.jwt_access_token_expire_minutes * 60,
                user=UserResponse.from_orm(user)
            )
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Erro no login: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Erro interno do servidor"
            )
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """Buscar usuário por nome de usuário."""
        try:
            return self.db.query(User).filter(User.username == username).first()
        except Exception as e:
            logger.error(f"Erro ao buscar usuário por username: {e}")
            return None
    
    def get_user_by_email(self, email: str) -> Optional[User]:
        """Buscar usuário por email."""
        try:
            return self.db.query(User).filter(User.email == email).first()
        except Exception as e:
            logger.error(f"Erro ao buscar usuário por email: {e}")
            return None
    
    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """Buscar usuário por ID."""
        try:
            return self.db.query(User).filter(User.id == user_id).first()
        except Exception as e:
            logger.error(f"Erro ao buscar usuário por ID: {e}")
            return None
    
    def update_user_role(self, user_id: int, new_role: UserRole) -> bool:
        """
        Atualizar role do usuário.
        
        Args:
            user_id: ID do usuário
            new_role: Nova role
            
        Returns:
            True se atualizado com sucesso
        """
        try:
            user = self.get_user_by_id(user_id)
            if not user:
                return False
            
            user.role = new_role
            user.updated_at = datetime.utcnow()
            self.db.commit()
            
            logger.info(f"Role atualizada para usuário {user_id}: {new_role}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao atualizar role: {e}")
            self.db.rollback()
            return False
    
    def deactivate_user(self, user_id: int) -> bool:
        """
        Desativar usuário.
        
        Args:
            user_id: ID do usuário
            
        Returns:
            True se desativado com sucesso
        """
        try:
            user = self.get_user_by_id(user_id)
            if not user:
                return False
            
            user.is_active = False
            user.updated_at = datetime.utcnow()
            self.db.commit()
            
            logger.info(f"Usuário desativado: {user_id}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao desativar usuário: {e}")
            self.db.rollback()
            return False

# Instância global do serviço
auth_service = AuthService()

def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """
    Dependency para obter usuário atual autenticado.
    
    Args:
        credentials: Credenciais Bearer
        db: Sessão do banco de dados
        
    Returns:
        Usuário autenticado
        
    Raises:
        HTTPException: Se token inválido ou usuário não encontrado
    """
    try:
        # Verificar token
        payload = verify_token(credentials.credentials)
        
        if not payload:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token inválido",
                headers={"WWW-Authenticate": "Bearer"}
            )
        
        # Extrair dados do token
        username = payload.get("sub")
        user_id = payload.get("user_id")
        
        if not username or not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token malformado",
                headers={"WWW-Authenticate": "Bearer"}
            )
        
        # Buscar usuário no banco
        user = db.query(User).filter(User.id == user_id).first()
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Usuário não encontrado",
                headers={"WWW-Authenticate": "Bearer"}
            )
        
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter usuário atual: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Erro de autenticação",
            headers={"WWW-Authenticate": "Bearer"}
        )

def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """
    Dependency para obter usuário ativo atual.
    
    Args:
        current_user: Usuário atual
        
    Returns:
        Usuário ativo
        
    Raises:
        HTTPException: Se usuário inativo
    """
    if not current_user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Usuário inativo"
        )
    
    return current_user

def require_role(required_role: UserRole):
    """
    Decorator para exigir role específica.
    
    Args:
        required_role: Role necessária
        
    Returns:
        Dependency function
    """
    def role_checker(current_user: User = Depends(get_current_active_user)):
        if current_user.role != required_role and current_user.role != UserRole.ADMIN:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Permissões insuficientes"
            )
        return current_user
    
    return role_checker

def require_admin(current_user: User = Depends(get_current_active_user)):
    """Dependency para exigir role de admin."""
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso restrito a administradores"
        )
    return current_user

