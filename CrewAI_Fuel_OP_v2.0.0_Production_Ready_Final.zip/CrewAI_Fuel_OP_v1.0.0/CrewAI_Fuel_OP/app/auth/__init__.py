"""
Módulo de autenticação e autorização para o sistema CrewAI Fuel OP.
"""

from .auth_service import AuthService, get_current_user, get_current_active_user
from .models import User, UserCreate, UserLogin, Token, UserRole
from .security import create_access_token, verify_password, get_password_hash

__all__ = [
    "AuthService",
    "get_current_user", 
    "get_current_active_user",
    "User",
    "UserCreate", 
    "UserLogin",
    "Token",
    "UserRole",
    "create_access_token",
    "verify_password",
    "get_password_hash"
]

