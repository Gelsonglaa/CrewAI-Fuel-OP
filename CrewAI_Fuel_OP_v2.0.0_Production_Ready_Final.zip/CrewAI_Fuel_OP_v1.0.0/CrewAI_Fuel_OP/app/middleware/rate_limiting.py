"""
Middleware de rate limiting para controlar frequência de requisições.
"""

import logging
import time
from collections import defaultdict, deque
from typing import Callable, Dict, Deque
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Middleware de rate limiting usando sliding window.
    """
    
    def __init__(
        self, 
        app,
        requests_per_minute: int = 60,
        requests_per_hour: int = 1000,
        burst_limit: int = 10
    ):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.requests_per_hour = requests_per_hour
        self.burst_limit = burst_limit
        
        # Armazenar timestamps das requisições por IP
        self.request_history: Dict[str, Deque[float]] = defaultdict(deque)
        
        # Limites específicos por endpoint
        self.endpoint_limits = {
            "/auth/login": {"per_minute": 5, "per_hour": 20},
            "/auth/register": {"per_minute": 3, "per_hour": 10},
            "/sensor-data": {"per_minute": 100, "per_hour": 5000},
            "/predict/anomaly": {"per_minute": 30, "per_hour": 500},
            "/predict/demand": {"per_minute": 20, "per_hour": 200}
        }
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Processar requisição aplicando rate limiting.
        """
        client_ip = self._get_client_ip(request)
        endpoint = request.url.path
        current_time = time.time()
        
        try:
            # Verificar rate limit
            if not self._check_rate_limit(client_ip, endpoint, current_time):
                logger.warning(f"Rate limit excedido para IP {client_ip} no endpoint {endpoint}")
                
                return JSONResponse(
                    status_code=429,
                    content={
                        "detail": "Rate limit excedido",
                        "retry_after": 60
                    },
                    headers={"Retry-After": "60"}
                )
            
            # Registrar requisição
            self._record_request(client_ip, current_time)
            
            # Processar requisição
            response = await call_next(request)
            
            # Adicionar headers de rate limit
            self._add_rate_limit_headers(response, client_ip, current_time)
            
            return response
            
        except Exception as e:
            logger.error(f"Erro no middleware de rate limiting: {e}")
            return JSONResponse(
                status_code=500,
                content={"detail": "Erro interno do servidor"}
            )
    
    def _get_client_ip(self, request: Request) -> str:
        """Obter IP real do cliente."""
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"
    
    def _check_rate_limit(self, ip: str, endpoint: str, current_time: float) -> bool:
        """
        Verificar se requisição está dentro dos limites.
        """
        request_times = self.request_history[ip]
        
        # Limpar requisições antigas (mais de 1 hora)
        while request_times and current_time - request_times[0] > 3600:
            request_times.popleft()
        
        # Obter limites para o endpoint
        limits = self.endpoint_limits.get(endpoint, {
            "per_minute": self.requests_per_minute,
            "per_hour": self.requests_per_hour
        })
        
        # Contar requisições no último minuto
        minute_ago = current_time - 60
        requests_last_minute = sum(1 for t in request_times if t > minute_ago)
        
        # Contar requisições na última hora
        hour_ago = current_time - 3600
        requests_last_hour = sum(1 for t in request_times if t > hour_ago)
        
        # Verificar burst limit (últimos 10 segundos)
        burst_window = current_time - 10
        requests_burst = sum(1 for t in request_times if t > burst_window)
        
        # Aplicar limites
        if requests_burst >= self.burst_limit:
            logger.debug(f"Burst limit excedido para {ip}: {requests_burst}")
            return False
        
        if requests_last_minute >= limits["per_minute"]:
            logger.debug(f"Limite por minuto excedido para {ip}: {requests_last_minute}")
            return False
        
        if requests_last_hour >= limits["per_hour"]:
            logger.debug(f"Limite por hora excedido para {ip}: {requests_last_hour}")
            return False
        
        return True
    
    def _record_request(self, ip: str, timestamp: float):
        """Registrar timestamp da requisição."""
        self.request_history[ip].append(timestamp)
        
        # Limitar tamanho do histórico para evitar uso excessivo de memória
        if len(self.request_history[ip]) > 2000:
            # Remover 25% das entradas mais antigas
            for _ in range(500):
                if self.request_history[ip]:
                    self.request_history[ip].popleft()
    
    def _add_rate_limit_headers(self, response: Response, ip: str, current_time: float):
        """Adicionar headers informativos sobre rate limit."""
        request_times = self.request_history[ip]
        
        # Contar requisições no último minuto
        minute_ago = current_time - 60
        requests_last_minute = sum(1 for t in request_times if t > minute_ago)
        
        # Contar requisições na última hora  
        hour_ago = current_time - 3600
        requests_last_hour = sum(1 for t in request_times if t > hour_ago)
        
        # Adicionar headers
        response.headers["X-RateLimit-Limit-Minute"] = str(self.requests_per_minute)
        response.headers["X-RateLimit-Remaining-Minute"] = str(
            max(0, self.requests_per_minute - requests_last_minute)
        )
        response.headers["X-RateLimit-Limit-Hour"] = str(self.requests_per_hour)
        response.headers["X-RateLimit-Remaining-Hour"] = str(
            max(0, self.requests_per_hour - requests_last_hour)
        )
        
        # Calcular reset time
        if request_times:
            oldest_in_minute = min(t for t in request_times if t > minute_ago) if requests_last_minute > 0 else current_time
            reset_time = int(oldest_in_minute + 60)
            response.headers["X-RateLimit-Reset"] = str(reset_time)
    
    def get_stats(self) -> dict:
        """Obter estatísticas de rate limiting."""
        current_time = time.time()
        stats = {
            "total_ips": len(self.request_history),
            "active_ips_last_hour": 0,
            "total_requests_last_hour": 0,
            "top_ips": []
        }
        
        ip_counts = []
        hour_ago = current_time - 3600
        
        for ip, request_times in self.request_history.items():
            # Contar requisições na última hora
            requests_last_hour = sum(1 for t in request_times if t > hour_ago)
            
            if requests_last_hour > 0:
                stats["active_ips_last_hour"] += 1
                stats["total_requests_last_hour"] += requests_last_hour
                ip_counts.append((ip, requests_last_hour))
        
        # Top 10 IPs por número de requisições
        ip_counts.sort(key=lambda x: x[1], reverse=True)
        stats["top_ips"] = ip_counts[:10]
        
        return stats
    
    def reset_ip_limits(self, ip: str):
        """Resetar limites para um IP específico."""
        if ip in self.request_history:
            del self.request_history[ip]
            logger.info(f"Limites resetados para IP: {ip}")
    
    def set_endpoint_limit(self, endpoint: str, per_minute: int, per_hour: int):
        """Definir limite específico para um endpoint."""
        self.endpoint_limits[endpoint] = {
            "per_minute": per_minute,
            "per_hour": per_hour
        }
        logger.info(f"Limite definido para {endpoint}: {per_minute}/min, {per_hour}/hour")
    
    def cleanup_old_entries(self):
        """Limpar entradas antigas para liberar memória."""
        current_time = time.time()
        hour_ago = current_time - 3600
        
        ips_to_remove = []
        
        for ip, request_times in self.request_history.items():
            # Remover timestamps antigos
            while request_times and request_times[0] < hour_ago:
                request_times.popleft()
            
            # Marcar IPs sem atividade recente para remoção
            if not request_times:
                ips_to_remove.append(ip)
        
        # Remover IPs inativos
        for ip in ips_to_remove:
            del self.request_history[ip]
        
        logger.debug(f"Limpeza concluída. Removidos {len(ips_to_remove)} IPs inativos.")

