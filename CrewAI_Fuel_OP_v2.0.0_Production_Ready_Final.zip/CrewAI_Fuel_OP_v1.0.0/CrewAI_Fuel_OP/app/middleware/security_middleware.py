"""
Middleware de segurança para proteção contra ataques comuns.
"""

import logging
import time
from typing import Callable
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

class SecurityMiddleware(BaseHTTPMiddleware):
    """
    Middleware de segurança que adiciona headers de proteção
    e valida requisições.
    """
    
    def __init__(self, app, max_request_size: int = 10 * 1024 * 1024):  # 10MB
        super().__init__(app)
        self.max_request_size = max_request_size
        
        # IPs bloqueados (pode ser expandido para usar Redis)
        self.blocked_ips = set()
        
        # Tentativas de login por IP
        self.login_attempts = {}
        self.max_login_attempts = 5
        self.lockout_duration = 300  # 5 minutos
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Processar requisição aplicando validações de segurança.
        """
        start_time = time.time()
        client_ip = self._get_client_ip(request)
        
        try:
            # Verificar IP bloqueado
            if self._is_ip_blocked(client_ip):
                logger.warning(f"Requisição bloqueada de IP: {client_ip}")
                return JSONResponse(
                    status_code=429,
                    content={"detail": "IP temporariamente bloqueado"}
                )
            
            # Validar tamanho da requisição
            if not await self._validate_request_size(request):
                logger.warning(f"Requisição muito grande de IP: {client_ip}")
                return JSONResponse(
                    status_code=413,
                    content={"detail": "Requisição muito grande"}
                )
            
            # Validar headers suspeitos
            if self._has_suspicious_headers(request):
                logger.warning(f"Headers suspeitos de IP: {client_ip}")
                return JSONResponse(
                    status_code=400,
                    content={"detail": "Requisição inválida"}
                )
            
            # Processar requisição
            response = await call_next(request)
            
            # Monitorar tentativas de login falhadas
            if request.url.path == "/auth/login" and response.status_code == 401:
                self._record_failed_login(client_ip)
            
            # Adicionar headers de segurança
            self._add_security_headers(response)
            
            # Log da requisição
            process_time = time.time() - start_time
            logger.info(
                f"{request.method} {request.url.path} - "
                f"IP: {client_ip} - Status: {response.status_code} - "
                f"Time: {process_time:.3f}s"
            )
            
            return response
            
        except Exception as e:
            logger.error(f"Erro no middleware de segurança: {e}")
            return JSONResponse(
                status_code=500,
                content={"detail": "Erro interno do servidor"}
            )
    
    def _get_client_ip(self, request: Request) -> str:
        """Obter IP real do cliente considerando proxies."""
        # Verificar headers de proxy
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        # IP direto
        return request.client.host if request.client else "unknown"
    
    def _is_ip_blocked(self, ip: str) -> bool:
        """Verificar se IP está bloqueado."""
        if ip in self.blocked_ips:
            return True
        
        # Verificar tentativas de login
        if ip in self.login_attempts:
            attempts_data = self.login_attempts[ip]
            
            # Verificar se ainda está no período de bloqueio
            if (time.time() - attempts_data["last_attempt"]) < self.lockout_duration:
                if attempts_data["count"] >= self.max_login_attempts:
                    return True
            else:
                # Reset contador se passou o período
                del self.login_attempts[ip]
        
        return False
    
    async def _validate_request_size(self, request: Request) -> bool:
        """Validar tamanho da requisição."""
        content_length = request.headers.get("content-length")
        
        if content_length:
            try:
                size = int(content_length)
                return size <= self.max_request_size
            except ValueError:
                return False
        
        return True
    
    def _has_suspicious_headers(self, request: Request) -> bool:
        """Verificar headers suspeitos que podem indicar ataques."""
        suspicious_patterns = [
            "script", "javascript", "vbscript", "onload", "onerror",
            "eval(", "alert(", "document.cookie", "document.write",
            "../", "..\\", "/etc/passwd", "cmd.exe", "powershell"
        ]
        
        # Verificar User-Agent suspeito
        user_agent = request.headers.get("user-agent", "").lower()
        if any(pattern in user_agent for pattern in suspicious_patterns):
            return True
        
        # Verificar outros headers
        for header_name, header_value in request.headers.items():
            if isinstance(header_value, str):
                header_lower = header_value.lower()
                if any(pattern in header_lower for pattern in suspicious_patterns):
                    return True
        
        return False
    
    def _record_failed_login(self, ip: str):
        """Registrar tentativa de login falhada."""
        current_time = time.time()
        
        if ip not in self.login_attempts:
            self.login_attempts[ip] = {"count": 0, "last_attempt": current_time}
        
        self.login_attempts[ip]["count"] += 1
        self.login_attempts[ip]["last_attempt"] = current_time
        
        # Log da tentativa suspeita
        if self.login_attempts[ip]["count"] >= self.max_login_attempts:
            logger.warning(
                f"IP {ip} excedeu limite de tentativas de login: "
                f"{self.login_attempts[ip]['count']}"
            )
    
    def _add_security_headers(self, response: Response):
        """Adicionar headers de segurança à resposta."""
        security_headers = {
            # Prevenir ataques XSS
            "X-XSS-Protection": "1; mode=block",
            
            # Prevenir MIME type sniffing
            "X-Content-Type-Options": "nosniff",
            
            # Prevenir clickjacking
            "X-Frame-Options": "DENY",
            
            # Política de referrer
            "Referrer-Policy": "strict-origin-when-cross-origin",
            
            # Política de permissões
            "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
            
            # HSTS (apenas em HTTPS)
            # "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
            
            # CSP básico
            "Content-Security-Policy": (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: https:; "
                "font-src 'self' https:; "
                "connect-src 'self' https:; "
                "frame-ancestors 'none'"
            )
        }
        
        for header_name, header_value in security_headers.items():
            response.headers[header_name] = header_value
    
    def block_ip(self, ip: str):
        """Bloquear IP manualmente."""
        self.blocked_ips.add(ip)
        logger.info(f"IP bloqueado manualmente: {ip}")
    
    def unblock_ip(self, ip: str):
        """Desbloquear IP."""
        self.blocked_ips.discard(ip)
        if ip in self.login_attempts:
            del self.login_attempts[ip]
        logger.info(f"IP desbloqueado: {ip}")
    
    def get_blocked_ips(self) -> list:
        """Obter lista de IPs bloqueados."""
        return list(self.blocked_ips)
    
    def get_login_attempts(self) -> dict:
        """Obter estatísticas de tentativas de login."""
        return dict(self.login_attempts)

