"""
Middleware de validação de dados e sanitização de entrada.
"""

import json
import logging
import re
from typing import Callable
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

class ValidationMiddleware(BaseHTTPMiddleware):
    """
    Middleware para validação e sanitização de dados de entrada.
    """
    
    def __init__(self, app):
        super().__init__(app)
        
        # Padrões de validação
        self.sql_injection_patterns = [
            r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b)",
            r"(--|#|/\*|\*/)",
            r"(\b(OR|AND)\s+\d+=\d+)",
            r"(\b(OR|AND)\s+['\"].*['\"])",
            r"(INFORMATION_SCHEMA|SYSOBJECTS|SYSCOLUMNS)"
        ]
        
        self.xss_patterns = [
            r"<script[^>]*>.*?</script>",
            r"javascript:",
            r"on\w+\s*=",
            r"<iframe[^>]*>.*?</iframe>",
            r"<object[^>]*>.*?</object>",
            r"<embed[^>]*>.*?</embed>",
            r"<link[^>]*>",
            r"<meta[^>]*>",
            r"vbscript:",
            r"data:text/html"
        ]
        
        self.path_traversal_patterns = [
            r"\.\./",
            r"\.\.\\",
            r"/etc/passwd",
            r"/proc/",
            r"\\windows\\",
            r"\\system32\\"
        ]
        
        # Limites de tamanho por tipo de campo
        self.field_size_limits = {
            "username": 50,
            "email": 100,
            "password": 128,
            "full_name": 100,
            "description": 1000,
            "station_id": 50,
            "sensor_type": 50,
            "action_description": 2000
        }
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Processar requisição aplicando validações.
        """
        try:
            # Validar método HTTP
            if not self._validate_http_method(request):
                return JSONResponse(
                    status_code=405,
                    content={"detail": "Método HTTP não permitido"}
                )
            
            # Validar URL
            if not self._validate_url(request):
                return JSONResponse(
                    status_code=400,
                    content={"detail": "URL inválida"}
                )
            
            # Validar e sanitizar corpo da requisição
            if request.method in ["POST", "PUT", "PATCH"]:
                validated_request = await self._validate_request_body(request)
                if isinstance(validated_request, JSONResponse):
                    return validated_request
                request = validated_request
            
            # Validar query parameters
            if not self._validate_query_params(request):
                return JSONResponse(
                    status_code=400,
                    content={"detail": "Parâmetros de consulta inválidos"}
                )
            
            # Processar requisição
            response = await call_next(request)
            
            # Sanitizar resposta se necessário
            response = await self._sanitize_response(response)
            
            return response
            
        except Exception as e:
            logger.error(f"Erro no middleware de validação: {e}")
            return JSONResponse(
                status_code=500,
                content={"detail": "Erro interno do servidor"}
            )
    
    def _validate_http_method(self, request: Request) -> bool:
        """Validar método HTTP."""
        allowed_methods = ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"]
        return request.method in allowed_methods
    
    def _validate_url(self, request: Request) -> bool:
        """Validar URL da requisição."""
        url_path = str(request.url.path)
        
        # Verificar path traversal
        for pattern in self.path_traversal_patterns:
            if re.search(pattern, url_path, re.IGNORECASE):
                logger.warning(f"Path traversal detectado: {url_path}")
                return False
        
        # Verificar caracteres suspeitos
        suspicious_chars = ["<", ">", "\"", "'", "&", "%00", "%2e%2e"]
        for char in suspicious_chars:
            if char in url_path:
                logger.warning(f"Caractere suspeito na URL: {char}")
                return False
        
        return True
    
    async def _validate_request_body(self, request: Request) -> Request | JSONResponse:
        """Validar e sanitizar corpo da requisição."""
        try:
            # Ler corpo da requisição
            body = await request.body()
            
            if not body:
                return request
            
            # Tentar decodificar JSON
            try:
                json_data = json.loads(body.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                logger.warning("Corpo da requisição não é JSON válido")
                return JSONResponse(
                    status_code=400,
                    content={"detail": "Formato de dados inválido"}
                )
            
            # Validar e sanitizar dados JSON
            sanitized_data = self._sanitize_json_data(json_data)
            
            if sanitized_data is None:
                return JSONResponse(
                    status_code=400,
                    content={"detail": "Dados contêm conteúdo malicioso"}
                )
            
            # Validar tamanhos de campo
            validation_errors = self._validate_field_sizes(sanitized_data)
            if validation_errors:
                return JSONResponse(
                    status_code=400,
                    content={
                        "detail": "Validação de dados falhou",
                        "errors": validation_errors
                    }
                )
            
            # Criar nova requisição com dados sanitizados
            sanitized_body = json.dumps(sanitized_data).encode("utf-8")
            
            # Substituir o corpo da requisição
            async def receive():
                return {"type": "http.request", "body": sanitized_body}
            
            request._receive = receive
            
            return request
            
        except Exception as e:
            logger.error(f"Erro ao validar corpo da requisição: {e}")
            return JSONResponse(
                status_code=400,
                content={"detail": "Erro na validação de dados"}
            )
    
    def _sanitize_json_data(self, data) -> dict | list | None:
        """Sanitizar dados JSON recursivamente."""
        if isinstance(data, dict):
            sanitized = {}
            for key, value in data.items():
                # Sanitizar chave
                clean_key = self._sanitize_string(str(key))
                if clean_key is None:
                    logger.warning(f"Chave maliciosa detectada: {key}")
                    return None
                
                # Sanitizar valor
                clean_value = self._sanitize_json_data(value)
                if clean_value is None:
                    return None
                
                sanitized[clean_key] = clean_value
            
            return sanitized
            
        elif isinstance(data, list):
            sanitized = []
            for item in data:
                clean_item = self._sanitize_json_data(item)
                if clean_item is None:
                    return None
                sanitized.append(clean_item)
            
            return sanitized
            
        elif isinstance(data, str):
            return self._sanitize_string(data)
            
        else:
            # Números, booleanos, None passam sem modificação
            return data
    
    def _sanitize_string(self, text: str) -> str | None:
        """Sanitizar string individual."""
        if not isinstance(text, str):
            return text
        
        # Verificar SQL injection
        for pattern in self.sql_injection_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                logger.warning(f"SQL injection detectado: {text[:100]}...")
                return None
        
        # Verificar XSS
        for pattern in self.xss_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                logger.warning(f"XSS detectado: {text[:100]}...")
                return None
        
        # Verificar path traversal
        for pattern in self.path_traversal_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                logger.warning(f"Path traversal detectado: {text[:100]}...")
                return None
        
        # Remover caracteres de controle
        sanitized = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', text)
        
        # Limitar tamanho máximo
        if len(sanitized) > 10000:  # 10KB por campo
            logger.warning(f"Campo muito longo: {len(sanitized)} caracteres")
            return None
        
        return sanitized.strip()
    
    def _validate_query_params(self, request: Request) -> bool:
        """Validar parâmetros de consulta."""
        for key, value in request.query_params.items():
            # Sanitizar chave
            if self._sanitize_string(key) is None:
                logger.warning(f"Parâmetro de consulta malicioso: {key}")
                return False
            
            # Sanitizar valor
            if isinstance(value, str) and self._sanitize_string(value) is None:
                logger.warning(f"Valor de parâmetro malicioso: {value}")
                return False
        
        return True
    
    def _validate_field_sizes(self, data) -> list:
        """Validar tamanhos de campos específicos."""
        errors = []
        
        def check_field(obj, path=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    current_path = f"{path}.{key}" if path else key
                    
                    # Verificar tamanho do campo se estiver nos limites
                    if key in self.field_size_limits and isinstance(value, str):
                        max_size = self.field_size_limits[key]
                        if len(value) > max_size:
                            errors.append(
                                f"Campo '{key}' excede tamanho máximo de {max_size} caracteres"
                            )
                    
                    # Recursão para objetos aninhados
                    check_field(value, current_path)
                    
            elif isinstance(obj, list):
                for i, item in enumerate(obj):
                    check_field(item, f"{path}[{i}]")
        
        check_field(data)
        return errors
    
    async def _sanitize_response(self, response: Response) -> Response:
        """Sanitizar resposta se necessário."""
        # Por enquanto, apenas adicionar headers de segurança
        # Em implementações futuras, pode sanitizar conteúdo da resposta
        
        if not hasattr(response, 'headers'):
            return response
        
        # Garantir que não há informações sensíveis nos headers
        sensitive_headers = ["server", "x-powered-by", "x-aspnet-version"]
        
        for header in sensitive_headers:
            if header in response.headers:
                del response.headers[header]
        
        return response
    
    def add_validation_pattern(self, category: str, pattern: str):
        """Adicionar novo padrão de validação."""
        if category == "sql_injection":
            self.sql_injection_patterns.append(pattern)
        elif category == "xss":
            self.xss_patterns.append(pattern)
        elif category == "path_traversal":
            self.path_traversal_patterns.append(pattern)
        
        logger.info(f"Novo padrão adicionado à categoria {category}: {pattern}")
    
    def set_field_size_limit(self, field_name: str, max_size: int):
        """Definir limite de tamanho para um campo."""
        self.field_size_limits[field_name] = max_size
        logger.info(f"Limite de tamanho definido para '{field_name}': {max_size}")
    
    def get_validation_stats(self) -> dict:
        """Obter estatísticas de validação."""
        return {
            "sql_injection_patterns": len(self.sql_injection_patterns),
            "xss_patterns": len(self.xss_patterns),
            "path_traversal_patterns": len(self.path_traversal_patterns),
            "field_size_limits": len(self.field_size_limits)
        }

