#!/bin/bash
# Script de inicialização do CrewAI Fuel OP System

echo "🚀 Iniciando CrewAI Fuel OP System..."

# Verificar se o Docker está instalado
if ! command -v docker &> /dev/null; then
    echo "❌ Docker não está instalado. Por favor, instale o Docker primeiro."
    exit 1
fi

# Verificar se o Docker Compose está instalado
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose não está instalado. Por favor, instale o Docker Compose primeiro."
    exit 1
fi

# Criar diretórios necessários
mkdir -p data logs app/ml/models

# Copiar arquivo de exemplo de variáveis de ambiente se não existir
if [ ! -f .env ]; then
    cp .env.example .env
    echo "📝 Arquivo .env criado. Configure as variáveis conforme necessário."
fi

# Fazer build das imagens
echo "🔨 Construindo imagens Docker..."
docker-compose build

# Iniciar serviços
echo "🎯 Iniciando serviços..."
docker-compose up -d

# Aguardar serviços ficarem prontos
echo "⏳ Aguardando serviços ficarem prontos..."
sleep 30

# Verificar status dos serviços
echo "📊 Status dos serviços:"
docker-compose ps

# Exibir URLs de acesso
echo ""
echo "✅ Sistema inicializado com sucesso!"
echo ""
echo "🔗 URLs de acesso:"
echo "  - API: http://localhost:8000"
echo "  - Documentação: http://localhost:8000/docs"
echo "  - Dashboard: http://localhost:8501"
echo "  - Prometheus: http://localhost:9090 (opcional)"
echo "  - Grafana: http://localhost:3000 (opcional)"
echo ""
echo "📋 Comandos úteis:"
echo "  - Ver logs: docker-compose logs -f"
echo "  - Parar sistema: docker-compose down"
echo "  - Reiniciar: docker-compose restart"
echo ""
echo "🎉 Aproveite o CrewAI Fuel OP System!"
