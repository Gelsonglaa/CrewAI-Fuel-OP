# 📡 Documentação da API - CrewAI Fuel OP

## Visão Geral

A API do CrewAI Fuel OP é uma API RESTful construída com FastAPI que fornece endpoints para gerenciamento de dados de sensores, detecção de anomalias, autenticação e integração com sistemas externos.

**Base URL**: `http://localhost:8000`  
**Documentação Interativa**: `http://localhost:8000/docs`  
**Esquema OpenAPI**: `http://localhost:8000/openapi.json`

## Autenticação

A API utiliza autenticação JWT (JSON Web Tokens). Para acessar endpoints protegidos, você deve incluir o token no header `Authorization`.

### Obter Token de Acesso

```http
POST /auth/login
Content-Type: application/x-www-form-urlencoded

username=seu_usuario&password=sua_senha
```

**Resposta:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

### Usar Token nas Requisições

```http
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## Endpoints da API

### 🔐 Autenticação

#### POST /auth/register
Registrar novo usuário.

**Corpo da Requisição:**
```json
{
  "username": "novo_usuario",
  "email": "usuario@exemplo.com",
  "password": "senha_segura_123",
  "full_name": "Nome Completo",
  "is_active": true
}
```

**Resposta (201):**
```json
{
  "id": 1,
  "username": "novo_usuario",
  "email": "usuario@exemplo.com",
  "full_name": "Nome Completo",
  "is_active": true,
  "created_at": "2024-01-01T12:00:00Z"
}
```

#### POST /auth/login
Fazer login e obter token de acesso.

**Corpo da Requisição:**
```
username=seu_usuario&password=sua_senha
```

#### GET /auth/me
Obter informações do usuário atual (requer autenticação).

**Resposta (200):**
```json
{
  "id": 1,
  "username": "usuario",
  "email": "usuario@exemplo.com",
  "full_name": "Nome Completo",
  "is_active": true
}
```

#### POST /auth/change-password
Alterar senha do usuário (requer autenticação).

**Corpo da Requisição:**
```json
{
  "current_password": "senha_atual",
  "new_password": "nova_senha_123"
}
```

### 🏭 Estações

#### GET /stations
Listar todas as estações (requer autenticação).

**Parâmetros de Query:**
- `active_only` (bool): Filtrar apenas estações ativas

**Resposta (200):**
```json
{
  "stations": [
    {
      "station_id": "STATION_001",
      "name": "Posto Central",
      "status": "online",
      "last_update": "2024-01-01T12:00:00Z",
      "sensor_count": 4,
      "location": {
        "latitude": -23.5505,
        "longitude": -46.6333
      }
    }
  ],
  "total": 1
}
```

#### GET /stations/{station_id}
Obter detalhes de uma estação específica (requer autenticação).

**Resposta (200):**
```json
{
  "station_id": "STATION_001",
  "name": "Posto Central",
  "status": "online",
  "last_update": "2024-01-01T12:00:00Z",
  "sensors": [
    {
      "sensor_type": "fuel_level",
      "current_value": 75.5,
      "unit": "percent",
      "last_reading": "2024-01-01T12:00:00Z",
      "quality_score": 0.95
    }
  ],
  "location": {
    "latitude": -23.5505,
    "longitude": -46.6333
  }
}
```

### 📊 Dados de Sensores

#### GET /sensor-data/{station_id}
Obter dados de sensores de uma estação (requer autenticação).

**Parâmetros de Query:**
- `sensor_type` (str): Filtrar por tipo de sensor
- `hours_back` (int): Horas para trás (padrão: 24)
- `limit` (int): Limite de registros (padrão: 100)

**Resposta (200):**
```json
{
  "sensor_data": [
    {
      "id": 1,
      "station_id": "STATION_001",
      "sensor_type": "fuel_level",
      "value": 75.5,
      "unit": "percent",
      "quality_score": 0.95,
      "timestamp": "2024-01-01T12:00:00Z"
    }
  ],
  "total": 1,
  "station_id": "STATION_001",
  "period": {
    "start": "2024-01-01T00:00:00Z",
    "end": "2024-01-01T12:00:00Z"
  }
}
```

#### POST /sensor-data
Inserir dados de sensor (requer autenticação).

**Corpo da Requisição:**
```json
{
  "station_id": "STATION_001",
  "sensor_type": "fuel_level",
  "value": 75.5,
  "unit": "percent",
  "quality_score": 0.95
}
```

**Resposta (201):**
```json
{
  "id": 1,
  "station_id": "STATION_001",
  "sensor_type": "fuel_level",
  "value": 75.5,
  "unit": "percent",
  "quality_score": 0.95,
  "timestamp": "2024-01-01T12:00:00Z"
}
```

#### POST /sensor-data/batch
Inserir múltiplos dados de sensor (requer autenticação).

**Corpo da Requisição:**
```json
{
  "sensor_data": [
    {
      "station_id": "STATION_001",
      "sensor_type": "fuel_level",
      "value": 75.5,
      "unit": "percent",
      "quality_score": 0.95
    },
    {
      "station_id": "STATION_001",
      "sensor_type": "pressure",
      "value": 2.3,
      "unit": "bar",
      "quality_score": 0.97
    }
  ]
}
```

**Resposta (201):**
```json
{
  "inserted_count": 2,
  "sensor_data": [
    {
      "id": 1,
      "station_id": "STATION_001",
      "sensor_type": "fuel_level",
      "value": 75.5,
      "unit": "percent",
      "quality_score": 0.95,
      "timestamp": "2024-01-01T12:00:00Z"
    }
  ]
}
```

### ⚠️ Anomalias

#### GET /anomalies
Listar anomalias (requer autenticação).

**Parâmetros de Query:**
- `station_id` (str): Filtrar por estação
- `severity` (str): Filtrar por severidade (low, medium, high, critical)
- `resolved` (bool): Filtrar por status de resolução
- `limit` (int): Limite de registros (padrão: 50)

**Resposta (200):**
```json
{
  "anomalies": [
    {
      "id": 1,
      "station_id": "STATION_001",
      "sensor_type": "fuel_level",
      "sensor_value": 15.2,
      "anomaly_score": 0.89,
      "severity": "high",
      "description": "Nível de combustível criticamente baixo",
      "is_resolved": false,
      "detected_at": "2024-01-01T12:00:00Z",
      "resolved_at": null,
      "resolution_notes": null
    }
  ],
  "total": 1
}
```

#### POST /anomalies
Registrar nova anomalia (requer autenticação).

**Corpo da Requisição:**
```json
{
  "station_id": "STATION_001",
  "sensor_type": "fuel_level",
  "sensor_value": 15.2,
  "anomaly_score": 0.89,
  "severity": "high",
  "description": "Nível de combustível criticamente baixo"
}
```

#### PATCH /anomalies/{anomaly_id}/resolve
Resolver anomalia (requer autenticação).

**Corpo da Requisição:**
```json
{
  "resolution_notes": "Problema resolvido após reabastecimento"
}
```

### 🤖 Machine Learning

#### POST /ml/detect-anomaly
Detectar anomalia em dados de sensor (requer autenticação).

**Corpo da Requisição:**
```json
{
  "station_id": "STATION_001",
  "sensor_type": "fuel_level",
  "value": 15.0,
  "quality_score": 0.95
}
```

**Resposta (200):**
```json
{
  "is_anomaly": true,
  "anomaly_score": 0.89,
  "confidence": 0.92,
  "anomaly_type": "low_fuel_level",
  "threshold": 0.8,
  "model_version": "v1.2.0"
}
```

#### POST /ml/predict/consumption
Prever consumo de combustível (requer autenticação).

**Corpo da Requisição:**
```json
{
  "station_id": "STATION_001",
  "hours_ahead": 24
}
```

**Resposta (200):**
```json
{
  "predictions": [
    {
      "timestamp": "2024-01-01T13:00:00Z",
      "predicted_consumption": 45.2,
      "confidence_lower": 42.1,
      "confidence_upper": 48.3
    }
  ],
  "total_predicted_consumption": 1084.8,
  "confidence_interval": {
    "lower": 1020.5,
    "upper": 1149.1
  },
  "model_version": "v1.1.0"
}
```

#### POST /ml/retrain/anomaly-model
Retreinar modelo de detecção de anomalias (requer autenticação).

**Corpo da Requisição:**
```json
{
  "contamination": 0.1,
  "min_samples": 100
}
```

**Resposta (200):**
```json
{
  "status": "success",
  "message": "Modelo retreinado com sucesso",
  "training_stats": {
    "training_samples": 1500,
    "training_time": 12.5,
    "model_score": 0.94,
    "contamination": 0.1
  },
  "model_version": "v1.3.0"
}
```

#### POST /ml/retrain/demand-model
Retreinar modelo de previsão de demanda (requer autenticação).

**Resposta (200):**
```json
{
  "status": "success",
  "message": "Modelo retreinado com sucesso",
  "training_stats": {
    "training_samples": 2000,
    "training_time": 45.2,
    "mse": 0.05,
    "mae": 0.15,
    "r2_score": 0.95
  },
  "model_version": "v1.2.0"
}
```

#### GET /ml/status
Obter status dos modelos ML (requer autenticação).

**Resposta (200):**
```json
{
  "anomaly_detection": {
    "is_trained": true,
    "model_version": "v1.2.0",
    "last_training": "2024-01-01T10:00:00Z",
    "training_samples": 1500,
    "model_score": 0.94
  },
  "demand_prediction": {
    "is_trained": true,
    "model_version": "v1.1.0",
    "last_training": "2024-01-01T08:00:00Z",
    "training_samples": 2000,
    "r2_score": 0.95
  }
}
```

### 📈 Estatísticas

#### GET /stats/dashboard
Obter estatísticas para dashboard (requer autenticação).

**Resposta (200):**
```json
{
  "overview": {
    "active_stations": 12,
    "total_sensors": 48,
    "recent_data_points": 1247,
    "unresolved_anomalies": 3,
    "system_uptime": 99.2
  },
  "sensors": {
    "by_type": {
      "fuel_level": 12,
      "pressure": 12,
      "temperature": 12,
      "flow_rate": 12
    },
    "recent_data": [
      {
        "station_id": "STATION_001",
        "sensor_type": "fuel_level",
        "value": 75.5,
        "timestamp": "2024-01-01T12:00:00Z"
      }
    ]
  },
  "anomalies": {
    "total": 15,
    "last_24h": 3,
    "by_severity": {
      "low": 8,
      "medium": 5,
      "high": 2,
      "critical": 0
    }
  },
  "system": {
    "database": {
      "connected": true,
      "total_sensors": 48,
      "recent_data": 1247
    },
    "ml_services": {
      "anomaly_detection": {
        "status": "operational",
        "model_loaded": true
      },
      "demand_prediction": {
        "status": "operational",
        "model_loaded": true
      }
    }
  }
}
```

#### GET /stats/station/{station_id}
Obter estatísticas de estação específica (requer autenticação).

**Resposta (200):**
```json
{
  "station_id": "STATION_001",
  "sensor_types": ["fuel_level", "pressure", "temperature", "flow_rate"],
  "data_quality": {
    "average_quality": 0.94,
    "total_readings": 1500,
    "quality_distribution": {
      "excellent": 85,
      "good": 12,
      "fair": 2,
      "poor": 1
    }
  },
  "recent_activity": {
    "last_reading": "2024-01-01T12:00:00Z",
    "readings_last_hour": 4,
    "readings_last_24h": 96
  },
  "anomalies": {
    "total": 5,
    "resolved": 4,
    "unresolved": 1,
    "last_anomaly": "2024-01-01T10:30:00Z"
  }
}
```

### 🔗 Webhooks

#### POST /webhooks/fuel_supplier
Receber dados do fornecedor de combustível.

**Headers:**
```
X-Hub-Signature-256: sha256=hash_da_assinatura
Content-Type: application/json
```

**Corpo da Requisição:**
```json
{
  "event_type": "sensor_data",
  "data": {
    "sensors": [
      {
        "station_id": "STATION_001",
        "type": "fuel_level",
        "value": 67.8,
        "unit": "percent",
        "quality": 0.94
      }
    ]
  },
  "timestamp": "2024-01-01T12:00:00Z"
}
```

#### POST /webhooks/iot_platform
Receber dados da plataforma IoT.

#### POST /webhooks/monitoring_system
Receber dados do sistema de monitoramento.

### 🔌 Integração

#### GET /integration/mqtt/status
Obter status da conexão MQTT (requer autenticação).

**Resposta (200):**
```json
{
  "is_connected": true,
  "broker_host": "localhost",
  "broker_port": 1883,
  "client_id": "fuel_op_client_20240101_120000",
  "message_count": 1247,
  "error_count": 2,
  "subscribed_topics": [
    "fuel_op/sensors/+/data",
    "fuel_op/alerts/+",
    "fuel_op/status/+",
    "fuel_op/commands/+"
  ]
}
```

#### GET /integration/external-api/status
Obter status das APIs externas (requer autenticação).

**Resposta (200):**
```json
{
  "total_requests": 150,
  "successful_requests": 145,
  "error_count": 5,
  "success_rate": 96.67,
  "last_request": "2024-01-01T12:00:00Z",
  "services": {
    "fuel_price_api": {
      "status": "operational",
      "last_check": "2024-01-01T11:55:00Z"
    },
    "notification_service": {
      "status": "operational",
      "last_check": "2024-01-01T11:58:00Z"
    }
  }
}
```

### 🏥 Health Check

#### GET /health
Verificação básica de saúde do sistema.

**Resposta (200):**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00Z",
  "version": "1.0.0",
  "database": {
    "connected": true,
    "response_time_ms": 5
  }
}
```

#### GET /health/detailed
Verificação detalhada de saúde (requer autenticação).

**Resposta (200):**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00Z",
  "version": "1.0.0",
  "uptime_seconds": 86400,
  "database": {
    "connected": true,
    "response_time_ms": 5,
    "pool_size": 20,
    "active_connections": 3
  },
  "ml_services": {
    "anomaly_detection": {
      "status": "operational",
      "model_loaded": true,
      "last_prediction": "2024-01-01T11:59:00Z"
    },
    "demand_prediction": {
      "status": "operational",
      "model_loaded": true,
      "last_prediction": "2024-01-01T11:45:00Z"
    }
  },
  "external_services": {
    "mqtt_broker": {
      "status": "connected",
      "message_count": 1247
    },
    "redis": {
      "status": "connected",
      "memory_usage": "2.5MB"
    }
  },
  "system_info": {
    "cpu_usage": 15.2,
    "memory_usage": 45.8,
    "disk_usage": 12.3
  }
}
```

## Códigos de Status HTTP

| Código | Descrição |
|--------|-----------|
| 200 | OK - Requisição bem-sucedida |
| 201 | Created - Recurso criado com sucesso |
| 400 | Bad Request - Dados inválidos na requisição |
| 401 | Unauthorized - Token de autenticação ausente ou inválido |
| 403 | Forbidden - Acesso negado |
| 404 | Not Found - Recurso não encontrado |
| 422 | Unprocessable Entity - Erro de validação |
| 429 | Too Many Requests - Rate limit excedido |
| 500 | Internal Server Error - Erro interno do servidor |

## Tratamento de Erros

Todas as respostas de erro seguem o formato padrão:

```json
{
  "detail": "Descrição do erro",
  "error_code": "ERROR_CODE",
  "timestamp": "2024-01-01T12:00:00Z",
  "path": "/api/endpoint"
}
```

### Erros de Validação (422)

```json
{
  "detail": [
    {
      "loc": ["body", "value"],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

## Rate Limiting

A API implementa rate limiting para prevenir abuso:

- **Limite geral**: 100 requisições por minuto por IP
- **Usuários autenticados**: 1000 requisições por hora
- **Endpoints ML**: 10 requisições por minuto

Headers de resposta incluem informações sobre o rate limit:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1640995200
```

## Versionamento

A API utiliza versionamento via URL:

- **v1**: `/api/v1/` (atual)
- **Futuras versões**: `/api/v2/`, etc.

## WebSocket (Experimental)

Para dados em tempo real:

```javascript
const ws = new WebSocket('ws://localhost:8000/ws');

ws.onmessage = function(event) {
    const data = JSON.parse(event.data);
    console.log('Dados em tempo real:', data);
};
```

## Exemplos de Uso

### Python

```python
import requests

# Autenticação
response = requests.post(
    "http://localhost:8000/auth/login",
    data={"username": "admin", "password": "admin123"}
)
token = response.json()["access_token"]

headers = {"Authorization": f"Bearer {token}"}

# Inserir dados de sensor
sensor_data = {
    "station_id": "STATION_001",
    "sensor_type": "fuel_level",
    "value": 75.5,
    "unit": "percent",
    "quality_score": 0.95
}

response = requests.post(
    "http://localhost:8000/sensor-data",
    json=sensor_data,
    headers=headers
)

print(response.json())
```

### JavaScript

```javascript
// Autenticação
const loginResponse = await fetch('http://localhost:8000/auth/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'username=admin&password=admin123'
});

const { access_token } = await loginResponse.json();

// Buscar dados de sensores
const sensorsResponse = await fetch('http://localhost:8000/sensor-data/STATION_001', {
    headers: {
        'Authorization': `Bearer ${access_token}`
    }
});

const sensorsData = await sensorsResponse.json();
console.log(sensorsData);
```

### cURL

```bash
# Autenticação
TOKEN=$(curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin123" | jq -r '.access_token')

# Buscar anomalias
curl -X GET http://localhost:8000/anomalies \
  -H "Authorization: Bearer $TOKEN" | jq
```

## Suporte

Para dúvidas sobre a API:

- **Documentação Interativa**: http://localhost:8000/docs
- **Email**: api-support@fuel-op.com
- **GitHub Issues**: [Reportar problemas](https://github.com/your-org/fuel-op/issues)

