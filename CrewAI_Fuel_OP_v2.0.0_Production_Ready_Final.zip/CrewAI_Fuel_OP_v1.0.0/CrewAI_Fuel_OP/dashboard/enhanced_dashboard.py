"""
Dashboard Streamlit aprimorado para o sistema CrewAI Fuel OP.
Interface web moderna e responsiva com filtros avançados.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import requests
import time
from datetime import datetime, timedelta
import json
import numpy as np
from typing import Dict, List, Any, Optional

# Configuração da página
st.set_page_config(
    page_title="CrewAI Fuel OP - Dashboard Avançado",
    page_icon="⛽",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS customizado para melhor aparência
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #1f4e79 0%, #2980b9 100%);
        color: white;
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        text-align: center;
    }
    
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 4px solid #2980b9;
    }
    
    .alert-card {
        background: #fff3cd;
        border: 1px solid #ffeaa7;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
    }
    
    .critical-alert {
        background: #f8d7da;
        border-color: #f5c6cb;
    }
    
    .success-card {
        background: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
    }
    
    .sidebar .sidebar-content {
        background: #f8f9fa;
    }
    
    .stSelectbox > div > div {
        background-color: white;
    }
    
    .filter-section {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Configurações
API_BASE_URL = "http://localhost:8000"
REFRESH_INTERVAL = 30

class EnhancedAPIClient:
    """Cliente aprimorado para comunicação com a API."""

    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': 'CrewAI-Dashboard/1.0'
        })

    def get(self, endpoint: str, params: Dict = None) -> Dict:
        """Fazer requisição GET com tratamento de erro aprimorado."""
        try:
            url = f"{self.base_url}{endpoint}"
            response = self.session.get(url, params=params, timeout=15)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.ConnectionError:
            st.error("🔌 Erro de conexão com a API. Verifique se o servidor está rodando.")
            return {}
        except requests.exceptions.Timeout:
            st.error("⏱️ Timeout na requisição. Tente novamente.")
            return {}
        except requests.exceptions.HTTPError as e:
            st.error(f"❌ Erro HTTP {e.response.status_code}: {e.response.text}")
            return {}
        except Exception as e:
            st.error(f"🚨 Erro inesperado: {str(e)}")
            return {}

    def post(self, endpoint: str, data: Dict = None) -> Dict:
        """Fazer requisição POST com tratamento de erro aprimorado."""
        try:
            url = f"{self.base_url}{endpoint}"
            response = self.session.post(url, json=data, timeout=30)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            st.error(f"Erro na requisição POST: {e}")
            return {}

# Inicializar cliente da API
@st.cache_resource
def get_api_client():
    return EnhancedAPIClient(API_BASE_URL)

api = get_api_client()

# Funções de cache aprimoradas
@st.cache_data(ttl=30, show_spinner=False)
def load_dashboard_stats():
    """Carregar estatísticas do dashboard."""
    return api.get("/stats/dashboard")

@st.cache_data(ttl=60, show_spinner=False)
def load_stations():
    """Carregar lista de estações."""
    return api.get("/stations")

@st.cache_data(ttl=30, show_spinner=False)
def load_anomalies(station_id=None, severity=None, limit=100):
    """Carregar anomalias com filtros."""
    params = {"limit": limit}
    if station_id:
        params["station_id"] = station_id
    if severity:
        params["severity"] = severity
    return api.get("/anomalies", params=params)

@st.cache_data(ttl=30, show_spinner=False)
def load_sensor_data(station_id, hours_back=24, sensor_type=None):
    """Carregar dados de sensores com filtros."""
    params = {"hours_back": hours_back}
    if sensor_type:
        params["sensor_type"] = sensor_type
    return api.get(f"/sensor-data/{station_id}", params)

@st.cache_data(ttl=300, show_spinner=False)
def load_health_status():
    """Carregar status de saúde do sistema."""
    return api.get("/health")

# Funções de visualização aprimoradas
def create_advanced_gauge(value: float, title: str, max_value: float = 100, 
                         unit: str = "", thresholds: Dict = None) -> go.Figure:
    """Criar gauge avançado com múltiplos limiares."""
    if thresholds is None:
        thresholds = {"warning": 70, "critical": 90}
    
    # Determinar cor baseada nos limiares
    if value >= thresholds.get("critical", 90):
        color = "red"
    elif value >= thresholds.get("warning", 70):
        color = "orange"
    else:
        color = "green"
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=value,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': f"{title}<br><span style='font-size:0.8em;color:gray'>{unit}</span>"},
        delta={'reference': max_value * 0.8},
        gauge={
            'axis': {'range': [None, max_value], 'tickwidth': 1, 'tickcolor': "darkblue"},
            'bar': {'color': color, 'thickness': 0.3},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [0, thresholds.get("warning", 70)], 'color': "#e8f5e8"},
                {'range': [thresholds.get("warning", 70), thresholds.get("critical", 90)], 'color': "#fff3cd"},
                {'range': [thresholds.get("critical", 90), max_value], 'color': "#f8d7da"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': thresholds.get("critical", 90)
            }
        }
    ))

    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=250,
        margin=dict(l=20, r=20, t=40, b=20)
    )

    return fig

def create_multi_sensor_chart(data: List[Dict], title: str, station_id: str = None) -> go.Figure:
    """Criar gráfico multi-sensor com subplots."""
    if not data:
        return go.Figure().add_annotation(
            text="Sem dados disponíveis",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=16, color="gray")
        )

    df = pd.DataFrame(data)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    # Obter tipos únicos de sensores
    sensor_types = df['sensor_type'].unique()
    n_sensors = len(sensor_types)
    
    if n_sensors == 0:
        return go.Figure()
    
    # Criar subplots
    rows = (n_sensors + 1) // 2 if n_sensors > 1 else 1
    cols = 2 if n_sensors > 1 else 1
    
    fig = make_subplots(
        rows=rows, cols=cols,
        subplot_titles=[f"{sensor_type.replace('_', ' ').title()}" for sensor_type in sensor_types],
        vertical_spacing=0.1,
        horizontal_spacing=0.1
    )
    
    # Cores para diferentes sensores
    colors = px.colors.qualitative.Set1
    
    for i, sensor_type in enumerate(sensor_types):
        sensor_data = df[df['sensor_type'] == sensor_type].sort_values('timestamp')
        
        row = (i // cols) + 1
        col = (i % cols) + 1
        
        fig.add_trace(
            go.Scatter(
                x=sensor_data['timestamp'],
                y=sensor_data['value'],
                name=sensor_type,
                mode='lines+markers',
                line=dict(color=colors[i % len(colors)], width=2),
                marker=dict(size=4),
                hovertemplate=f"<b>{sensor_type}</b><br>" +
                             "Valor: %{y}<br>" +
                             "Tempo: %{x}<br>" +
                             "<extra></extra>"
            ),
            row=row, col=col
        )
    
    fig.update_layout(
        title=title,
        height=300 * rows,
        showlegend=False,
        hovermode='x unified'
    )
    
    return fig

def create_anomaly_heatmap(anomalies: List[Dict]) -> go.Figure:
    """Criar heatmap de anomalias por estação e tipo de sensor."""
    if not anomalies:
        return go.Figure().add_annotation(
            text="Nenhuma anomalia para exibir",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False
        )
    
    df = pd.DataFrame(anomalies)
    
    # Criar matriz de anomalias
    heatmap_data = df.groupby(['station_id', 'sensor_type']).size().unstack(fill_value=0)
    
    fig = go.Figure(data=go.Heatmap(
        z=heatmap_data.values,
        x=heatmap_data.columns,
        y=heatmap_data.index,
        colorscale='Reds',
        showscale=True,
        hovertemplate="Estação: %{y}<br>Sensor: %{x}<br>Anomalias: %{z}<extra></extra>"
    ))
    
    fig.update_layout(
        title="Mapa de Calor - Anomalias por Estação e Sensor",
        xaxis_title="Tipo de Sensor",
        yaxis_title="Estação",
        height=400
    )
    
    return fig

def create_real_time_alerts(anomalies: List[Dict]) -> None:
    """Criar alertas em tempo real."""
    if not anomalies:
        st.success("✅ Nenhum alerta ativo no momento")
        return
    
    # Filtrar anomalias críticas e recentes
    recent_anomalies = [a for a in anomalies if a.get('severity') in ['high', 'critical']]
    
    if recent_anomalies:
        st.warning(f"⚠️ {len(recent_anomalies)} alertas críticos ativos")
        
        for anomaly in recent_anomalies[:5]:  # Mostrar apenas os 5 mais recentes
            severity = anomaly.get('severity', 'medium')
            icon = "🚨" if severity == 'critical' else "⚠️"
            
            with st.expander(f"{icon} {anomaly.get('station_id')} - {anomaly.get('sensor_type')}", expanded=False):
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Score de Anomalia", f"{anomaly.get('anomaly_score', 0):.3f}")
                
                with col2:
                    st.metric("Valor do Sensor", f"{anomaly.get('sensor_value', 0):.2f}")
                
                with col3:
                    detected_at = pd.to_datetime(anomaly.get('detected_at'))
                    st.metric("Detectado há", f"{(datetime.now() - detected_at.tz_localize(None)).seconds // 60} min")

# Interface principal aprimorada
def main():
    # Header customizado
    st.markdown("""
    <div class="main-header">
        <h1>⛽ CrewAI Fuel OP - Dashboard Avançado</h1>
        <p>Sistema de Monitoramento Inteligente de Combustível</p>
    </div>
    """, unsafe_allow_html=True)

    # Sidebar aprimorada
    with st.sidebar:
        st.markdown("### 🔧 Painel de Controle")

        # Status da conexão
        with st.spinner("Verificando conexão..."):
            health_data = load_health_status()
            
        if health_data.get("status") == "healthy":
            st.success("🟢 Sistema Online")
        else:
            st.error("🔴 Sistema Offline")

        st.markdown("---")

        # Auto-refresh aprimorado
        st.markdown("### 🔄 Atualização Automática")
        auto_refresh = st.checkbox("Ativar auto-refresh", value=True)
        
        if auto_refresh:
            refresh_interval = st.slider("Intervalo (segundos)", 10, 300, REFRESH_INTERVAL)
            st.info(f"Próxima atualização em {refresh_interval}s")

        st.markdown("---")

        # Filtros avançados
        st.markdown("### 🔍 Filtros Avançados")

        # Carregar dados para filtros
        stations_data = load_stations()
        station_options = ["🌐 Todas as Estações"] + [f"🏭 {s['station_id']}" for s in stations_data.get("stations", [])]
        selected_station = st.selectbox("Estação", station_options)

        # Filtro de tipo de sensor
        sensor_types = ["📊 Todos os Sensores", "⛽ Nível de Combustível", "🌡️ Temperatura", "📏 Pressão", "💧 Vazão"]
        selected_sensor_type = st.selectbox("Tipo de Sensor", sensor_types)

        # Filtro de severidade
        severity_options = ["🎯 Todas as Severidades", "🟢 Baixa", "🟡 Média", "🟠 Alta", "🔴 Crítica"]
        selected_severity = st.selectbox("Severidade", severity_options)

        # Período de tempo avançado
        st.markdown("#### ⏰ Período de Análise")
        time_options = {
            "⚡ Última Hora": 1,
            "🌅 Últimas 6 Horas": 6,
            "📅 Último Dia": 24,
            "📊 Última Semana": 168,
            "📈 Último Mês": 720
        }
        selected_time = st.selectbox("Período", list(time_options.keys()), index=2)
        hours_back = time_options[selected_time]

        # Filtro de data customizado
        use_custom_date = st.checkbox("📆 Período Personalizado")
        if use_custom_date:
            start_date = st.date_input("Data Inicial", datetime.now() - timedelta(days=7))
            end_date = st.date_input("Data Final", datetime.now())

        st.markdown("---")

        # Ações de ML aprimoradas
        st.markdown("### 🤖 Machine Learning")

        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔄 Anomalias", help="Retreinar modelo de detecção de anomalias"):
                with st.spinner("Treinando..."):
                    result = api.post("/retrain/anomaly-model", {"contamination": 0.1})
                    if result:
                        st.success("✅ Sucesso!")
                        st.cache_data.clear()

        with col2:
            if st.button("📈 Demanda", help="Retreinar modelo de previsão de demanda"):
                with st.spinner("Treinando..."):
                    result = api.post("/retrain/demand-model")
                    if result:
                        st.success("✅ Sucesso!")
                        st.cache_data.clear()

        st.markdown("---")

        # Configurações de exibição
        st.markdown("### ⚙️ Configurações")
        show_raw_data = st.checkbox("Mostrar dados brutos", value=False)
        chart_theme = st.selectbox("Tema dos gráficos", ["plotly", "plotly_white", "plotly_dark"])

    # Carregar dados principais
    with st.spinner("🔄 Carregando dados do dashboard..."):
        dashboard_data = load_dashboard_stats()

    if not dashboard_data:
        st.error("❌ Erro ao carregar dados do dashboard")
        st.stop()

    # Seção de alertas em tempo real
    st.markdown("### 🚨 Alertas em Tempo Real")
    
    # Processar filtros
    station_filter = None
    if selected_station != "🌐 Todas as Estações":
        station_filter = selected_station.replace("🏭 ", "")
    
    severity_map = {
        "🟢 Baixa": "low",
        "🟡 Média": "medium", 
        "🟠 Alta": "high",
        "🔴 Crítica": "critical"
    }
    severity_filter = severity_map.get(selected_severity)

    anomalies_data = load_anomalies(station_filter, severity_filter, limit=50)
    anomalies = anomalies_data.get("anomalies", [])
    
    create_real_time_alerts(anomalies)

    st.markdown("---")

    # Métricas principais aprimoradas
    st.markdown("### 📊 Visão Geral do Sistema")

    overview = dashboard_data.get("overview", {})
    
    col1, col2, col3, col4, col5 = st.columns(5)

    with col1:
        fig_stations = create_advanced_gauge(
            overview.get("active_stations", 0),
            "Estações Ativas",
            max_value=max(overview.get("total_stations", 1), 1),
            unit="estações"
        )
        st.plotly_chart(fig_stations, use_container_width=True)

    with col2:
        fig_sensors = create_advanced_gauge(
            overview.get("recent_data_points", 0),
            "Dados Recentes",
            max_value=max(overview.get("total_sensors", 1), 1),
            unit="pontos"
        )
        st.plotly_chart(fig_sensors, use_container_width=True)

    with col3:
        anomaly_count = overview.get("unresolved_anomalies", 0)
        fig_anomalies = create_advanced_gauge(
            anomaly_count,
            "Anomalias Abertas",
            max_value=max(anomaly_count * 2, 10),
            unit="alertas",
            thresholds={"warning": 3, "critical": 7}
        )
        st.plotly_chart(fig_anomalies, use_container_width=True)

    with col4:
        # Calcular uptime baseado no health status
        uptime = 99.5 if health_data.get("status") == "healthy" else 85.0
        fig_uptime = create_advanced_gauge(
            uptime,
            "Uptime do Sistema",
            max_value=100,
            unit="%",
            thresholds={"warning": 95, "critical": 90}
        )
        st.plotly_chart(fig_uptime, use_container_width=True)

    with col5:
        # Calcular qualidade média dos dados
        quality_score = 95.2  # Placeholder - calcular baseado nos dados reais
        fig_quality = create_advanced_gauge(
            quality_score,
            "Qualidade dos Dados",
            max_value=100,
            unit="%",
            thresholds={"warning": 85, "critical": 70}
        )
        st.plotly_chart(fig_quality, use_container_width=True)

    st.markdown("---")

    # Tabs aprimoradas
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📈 Monitoramento", "⚠️ Anomalias", "🔮 Previsões", "📊 Analytics", "⚙️ Sistema"
    ])

    with tab1:
        st.markdown("### 📈 Monitoramento em Tempo Real")

        if station_filter:
            # Monitoramento específico da estação
            sensor_data = load_sensor_data(station_filter, hours_back)

            if sensor_data.get("sensor_data"):
                # Gráfico multi-sensor
                fig = create_multi_sensor_chart(
                    sensor_data["sensor_data"], 
                    f"Sensores - {station_filter}",
                    station_filter
                )
                st.plotly_chart(fig, use_container_width=True)

                # Estatísticas da estação
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("#### 📊 Estatísticas Atuais")
                    df = pd.DataFrame(sensor_data["sensor_data"])
                    if not df.empty:
                        latest_data = df.groupby('sensor_type').last()
                        for sensor_type, row in latest_data.iterrows():
                            st.metric(
                                label=sensor_type.replace('_', ' ').title(),
                                value=f"{row['value']:.2f} {row['unit']}",
                                delta=f"Qualidade: {row['quality_score']:.1%}"
                            )

                with col2:
                    st.markdown("#### 📋 Dados Recentes")
                    if show_raw_data:
                        recent_df = pd.DataFrame(sensor_data["sensor_data"][:10])
                        recent_df['timestamp'] = pd.to_datetime(recent_df['timestamp'])
                        st.dataframe(recent_df, use_container_width=True)
            else:
                st.info("📭 Nenhum dado encontrado para a estação selecionada")

        else:
            # Visão geral de todas as estações
            sensors_data = dashboard_data.get("sensors", {})
            recent_data = sensors_data.get("recent_data", [])

            if recent_data:
                # Gráfico geral
                fig = create_multi_sensor_chart(recent_data, "Visão Geral - Todas as Estações")
                st.plotly_chart(fig, use_container_width=True)

                # Mapa de estações
                st.markdown("#### 🗺️ Status das Estações")
                stations = sensors_data.get("stations", [])
                
                if stations:
                    cols = st.columns(min(len(stations), 4))
                    for i, station in enumerate(stations):
                        with cols[i % 4]:
                            status_icon = "🟢" if station in [d["station_id"] for d in recent_data] else "🔴"
                            st.metric(
                                label=f"{status_icon} {station}",
                                value="Online" if status_icon == "🟢" else "Offline"
                            )

    with tab2:
        st.markdown("### ⚠️ Análise de Anomalias")

        if anomalies:
            # Heatmap de anomalias
            fig_heatmap = create_anomaly_heatmap(anomalies)
            st.plotly_chart(fig_heatmap, use_container_width=True)

            col1, col2 = st.columns(2)

            with col1:
                # Distribuição por severidade
                st.markdown("#### 📊 Distribuição por Severidade")
                anomaly_stats = dashboard_data.get("anomalies", {}).get("by_severity", {})
                
                if anomaly_stats:
                    fig_pie = px.pie(
                        values=list(anomaly_stats.values()),
                        names=[f"{k.title()} ({v})" for k, v in anomaly_stats.items()],
                        title="Anomalias por Severidade",
                        color_discrete_map={
                            "Low": "#28a745",
                            "Medium": "#ffc107", 
                            "High": "#fd7e14",
                            "Critical": "#dc3545"
                        }
                    )
                    st.plotly_chart(fig_pie, use_container_width=True)

            with col2:
                # Timeline de anomalias
                st.markdown("#### ⏰ Timeline de Anomalias")
                df_anomalies = pd.DataFrame(anomalies[:20])
                if not df_anomalies.empty:
                    df_anomalies['detected_at'] = pd.to_datetime(df_anomalies['detected_at'])
                    
                    fig_timeline = px.scatter(
                        df_anomalies,
                        x='detected_at',
                        y='station_id',
                        color='severity',
                        size='anomaly_score',
                        hover_data=['sensor_type', 'sensor_value'],
                        title="Timeline de Anomalias"
                    )
                    st.plotly_chart(fig_timeline, use_container_width=True)

            # Tabela detalhada de anomalias
            st.markdown("#### 📋 Detalhes das Anomalias")
            df_display = pd.DataFrame(anomalies[:20])
            if not df_display.empty:
                df_display['detected_at'] = pd.to_datetime(df_display['detected_at'])
                df_display = df_display.sort_values('detected_at', ascending=False)
                
                # Formatação da tabela
                df_display['anomaly_score'] = df_display['anomaly_score'].round(3)
                df_display['sensor_value'] = df_display['sensor_value'].round(2)
                
                st.dataframe(
                    df_display[['station_id', 'sensor_type', 'severity', 'anomaly_score', 'sensor_value', 'detected_at']],
                    use_container_width=True
                )
        else:
            st.success("✅ Nenhuma anomalia encontrada com os filtros aplicados")

    with tab3:
        st.markdown("### 🔮 Previsões e Análise Preditiva")

        # Interface aprimorada para previsão
        col1, col2, col3 = st.columns([2, 1, 1])

        with col1:
            pred_station = st.selectbox(
                "🏭 Estação para Previsão", 
                [s["station_id"] for s in stations_data.get("stations", [])],
                key="pred_station"
            )

        with col2:
            pred_hours = st.slider("⏰ Horas à frente", 1, 168, 24, key="pred_hours")

        with col3:
            confidence_level = st.slider("📊 Nível de Confiança", 80, 99, 95)

        if st.button("🔮 Gerar Previsão Avançada", key="predict_btn", type="primary"):
            with st.spinner("🔄 Gerando previsão com IA..."):
                prediction_data = {
                    "station_id": pred_station,
                    "hours_ahead": pred_hours
                }
                result = api.post("/predict/demand", prediction_data)

                if result and "prediction" in result:
                    prediction = result["prediction"]

                    # Gráfico de previsão avançado
                    pred_df = pd.DataFrame(prediction["predictions"])
                    pred_df['timestamp'] = pd.to_datetime(pred_df['timestamp'])

                    fig = go.Figure()
                    
                    # Linha principal de previsão
                    fig.add_trace(go.Scatter(
                        x=pred_df['timestamp'],
                        y=pred_df['predicted_consumption'],
                        mode='lines+markers',
                        name='Consumo Previsto',
                        line=dict(color='#2980b9', width=3),
                        marker=dict(size=6)
                    ))
                    
                    # Banda de confiança (simulada)
                    upper_bound = pred_df['predicted_consumption'] * 1.1
                    lower_bound = pred_df['predicted_consumption'] * 0.9
                    
                    fig.add_trace(go.Scatter(
                        x=pred_df['timestamp'],
                        y=upper_bound,
                        mode='lines',
                        line=dict(width=0),
                        showlegend=False,
                        hoverinfo='skip'
                    ))
                    
                    fig.add_trace(go.Scatter(
                        x=pred_df['timestamp'],
                        y=lower_bound,
                        mode='lines',
                        line=dict(width=0),
                        fill='tonexty',
                        fillcolor='rgba(41, 128, 185, 0.2)',
                        name=f'Intervalo de Confiança ({confidence_level}%)',
                        hoverinfo='skip'
                    ))

                    fig.update_layout(
                        title=f"📈 Previsão de Consumo - {pred_station}",
                        xaxis_title="Data/Hora",
                        yaxis_title="Consumo Previsto (L)",
                        height=500,
                        hovermode='x unified'
                    )

                    st.plotly_chart(fig, use_container_width=True)

                    # Métricas da previsão
                    col1, col2, col3, col4 = st.columns(4)
                    
                    total_consumption = prediction.get("total_predicted_consumption", 0)
                    avg_consumption = total_consumption / pred_hours if pred_hours > 0 else 0
                    
                    with col1:
                        st.metric("💧 Consumo Total", f"{total_consumption:.2f} L")
                    
                    with col2:
                        st.metric("📊 Consumo Médio/Hora", f"{avg_consumption:.2f} L/h")
                    
                    with col3:
                        peak_consumption = pred_df['predicted_consumption'].max()
                        st.metric("📈 Pico de Consumo", f"{peak_consumption:.2f} L")
                    
                    with col4:
                        min_consumption = pred_df['predicted_consumption'].min()
                        st.metric("📉 Consumo Mínimo", f"{min_consumption:.2f} L")

                else:
                    st.error("❌ Erro ao gerar previsão")

    with tab4:
        st.markdown("### 📊 Analytics Avançado")
        
        # Análise de tendências
        st.markdown("#### 📈 Análise de Tendências")
        
        # Placeholder para análises mais avançadas
        st.info("🚧 Seção em desenvolvimento - Analytics avançado com ML")
        
        # Exemplo de análise de correlação
        if station_filter:
            sensor_data = load_sensor_data(station_filter, hours_back * 2)  # Mais dados para análise
            
            if sensor_data.get("sensor_data"):
                df = pd.DataFrame(sensor_data["sensor_data"])
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                
                # Matriz de correlação
                pivot_df = df.pivot_table(
                    index='timestamp', 
                    columns='sensor_type', 
                    values='value', 
                    aggfunc='mean'
                ).fillna(method='ffill')
                
                if len(pivot_df.columns) > 1:
                    corr_matrix = pivot_df.corr()
                    
                    fig_corr = px.imshow(
                        corr_matrix,
                        title="Matriz de Correlação entre Sensores",
                        color_continuous_scale="RdBu",
                        aspect="auto"
                    )
                    st.plotly_chart(fig_corr, use_container_width=True)

    with tab5:
        st.markdown("### ⚙️ Status do Sistema")

        # Health check detalhado
        if health_data:
            col1, col2 = st.columns(2)

            with col1:
                st.markdown("#### 💾 Banco de Dados")
                db_data = health_data.get("database", {})

                if db_data:
                    st.success("✅ Banco de Dados Conectado")
                    
                    metrics_col1, metrics_col2 = st.columns(2)
                    with metrics_col1:
                        st.metric("Total de Registros", db_data.get("sensor_data_count", 0))
                        st.metric("Anomalias Registradas", db_data.get("anomaly_events_count", 0))
                    
                    with metrics_col2:
                        st.metric("Dados Recentes (24h)", db_data.get("recent_sensor_data", 0))
                        st.metric("Anomalias Não Resolvidas", db_data.get("unresolved_anomalies", 0))
                else:
                    st.error("❌ Erro na conexão com o banco")

            with col2:
                st.markdown("#### 🤖 Serviços de ML")
                ml_services = health_data.get("ml_services", {})
                
                for service_name, service_info in ml_services.items():
                    status = service_info.get("status", "unknown")
                    model_loaded = service_info.get("model_loaded", False)
                    
                    if status == "operational" and model_loaded:
                        st.success(f"✅ {service_name.replace('_', ' ').title()}")
                    else:
                        st.error(f"❌ {service_name.replace('_', ' ').title()}")

        # Logs do sistema (placeholder)
        st.markdown("#### 📋 Logs do Sistema")
        st.info("🚧 Visualização de logs em desenvolvimento")

    # Auto-refresh
    if auto_refresh:
        time.sleep(refresh_interval)
        st.rerun()

if __name__ == "__main__":
    main()

