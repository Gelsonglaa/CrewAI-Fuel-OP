#!/bin/bash

# =============================================================================
# Health Check Script para CrewAI Fuel OP API
# =============================================================================

set -e

# Configurações
API_HOST=${API_HOST:-localhost}
API_PORT=${API_PORT:-8000}
HEALTH_ENDPOINT="/health"
TIMEOUT=${HEALTH_CHECK_TIMEOUT:-10}

# Função para log com timestamp
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Função para verificar se a API está respondendo
check_api_health() {
    local url="http://${API_HOST}:${API_PORT}${HEALTH_ENDPOINT}"
    
    log "Verificando saúde da API em: $url"
    
    # Fazer requisição HTTP com timeout
    response=$(curl -s -w "%{http_code}" --max-time $TIMEOUT "$url" || echo "000")
    http_code="${response: -3}"
    body="${response%???}"
    
    if [ "$http_code" = "200" ]; then
        log "✅ API está saudável (HTTP $http_code)"
        
        # Verificar se a resposta contém os campos esperados
        if echo "$body" | grep -q '"status"' && echo "$body" | grep -q '"timestamp"'; then
            log "✅ Resposta de saúde válida"
            return 0
        else
            log "⚠️  Resposta de saúde inválida: $body"
            return 1
        fi
    else
        log "❌ API não está saudável (HTTP $http_code)"
        if [ -n "$body" ]; then
            log "Resposta: $body"
        fi
        return 1
    fi
}

# Função para verificar conectividade de rede
check_network() {
    log "Verificando conectividade de rede..."
    
    if nc -z "$API_HOST" "$API_PORT" 2>/dev/null; then
        log "✅ Porta $API_PORT está acessível"
        return 0
    else
        log "❌ Não foi possível conectar na porta $API_PORT"
        return 1
    fi
}

# Função para verificar uso de recursos
check_resources() {
    log "Verificando uso de recursos..."
    
    # Verificar uso de memória
    if command -v free >/dev/null 2>&1; then
        memory_usage=$(free | grep Mem | awk '{printf "%.1f", $3/$2 * 100.0}')
        log "📊 Uso de memória: ${memory_usage}%"
        
        # Alertar se uso de memória for muito alto
        if (( $(echo "$memory_usage > 90" | bc -l) )); then
            log "⚠️  Alto uso de memória detectado"
        fi
    fi
    
    # Verificar uso de CPU (se disponível)
    if command -v top >/dev/null 2>&1; then
        cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
        if [ -n "$cpu_usage" ]; then
            log "📊 Uso de CPU: ${cpu_usage}%"
        fi
    fi
    
    # Verificar espaço em disco
    if command -v df >/dev/null 2>&1; then
        disk_usage=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
        log "📊 Uso de disco: ${disk_usage}%"
        
        # Alertar se uso de disco for muito alto
        if [ "$disk_usage" -gt 85 ]; then
            log "⚠️  Alto uso de disco detectado"
        fi
    fi
}

# Função principal
main() {
    log "🏥 Iniciando verificação de saúde..."
    
    # Verificar conectividade básica
    if ! check_network; then
        log "❌ Falha na verificação de rede"
        exit 1
    fi
    
    # Verificar saúde da API
    if ! check_api_health; then
        log "❌ Falha na verificação de saúde da API"
        exit 1
    fi
    
    # Verificar recursos (não crítico)
    check_resources || true
    
    log "✅ Todas as verificações de saúde passaram"
    exit 0
}

# Executar verificação principal
main "$@"

