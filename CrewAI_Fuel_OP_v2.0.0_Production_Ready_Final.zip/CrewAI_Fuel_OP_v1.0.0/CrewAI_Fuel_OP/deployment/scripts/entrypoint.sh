#!/bin/bash

# =============================================================================
# Entrypoint Script para CrewAI Fuel OP API
# =============================================================================

set -e

echo "🚀 Iniciando CrewAI Fuel OP API..."

# Configurar timezone
export TZ=${TIMEZONE:-America/Sao_Paulo}

# Aguardar serviços dependentes
echo "⏳ Aguardando banco de dados..."
./wait-for-it.sh ${DATABASE_HOST:-db}:${DATABASE_PORT:-5432} --timeout=60 --strict

if [ -n "$REDIS_URL" ]; then
    echo "⏳ Aguardando Redis..."
    ./wait-for-it.sh ${REDIS_HOST:-redis}:${REDIS_PORT:-6379} --timeout=30 --strict
fi

if [ -n "$MQTT_BROKER_URL" ]; then
    echo "⏳ Aguardando MQTT Broker..."
    ./wait-for-it.sh ${MQTT_BROKER_URL:-mqtt}:${MQTT_PORT:-1883} --timeout=30 --strict
fi

# Executar migrações do banco de dados
echo "🔄 Executando migrações do banco de dados..."
if [ "$ENVIRONMENT" = "production" ]; then
    alembic upgrade head
else
    # Em desenvolvimento, criar tabelas se não existirem
    python -c "
from app.core.database import create_tables
try:
    create_tables()
    print('✅ Tabelas criadas/verificadas com sucesso')
except Exception as e:
    print(f'❌ Erro ao criar tabelas: {e}')
    exit(1)
"
fi

# Criar usuário administrador padrão se não existir
echo "👤 Verificando usuário administrador..."
python -c "
from app.auth.auth_service import AuthService
from app.core.database import SessionLocal
import os

db = SessionLocal()
auth_service = AuthService(db)

admin_user = {
    'username': os.getenv('ADMIN_USERNAME', 'admin'),
    'email': os.getenv('ADMIN_EMAIL', 'admin@fuel-op.com'),
    'password': os.getenv('ADMIN_PASSWORD', 'admin123'),
    'full_name': 'Administrador do Sistema',
    'is_active': True
}

existing_user = auth_service.get_user_by_username(admin_user['username'])
if not existing_user:
    user = auth_service.create_user(admin_user)
    if user:
        print(f'✅ Usuário administrador criado: {admin_user[\"username\"]}')
    else:
        print('❌ Erro ao criar usuário administrador')
else:
    print(f'ℹ️  Usuário administrador já existe: {admin_user[\"username\"]}')

db.close()
"

# Verificar modelos de ML
echo "🤖 Verificando modelos de Machine Learning..."
python -c "
import os
from pathlib import Path

models_dir = Path('/app/models')
models_dir.mkdir(exist_ok=True)

# Verificar se existem modelos treinados
anomaly_model = models_dir / 'anomaly_detection_model.joblib'
demand_model = models_dir / 'demand_prediction_model.joblib'

if not anomaly_model.exists():
    print('⚠️  Modelo de detecção de anomalias não encontrado')
    print('   O modelo será treinado automaticamente quando houver dados suficientes')

if not demand_model.exists():
    print('⚠️  Modelo de previsão de demanda não encontrado')
    print('   O modelo será treinado automaticamente quando houver dados suficientes')

print('✅ Verificação de modelos ML concluída')
"

# Configurar logs
echo "📝 Configurando sistema de logs..."
mkdir -p /app/logs
touch /app/logs/fuel_op.log
touch /app/logs/access.log
touch /app/logs/error.log

# Verificar configurações críticas
echo "🔍 Verificando configurações..."
python -c "
import os
import sys

# Verificar variáveis críticas
critical_vars = ['SECRET_KEY', 'DATABASE_URL']
missing_vars = []

for var in critical_vars:
    if not os.getenv(var):
        missing_vars.append(var)

if missing_vars:
    print(f'❌ Variáveis de ambiente críticas não definidas: {missing_vars}')
    sys.exit(1)

# Verificar se SECRET_KEY não é o padrão
secret_key = os.getenv('SECRET_KEY')
if secret_key in ['your-super-secret-key-change-this-in-production', 'changeme']:
    print('⚠️  AVISO: SECRET_KEY está usando valor padrão. Altere em produção!')

print('✅ Configurações verificadas')
"

# Pré-carregar modelos se existirem
echo "🔄 Pré-carregando serviços..."
python -c "
try:
    from app.ml.anomaly_detection_service import anomaly_detection_service
    from app.ml.demand_prediction_service import demand_prediction_service
    print('✅ Serviços de ML inicializados')
except Exception as e:
    print(f'⚠️  Aviso ao inicializar serviços ML: {e}')
"

# Executar testes de conectividade
echo "🔗 Testando conectividade..."
python -c "
from app.core.database import engine
try:
    with engine.connect() as conn:
        conn.execute('SELECT 1')
    print('✅ Conexão com banco de dados OK')
except Exception as e:
    print(f'❌ Erro de conexão com banco: {e}')
    exit(1)
"

# Configurar sinais para graceful shutdown
trap 'echo \"🛑 Recebido sinal de parada, encerrando graciosamente...\"; kill -TERM \$PID; wait \$PID' TERM INT

echo "✅ Inicialização concluída com sucesso!"
echo "🌟 CrewAI Fuel OP API está pronta para receber requisições"

# Executar comando principal
exec "$@" &
PID=$!
wait $PID

